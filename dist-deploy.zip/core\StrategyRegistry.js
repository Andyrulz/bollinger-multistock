"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StrategyRegistry = void 0;
class StrategyRegistry {
    static initialize(logger) {
        this.logger = logger;
        this.logger.info('🏭 Strategy Registry initialized');
    }
    static registerStrategy(id, strategyClass) {
        this.strategies.set(id, strategyClass);
        this.logger.info(`📝 Registered strategy: ${id}`);
    }
    static async createInstance(id, kiteConnect, logger, quoteManager, instrumentCache, config) {
        const StrategyClass = this.strategies.get(id);
        if (!StrategyClass) {
            throw new Error(`Strategy class not found for ID: ${id}`);
        }
        if (this.instances.has(config.id)) {
            throw new Error(`Strategy instance already exists for ID: ${config.id}`);
        }
        try {
            const instance = new StrategyClass(kiteConnect, logger, quoteManager, instrumentCache, config);
            const hasAuth = !!(kiteConnect.access_token || kiteConnect.accessToken);
            if (hasAuth) {
                await instance.initialize();
                this.logger.info(`✅ Created and initialized: ${config.name} (${config.id})`);
            }
            else {
                this.logger.warn(`⏸️ Created ${config.name} - initialization pending authentication`);
            }
            this.instances.set(config.id, instance);
            return instance;
        }
        catch (error) {
            this.logger.error(`❌ Failed to create strategy instance ${config.id}:`, error);
            throw error;
        }
    }
    static getInstance(id) {
        return this.instances.get(id);
    }
    static getAllInstances() {
        return new Map(this.instances);
    }
    static async removeInstance(id) {
        const instance = this.instances.get(id);
        if (!instance) {
            return false;
        }
        try {
            if (instance.isRunning()) {
                await instance.stop();
            }
            this.instances.delete(id);
            this.logger.info(`🗑️ Removed strategy instance: ${id}`);
            return true;
        }
        catch (error) {
            this.logger.error(`❌ Failed to remove strategy instance ${id}:`, error);
            return false;
        }
    }
    static getRegisteredStrategies() {
        return Array.from(this.strategies.keys());
    }
    static getActiveInstances() {
        return Array.from(this.instances.keys());
    }
    static isRegistered(id) {
        return this.strategies.has(id);
    }
    static hasInstance(id) {
        return this.instances.has(id);
    }
    static async initializePendingStrategies() {
        const pendingStrategies = [];
        for (const [id, instance] of this.instances.entries()) {
            if (!instance.isInitialized) {
                pendingStrategies.push({ id, instance });
            }
        }
        if (pendingStrategies.length === 0) {
            this.logger.info('✅ All strategies already initialized');
            return;
        }
        this.logger.info(`🔄 Initializing ${pendingStrategies.length} pending strategies...`);
        for (const { id, instance } of pendingStrategies) {
            try {
                await instance.initialize();
                this.logger.info(`✅ Initialized strategy: ${instance.getName()}`);
                await instance.start();
                this.logger.info(`🚀 Started strategy: ${instance.getName()}`);
            }
            catch (error) {
                this.logger.error(`❌ Failed to initialize/start strategy ${id}:`, error);
            }
        }
        const successCount = pendingStrategies.filter(({ instance }) => instance.isInitialized).length;
        this.logger.info(`✅ Strategy initialization complete: ${successCount}/${pendingStrategies.length} successful`);
    }
}
exports.StrategyRegistry = StrategyRegistry;
StrategyRegistry.strategies = new Map();
StrategyRegistry.instances = new Map();
//# sourceMappingURL=StrategyRegistry.js.map