import { Logger } from '../../utils/Logger';
import { TradeSetupRequest } from './BreakoutPullbackStrategy';
export interface OptionInstrument {
    instrument_token: number;
    tradingsymbol: string;
    name: string;
    exchange: string;
    strike: number;
    expiry: Date;
    instrument_type: string;
    lot_size: number;
}
export interface ActivePosition {
    tradeId: string;
    entryOrderId: string;
    instrument: OptionInstrument;
    direction: 'LONG' | 'SHORT';
    quantity: number;
    entryPrice: number;
    entryTime: Date;
    stopLoss: number;
    target: number;
    originalStopLoss: number;
    isTrailingActive: boolean;
    trailingTrigger: number;
    trailedAt?: Date;
}
export interface TradeRecord {
    tradeId: string;
    entryOrderId: string;
    exitOrderId?: string;
    instrument: OptionInstrument;
    direction: 'LONG' | 'SHORT';
    quantity: number;
    entryPrice: number;
    exitPrice?: number;
    entryTime: Date;
    exitTime?: Date;
    pnl?: number;
    exitReason?: 'TARGET' | 'STOP_LOSS' | 'MANUAL';
    status: 'OPEN' | 'CLOSED';
    isPaperTrade: boolean;
}
export interface TradingConfig {
    capital: number;
    riskPerTrade: number;
    maxRetries: number;
    orderTimeout: number;
    paperTradingMode: boolean;
    niftyLotSize: number;
}
export interface PersistedData {
    config: TradingConfig;
    activePosition?: ActivePosition;
    tradeHistory: TradeRecord[];
    activeInstrument?: OptionInstrument & {
        selectedAt: Date;
        direction: 'LONG' | 'SHORT';
        underlyingPrice: number;
    };
    lastUpdated: Date;
}
export interface DetailedPosition {
    tradeId: string;
    direction: 'LONG' | 'SHORT';
    instrument: string;
    strikePrice: number;
    entryPrice: number;
    quantity: number;
    entryTime: Date;
    entryOrderId: string;
    stopLoss: number;
    target: number;
    currentLTP: number | null;
    currentLTPTimestamp: Date | null;
    unrealizedPnL: number | null;
    percentChange: number | null;
    minutesSinceEntry: number;
    secondsSinceLastUpdate: number | null;
    isActive: boolean;
}
export declare class TradeExecutionService {
    private kiteConnect;
    private logger;
    private persistedData;
    private dataFilePath;
    private instruments;
    private niftyInstruments;
    private cachedOptionPrice;
    private cachedOptionTimestamp;
    constructor(kiteConnect: any, logger: Logger);
    private setupGracefulShutdown;
    private gracefulShutdown;
    forceCloseAllPositions(reason?: string): Promise<void>;
    clearOrphanedPositionWithExitPrice(): Promise<void>;
    private fetchExitOrderFromBroker;
    clearOrphanedPosition(): void;
    private ensureDataDirectory;
    private loadPersistedData;
    private savePersistedData;
    loadInstruments(): Promise<void>;
    private getNextTuesdayExpiry;
    private findATMStrike;
    selectATMOption(direction: 'LONG' | 'SHORT', niftyPrice: number): Promise<OptionInstrument>;
    private calculatePositionSize;
    placeMarketOrder(tradeSetup: TradeSetupRequest): Promise<string>;
    closePosition(tradeId: string, exitReason?: 'TARGET' | 'STOP_LOSS' | 'MANUAL'): Promise<void>;
    private verifyBrokerPosition;
    syncWithBrokerState(): Promise<void>;
    private getOptionPrice;
    private waitForOrderConfirmation;
    private getActualFillPrice;
    private getActualFillQuantity;
    private calculatePnL;
    private updateCapitalAfterTrade;
    getCurrentCapital(): number;
    getActivePosition(): ActivePosition | undefined;
    updateStopLossToCost(entryPrice: number): void;
    getDetailedPosition(): DetailedPosition | null;
    getTradeHistory(): TradeRecord[];
    getTradingConfig(): TradingConfig;
    updateTradingConfig(updates: Partial<TradingConfig>): void;
    getExecutionStatus(): {
        hasActivePosition: boolean;
        currentCapital: number;
        totalTrades: number;
        paperTradingMode: boolean;
    };
    updateOptionPrice(price: number): void;
    getCachedOptionPrice(): {
        price: number;
        timestamp: Date;
    } | null;
    private clearOptionPriceCache;
    getOptionPriceByToken(instrumentToken: string): Promise<number>;
    getInstrumentsStatus(): {
        loaded: boolean;
        count: number;
        loadedAt?: Date;
        sampleInstruments?: any[];
    };
    onBreakoutDetected(direction: 'LONG' | 'SHORT', underlyingPrice: number, timestamp: Date): Promise<void>;
    getSelectedInstrument(): any;
}
//# sourceMappingURL=BreakoutPullbackExecutor.d.ts.map