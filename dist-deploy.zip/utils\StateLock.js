"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.globalStateLock = exports.StateLock = void 0;
class StateLock {
    constructor() {
        this.locks = new Map();
        this.queues = new Map();
    }
    async acquire(key, timeoutMs = 30000) {
        return new Promise((resolve, reject) => {
            if (!this.locks.get(key)) {
                this.locks.set(key, true);
                resolve(() => {
                    this.locks.delete(key);
                    this.processQueue(key);
                });
                return;
            }
            const timeout = setTimeout(() => {
                this.removeFromQueue(key, resolve);
                reject(new Error(`Lock acquisition timeout after ${timeoutMs}ms for key: ${key}`));
            }, timeoutMs);
            const queueEntry = {
                resolve: () => {
                    clearTimeout(timeout);
                    this.locks.set(key, true);
                    resolve(() => {
                        this.locks.delete(key);
                        this.processQueue(key);
                    });
                },
                reject: (error) => {
                    clearTimeout(timeout);
                    reject(error);
                },
                timeout
            };
            if (!this.queues.has(key)) {
                this.queues.set(key, []);
            }
            this.queues.get(key).push(queueEntry);
        });
    }
    processQueue(key) {
        const queue = this.queues.get(key);
        if (queue && queue.length > 0) {
            const next = queue.shift();
            next.resolve();
        }
        else {
            this.queues.delete(key);
        }
    }
    removeFromQueue(key, resolveFunction) {
        const queue = this.queues.get(key);
        if (queue) {
            const index = queue.findIndex(entry => entry.resolve === resolveFunction);
            if (index >= 0) {
                const removedEntries = queue.splice(index, 1);
                if (removedEntries.length > 0 && removedEntries[0]) {
                    clearTimeout(removedEntries[0].timeout);
                }
            }
        }
    }
    async executeAtomic(key, operation, timeoutMs = 30000) {
        const release = await this.acquire(key, timeoutMs);
        try {
            const result = await operation();
            return result;
        }
        finally {
            release();
        }
    }
    isLocked(key) {
        return this.locks.get(key) || false;
    }
    getActiveLocks() {
        return Array.from(this.locks.keys()).filter(key => this.locks.get(key));
    }
    getQueueStatus() {
        const status = {};
        for (const [key, locked] of this.locks.entries()) {
            status[key] = { locked, queueLength: 0 };
        }
        for (const [key, queue] of this.queues.entries()) {
            if (!status[key]) {
                status[key] = { locked: false, queueLength: queue.length };
            }
            else {
                status[key].queueLength = queue.length;
            }
        }
        return status;
    }
}
exports.StateLock = StateLock;
exports.globalStateLock = new StateLock();
//# sourceMappingURL=StateLock.js.map