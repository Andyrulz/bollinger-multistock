"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SECTOR_TOKENS = void 0;
exports.getSectorToken = getSectorToken;
exports.getSectorName = getSectorName;
exports.SECTOR_TOKENS = {
    "NIFTY 50": 256265,
    "NIFTY BANK": 260105,
    "NIFTY IT": 259849,
    "NIFTY AUTO": 257289,
    "NIFTY METAL": 258313,
    "NIFTY INFRA": 257801,
    "NIFTY ENERGY": 256521,
    "NIFTY FMCG": 257033,
    "NIFTY PHARMA": 258569,
    "NIFTY PSU BANK": 261129,
    "NIFTY FIN SERVICE": 257545,
    "NIFTY CONSUMER DURABLES": 261641,
    "NIFTY REALTY": 260617,
    "NIFTY HEALTHCARE": 260873,
    "NIFTY MEDIA": 258057,
};
function getSectorToken(sectorName) {
    return exports.SECTOR_TOKENS[sectorName] || null;
}
function getSectorName(token) {
    const entry = Object.entries(exports.SECTOR_TOKENS).find(([_, t]) => t === token);
    return entry ? entry[0] : null;
}
//# sourceMappingURL=sectorTokens.js.map