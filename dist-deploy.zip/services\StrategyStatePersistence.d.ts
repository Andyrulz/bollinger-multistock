import { Logger } from '../utils/Logger';
import { StrategyState, Candle, PivotPoint, BreakoutSignal, MarkingCandleState, TradeState, TradeSetupRequest, NiftyFuturesData } from '../strategies/breakout-pullback/BreakoutPullbackStrategy';
export interface PersistedStrategyState {
    isActive: boolean;
    currentContract?: NiftyFuturesData | undefined;
    tradeState: TradeState;
    currentTradeId?: string | undefined;
    tradeSetupRequest?: TradeSetupRequest | undefined;
    candles: Candle[];
    latestPivotHigh?: PivotPoint | undefined;
    latestPivotLow?: PivotPoint | undefined;
    latestBreakoutSignal?: BreakoutSignal | undefined;
    markingCandleState: MarkingCandleState;
    currentVolumeSMA50: number;
    lastCumulativeVolume: number;
    lastProcessedCandleForBreakout?: Date | undefined;
    lastFiveMinuteBoundary?: Date | undefined;
    lastUpdateTime: Date;
    lastPersistTime: Date;
    version: string;
}
interface CandlesCache {
    candles5m: Candle[];
    candles1m: Candle[];
    timestamp: Date;
    contract?: NiftyFuturesData | undefined;
}
export declare class StrategyStatePersistence {
    private readonly stateFilePath;
    private readonly backupFilePath;
    private readonly candlesCachePath;
    private readonly logger;
    private readonly encryptionKey;
    private readonly version;
    constructor(logger: Logger);
    private ensureStrategyDirectory;
    private encryptStateData;
    private decryptStateData;
    private convertStringDatesToObjects;
    validateStateIntegrity(state: PersistedStrategyState): boolean;
    saveStrategyState(state: PersistedStrategyState): Promise<void>;
    loadStrategyState(): Promise<PersistedStrategyState | null>;
    private loadStateFromFile;
    createBackup(): Promise<void>;
    saveCandlesCache(candles1m: Candle[], candles5m: Candle[], contract?: NiftyFuturesData): Promise<void>;
    loadCandlesCache(): Promise<CandlesCache | null>;
    private getFileSizeKB;
    cleanupOldBackups(): Promise<void>;
    convertStrategyStateToPersistedFormat(strategyState: StrategyState): PersistedStrategyState;
}
export {};
//# sourceMappingURL=StrategyStatePersistence.d.ts.map