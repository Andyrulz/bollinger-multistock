"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const SessionPersistence_1 = require("./SessionPersistence");
class AuthService {
    constructor(kiteConnect, logger) {
        this.kiteConnect = kiteConnect;
        this.logger = logger;
        this.lastValidationTime = 0;
        this.lastValidationResult = false;
        this.VALIDATION_CACHE_TTL = 5 * 60 * 1000;
        this.sessionPersistence = new SessionPersistence_1.SessionPersistence(logger);
        this.initializationPromise = this.initializeSession().catch(error => {
            this.logger.warn('Failed to initialize session on startup:', error);
        });
    }
    async waitForInitialization() {
        return this.initializationPromise;
    }
    async initializeSession() {
        try {
            const persistedSession = await this.sessionPersistence.loadSession();
            if (persistedSession) {
                this.accessToken = persistedSession.accessToken;
                this.sessionData = persistedSession.sessionData;
                this.kiteConnect.setAccessToken(this.accessToken);
                await this.validateToken();
                this.lastValidationResult = true;
                this.lastValidationTime = Date.now();
                this.logger.info(`🔑 Session restored successfully for user: ${this.sessionData.user_name}`);
                this.logger.info(`⏰ Session expires at: ${persistedSession.expiryTime.toLocaleString()}`);
            }
            else {
                this.logger.info('📝 No valid persisted session found - authentication required');
            }
        }
        catch (error) {
            this.logger.error('Failed to initialize session:', error);
            delete this.accessToken;
            delete this.sessionData;
            this.lastValidationResult = false;
            this.lastValidationTime = 0;
            await this.sessionPersistence.clearSession();
        }
    }
    isTransientError(error) {
        if (error?.code === 'ECONNABORTED' || error?.code === 'ETIMEDOUT' || error?.code === 'ECONNRESET' || error?.code === 'ENOTFOUND') {
            return true;
        }
        if (error?.error_type === 'NetworkException') {
            return true;
        }
        if (error?.message && /network|timeout|socket/i.test(error.message) && !error?.error_type) {
            return true;
        }
        return false;
    }
    async validateToken() {
        try {
            if (!this.accessToken) {
                throw new Error('No access token to validate');
            }
            await this.kiteConnect.getProfile();
            this.logger.debug('✅ Token validation successful');
        }
        catch (error) {
            if (this.isTransientError(error)) {
                this.logger.warn(`⚠️ Token validation skipped (transient error: ${error.code || error.error_type || error.message}). Keeping session intact.`);
                return;
            }
            this.logger.warn('❌ Token validation failed (auth error):', error);
            delete this.accessToken;
            delete this.sessionData;
            this.lastValidationResult = false;
            this.lastValidationTime = 0;
            await this.sessionPersistence.clearSession();
            throw error;
        }
    }
    getLoginUrl() {
        return this.kiteConnect.getLoginURL();
    }
    async generateSession(requestToken) {
        const apiSecret = process.env.ZERODHA_API_SECRET;
        if (!apiSecret) {
            throw new Error('ZERODHA_API_SECRET environment variable is not set');
        }
        const maxRetries = 3;
        const baseDelay = 2000;
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                this.logger.info(`Generating session with request token (attempt ${attempt}/${maxRetries})`);
                const response = await this.kiteConnect.generateSession(requestToken, apiSecret);
                this.accessToken = response.access_token;
                this.sessionData = response;
                this.kiteConnect.setAccessToken(this.accessToken);
                if (this.accessToken && this.sessionData) {
                    await this.sessionPersistence.saveSession(this.accessToken, this.sessionData);
                }
                this.lastValidationResult = true;
                this.lastValidationTime = Date.now();
                this.logger.info(`Session generated and saved successfully for user: ${response.user_name}`);
                return response;
            }
            catch (error) {
                if (this.isTransientError(error) && attempt < maxRetries) {
                    const delay = baseDelay * Math.pow(2, attempt - 1);
                    this.logger.warn(`⚠️ generateSession attempt ${attempt} failed (transient: ${error.code || error.error_type || error.message}), retrying in ${delay}ms...`);
                    await new Promise(resolve => setTimeout(resolve, delay));
                    continue;
                }
                this.logger.error(`Failed to generate session (attempt ${attempt}):`, error);
                throw error;
            }
        }
        throw new Error('generateSession: exhausted all retries');
    }
    isAuthenticated() {
        return !!this.accessToken;
    }
    async isAuthenticatedAndValid() {
        if (!this.accessToken) {
            return false;
        }
        const now = Date.now();
        if (this.lastValidationResult && (now - this.lastValidationTime) < this.VALIDATION_CACHE_TTL) {
            return true;
        }
        try {
            await this.kiteConnect.getProfile();
            this.lastValidationResult = true;
            this.lastValidationTime = now;
            return true;
        }
        catch (error) {
            if (this.isTransientError(error)) {
                this.logger.warn(`⚠️ Auth validation skipped (transient: ${error.code || error.error_type || error.message}). Assuming session is still valid.`);
                if (this.lastValidationResult) {
                    return true;
                }
                return false;
            }
            this.logger.warn('❌ Token validation failed (auth error) during auth check:', error);
            delete this.accessToken;
            delete this.sessionData;
            this.lastValidationResult = false;
            this.lastValidationTime = 0;
            await this.sessionPersistence.clearSession();
            return false;
        }
    }
    getAccessToken() {
        return this.accessToken;
    }
    getSessionData() {
        return this.sessionData;
    }
    async getProfile() {
        try {
            if (!this.isAuthenticated()) {
                throw new Error('Not authenticated. Please generate session first.');
            }
            const profile = await this.kiteConnect.getProfile();
            this.logger.info('Profile retrieved successfully');
            return profile;
        }
        catch (error) {
            this.logger.error('Failed to get profile:', error);
            throw error;
        }
    }
    async invalidateSession() {
        try {
            if (this.accessToken) {
                try {
                    await this.kiteConnect.invalidateAccessToken(this.accessToken);
                }
                catch (remoteError) {
                    this.logger.warn('Remote token invalidation failed (continuing with local cleanup):', remoteError);
                }
                delete this.accessToken;
                delete this.sessionData;
                this.lastValidationResult = false;
                this.lastValidationTime = 0;
                await this.sessionPersistence.clearSession();
                this.logger.info('Session invalidated and cleared successfully');
            }
        }
        catch (error) {
            this.logger.error('Failed to invalidate session:', error);
            throw error;
        }
    }
    async clearSessionOnExpiry() {
        this.logger.warn('🔒 Session expiry hook triggered by KiteConnect — clearing session');
        delete this.accessToken;
        delete this.sessionData;
        this.lastValidationResult = false;
        this.lastValidationTime = 0;
        await this.sessionPersistence.clearSession();
    }
    async getSessionInfo() {
        const persistedInfo = await this.sessionPersistence.getSessionInfo();
        const result = {
            authenticated: this.isAuthenticated(),
            persistedSession: persistedInfo
        };
        if (this.sessionData?.user_name) {
            result.userName = this.sessionData.user_name;
        }
        return result;
    }
}
exports.AuthService = AuthService;
//# sourceMappingURL=AuthService.js.map