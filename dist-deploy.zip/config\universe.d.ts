export interface UniverseStock {
    symbol: string;
    instrumentToken: number;
    sector: string;
    sectorToken: number;
    lotSize: number;
}
export declare const UNIVERSE: UniverseStock[];
//# sourceMappingURL=universe.d.ts.map