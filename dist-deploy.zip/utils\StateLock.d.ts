export declare class StateLock {
    private locks;
    private queues;
    acquire(key: string, timeoutMs?: number): Promise<() => void>;
    private processQueue;
    private removeFromQueue;
    executeAtomic<T>(key: string, operation: () => Promise<T>, timeoutMs?: number): Promise<T>;
    isLocked(key: string): boolean;
    getActiveLocks(): string[];
    getQueueStatus(): {
        [key: string]: {
            locked: boolean;
            queueLength: number;
        };
    };
}
export declare const globalStateLock: StateLock;
//# sourceMappingURL=StateLock.d.ts.map