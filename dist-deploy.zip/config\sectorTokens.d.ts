export declare const SECTOR_TOKENS: Record<string, number>;
export declare function getSectorToken(sectorName: string): number | null;
export declare function getSectorName(token: number): string | null;
//# sourceMappingURL=sectorTokens.d.ts.map