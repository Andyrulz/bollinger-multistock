export interface OrderCharges {
    brokerage: number;
    stt: number;
    txnCharges: number;
    sebiCharges: number;
    stampDuty: number;
    ipft: number;
    gst: number;
    total: number;
}
export interface TradeCharges {
    buy: OrderCharges;
    sell: OrderCharges;
    totalCharges: number;
}
export declare function calculateBuyCharges(price: number, quantity: number): OrderCharges;
export declare function calculateSellCharges(price: number, quantity: number): OrderCharges;
export declare function calculateRoundTripCharges(buyPrice: number, sellPrice: number, quantity: number): TradeCharges;
//# sourceMappingURL=ChargesCalculator.d.ts.map