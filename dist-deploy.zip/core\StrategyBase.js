"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StrategyBase = void 0;
class StrategyBase {
    constructor(kiteConnect, logger, config) {
        this._isInitialized = false;
        this.kiteConnect = kiteConnect;
        this.logger = logger;
        this.config = config;
        this.metrics = {
            isActive: false,
            isStreaming: false,
            totalTrades: 0,
            profitLoss: 0,
            winRate: 0,
            lastUpdateTime: new Date(),
            errorCount: 0,
            healthStatus: 'stopped'
        };
    }
    getConfig() {
        return { ...this.config };
    }
    getMetrics() {
        return { ...this.metrics };
    }
    getId() {
        return this.config.id;
    }
    getName() {
        return this.config.name;
    }
    isEnabled() {
        return this.config.enabled;
    }
    isRunning() {
        return this.metrics.isActive;
    }
    get isInitialized() {
        return this._isInitialized;
    }
    updateMetrics(updates) {
        this.metrics = {
            ...this.metrics,
            ...updates,
            lastUpdateTime: new Date()
        };
    }
    logStrategyEvent(level, message, data) {
        const logMessage = `[${this.config.name}] ${message}`;
        switch (level) {
            case 'info':
                this.logger.info(logMessage, data);
                break;
            case 'warn':
                this.logger.warn(logMessage, data);
                break;
            case 'error':
                this.logger.error(logMessage, data);
                this.metrics.errorCount++;
                break;
        }
    }
    setHealthStatus(status) {
        this.metrics.healthStatus = status;
        this.metrics.lastUpdateTime = new Date();
    }
}
exports.StrategyBase = StrategyBase;
//# sourceMappingURL=StrategyBase.js.map