import { StrategyBase, StrategyConfig, StrategyStatus } from '../../core/StrategyBase';
import { Logger } from '../../utils/Logger';
import { BreakoutPullbackStrategy } from './BreakoutPullbackStrategy';
export declare class BreakoutPullbackWrapper extends StrategyBase {
    private coreStrategy;
    constructor(kiteConnect: any, logger: Logger, config: StrategyConfig);
    initialize(): Promise<void>;
    start(): Promise<void>;
    stop(): Promise<void>;
    getStatus(): StrategyStatus;
    processMarketData(data: any): Promise<void>;
    private calculateTotalPnL;
    private calculateWinRate;
    getCoreStrategy(): BreakoutPullbackStrategy;
}
//# sourceMappingURL=BreakoutPullbackWrapper.d.ts.map