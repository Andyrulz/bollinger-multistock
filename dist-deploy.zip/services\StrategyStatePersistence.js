"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.StrategyStatePersistence = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const crypto = __importStar(require("crypto"));
const zlib = __importStar(require("zlib"));
const BreakoutPullbackStrategy_1 = require("../strategies/breakout-pullback/BreakoutPullbackStrategy");
class StrategyStatePersistence {
    constructor(logger) {
        this.version = '1.0.0';
        this.logger = logger;
        this.stateFilePath = path.join(__dirname, '../../data/strategy/strategy-state.json');
        this.backupFilePath = path.join(__dirname, '../../data/strategy/strategy-backup.json');
        this.candlesCachePath = path.join(__dirname, '../../data/strategy/candles-cache.json');
        const apiKey = process.env.ZERODHA_API_KEY || '';
        const apiSecret = process.env.ZERODHA_API_SECRET || '';
        this.encryptionKey = crypto.createHash('sha256')
            .update(apiKey + apiSecret + 'nifty_strategy_state_key')
            .digest('hex');
        this.ensureStrategyDirectory();
    }
    ensureStrategyDirectory() {
        const strategyDir = path.dirname(this.stateFilePath);
        if (!fs.existsSync(strategyDir)) {
            fs.mkdirSync(strategyDir, { recursive: true, mode: 0o700 });
            this.logger.info('📁 Created secure strategy state directory');
        }
    }
    encryptStateData(stateData) {
        const iv = crypto.randomBytes(16);
        const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(this.encryptionKey.slice(0, 32)), iv);
        let encrypted = cipher.update(JSON.stringify(stateData), 'utf8', 'hex');
        encrypted += cipher.final('hex');
        return {
            data: encrypted,
            iv: iv.toString('hex'),
            timestamp: new Date().toISOString(),
            version: this.version
        };
    }
    decryptStateData(encryptedFile) {
        try {
            const iv = Buffer.from(encryptedFile.iv, 'hex');
            const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(this.encryptionKey.slice(0, 32)), iv);
            let decrypted = decipher.update(encryptedFile.data, 'hex', 'utf8');
            decrypted += decipher.final('utf8');
            const stateData = JSON.parse(decrypted);
            this.convertStringDatesToObjects(stateData);
            return stateData;
        }
        catch (error) {
            this.logger.error('❌ Failed to decrypt strategy state data:', error);
            return null;
        }
    }
    convertStringDatesToObjects(stateData) {
        if (stateData.lastUpdateTime)
            stateData.lastUpdateTime = new Date(stateData.lastUpdateTime);
        if (stateData.lastPersistTime)
            stateData.lastPersistTime = new Date(stateData.lastPersistTime);
        if (stateData.lastProcessedOneMinuteCandleTime) {
            stateData.lastProcessedOneMinuteCandleTime = new Date(stateData.lastProcessedOneMinuteCandleTime);
        }
        if (stateData.currentContract?.expiry) {
            stateData.currentContract.expiry = new Date(stateData.currentContract.expiry);
        }
        stateData.candles?.forEach((candle) => {
            if (candle.timestamp)
                candle.timestamp = new Date(candle.timestamp);
        });
        stateData.oneMinuteCandles?.forEach((candle) => {
            if (candle.timestamp)
                candle.timestamp = new Date(candle.timestamp);
        });
        if (stateData.latestPivotHigh?.timestamp) {
            stateData.latestPivotHigh.timestamp = new Date(stateData.latestPivotHigh.timestamp);
        }
        if (stateData.latestPivotLow?.timestamp) {
            stateData.latestPivotLow.timestamp = new Date(stateData.latestPivotLow.timestamp);
        }
        if (stateData.latestBreakoutSignal?.timestamp) {
            stateData.latestBreakoutSignal.timestamp = new Date(stateData.latestBreakoutSignal.timestamp);
        }
        if (stateData.markingCandleState) {
            const mcs = stateData.markingCandleState;
            if (mcs.startTime)
                mcs.startTime = new Date(mcs.startTime);
            if (mcs.breakoutReference?.timestamp) {
                mcs.breakoutReference.timestamp = new Date(mcs.breakoutReference.timestamp);
            }
            if (mcs.currentMarkingCandle) {
                if (mcs.currentMarkingCandle.candle?.timestamp) {
                    mcs.currentMarkingCandle.candle.timestamp = new Date(mcs.currentMarkingCandle.candle.timestamp);
                }
                if (mcs.currentMarkingCandle.detectedAt) {
                    mcs.currentMarkingCandle.detectedAt = new Date(mcs.currentMarkingCandle.detectedAt);
                }
            }
        }
        if (stateData.tradeSetupRequest?.timestamp) {
            stateData.tradeSetupRequest.timestamp = new Date(stateData.tradeSetupRequest.timestamp);
        }
        if (stateData.lastProcessedCandleForBreakout) {
            stateData.lastProcessedCandleForBreakout = new Date(stateData.lastProcessedCandleForBreakout);
        }
        if (stateData.lastFiveMinuteBoundary) {
            stateData.lastFiveMinuteBoundary = new Date(stateData.lastFiveMinuteBoundary);
        }
    }
    validateStateIntegrity(state) {
        try {
            if (!state.version || state.version !== this.version) {
                this.logger.warn(`⚠️ State version mismatch: ${state.version} vs ${this.version}`);
                return false;
            }
            const maxAge = 24 * 60 * 60 * 1000;
            if (state.lastUpdateTime && (Date.now() - state.lastUpdateTime.getTime()) > maxAge) {
                this.logger.warn('⚠️ Strategy state is older than 24 hours');
                return false;
            }
            if (state.currentContract?.expiry && state.currentContract.expiry < new Date()) {
                this.logger.warn('⚠️ Contract has expired');
                return false;
            }
            if (state.candles && state.candles.length > 0) {
                for (let i = 1; i < state.candles.length; i++) {
                    const currentCandle = state.candles[i];
                    const prevCandle = state.candles[i - 1];
                    if (currentCandle && prevCandle && currentCandle.timestamp <= prevCandle.timestamp) {
                        this.logger.warn('⚠️ 5m candles are not chronologically ordered');
                        return false;
                    }
                }
            }
            if (state.currentVolumeSMA50 < 0 || state.currentVolumeSMA50 > 1000000000) {
                this.logger.warn(`⚠️ Volume SMA50 out of bounds: ${state.currentVolumeSMA50}`);
                return false;
            }
            if (!Object.values(BreakoutPullbackStrategy_1.TradeState).includes(state.tradeState)) {
                this.logger.warn(`⚠️ Invalid trade state: ${state.tradeState}`);
                return false;
            }
            this.logger.debug('✅ Strategy state integrity validation passed');
            return true;
        }
        catch (error) {
            this.logger.error('❌ Strategy state validation error:', error);
            return false;
        }
    }
    async saveStrategyState(state) {
        try {
            state.lastPersistTime = new Date();
            state.version = this.version;
            await this.createBackup();
            const encryptedData = this.encryptStateData(state);
            const tempFilePath = this.stateFilePath + '.tmp';
            fs.writeFileSync(tempFilePath, JSON.stringify(encryptedData, null, 2), { mode: 0o600 });
            fs.renameSync(tempFilePath, this.stateFilePath);
            this.logger.debug(`💾 Strategy state saved successfully (${this.getFileSizeKB(this.stateFilePath)} KB)`);
        }
        catch (error) {
            this.logger.error('❌ Failed to save strategy state:', error);
            throw error;
        }
    }
    async loadStrategyState() {
        try {
            let stateData = await this.loadStateFromFile(this.stateFilePath);
            if (!stateData) {
                this.logger.warn('⚠️ Primary state file failed, trying backup...');
                stateData = await this.loadStateFromFile(this.backupFilePath);
            }
            if (!stateData) {
                this.logger.info('📝 No valid strategy state found, will start fresh');
                return null;
            }
            if (!this.validateStateIntegrity(stateData)) {
                this.logger.warn('⚠️ State validation failed, will start fresh');
                return null;
            }
            this.logger.info(`🔄 Strategy state loaded successfully (${this.getFileSizeKB(this.stateFilePath)} KB)`);
            return stateData;
        }
        catch (error) {
            this.logger.error('❌ Failed to load strategy state:', error);
            return null;
        }
    }
    async loadStateFromFile(filePath) {
        try {
            if (!fs.existsSync(filePath)) {
                return null;
            }
            const fileContent = fs.readFileSync(filePath, 'utf8');
            const encryptedFile = JSON.parse(fileContent);
            return this.decryptStateData(encryptedFile);
        }
        catch (error) {
            this.logger.error(`❌ Failed to load state from ${filePath}:`, error);
            return null;
        }
    }
    async createBackup() {
        try {
            if (fs.existsSync(this.stateFilePath)) {
                fs.copyFileSync(this.stateFilePath, this.backupFilePath);
                this.logger.debug('📋 Strategy state backup created');
            }
        }
        catch (error) {
            this.logger.error('❌ Failed to create backup:', error);
        }
    }
    async saveCandlesCache(candles1m, candles5m, contract) {
        try {
            const cacheData = {
                candles1m,
                candles5m,
                timestamp: new Date(),
                contract
            };
            const compressed = zlib.gzipSync(JSON.stringify(cacheData));
            fs.writeFileSync(this.candlesCachePath, compressed, { mode: 0o600 });
            this.logger.debug(`💾 Candles cache saved (${candles5m.length} 5m candles, ${Math.round(compressed.length / 1024)} KB compressed)`);
        }
        catch (error) {
            this.logger.error('❌ Failed to save candles cache:', error);
        }
    }
    async loadCandlesCache() {
        try {
            if (!fs.existsSync(this.candlesCachePath)) {
                return null;
            }
            const compressed = fs.readFileSync(this.candlesCachePath);
            const decompressed = zlib.gunzipSync(compressed);
            const cacheData = JSON.parse(decompressed.toString());
            if (cacheData.timestamp)
                cacheData.timestamp = new Date(cacheData.timestamp);
            if (cacheData.contract?.expiry)
                cacheData.contract.expiry = new Date(cacheData.contract.expiry);
            cacheData.candles1m?.forEach(candle => {
                if (candle.timestamp)
                    candle.timestamp = new Date(candle.timestamp);
            });
            cacheData.candles5m?.forEach(candle => {
                if (candle.timestamp)
                    candle.timestamp = new Date(candle.timestamp);
            });
            this.logger.debug(`🔄 Candles cache loaded (${cacheData.candles5m?.length || 0} 5m candles)`);
            return cacheData;
        }
        catch (error) {
            this.logger.error('❌ Failed to load candles cache:', error);
            return null;
        }
    }
    getFileSizeKB(filePath) {
        try {
            const stats = fs.statSync(filePath);
            return Math.round(stats.size / 1024);
        }
        catch {
            return 0;
        }
    }
    async cleanupOldBackups() {
        try {
            const strategyDir = path.dirname(this.stateFilePath);
            const files = fs.readdirSync(strategyDir);
            files.forEach(file => {
                if (file.endsWith('.tmp')) {
                    const fullPath = path.join(strategyDir, file);
                    fs.unlinkSync(fullPath);
                    this.logger.debug(`🗑️ Cleaned up temp file: ${file}`);
                }
            });
        }
        catch (error) {
            this.logger.error('❌ Failed to cleanup old backups:', error);
        }
    }
    convertStrategyStateToPersistedFormat(strategyState) {
        return {
            isActive: strategyState.isActive,
            currentContract: strategyState.currentContract,
            tradeState: strategyState.tradeState,
            currentTradeId: strategyState.currentTradeId,
            tradeSetupRequest: strategyState.tradeSetupRequest,
            candles: [...strategyState.candles],
            latestPivotHigh: strategyState.latestPivotHigh,
            latestPivotLow: strategyState.latestPivotLow,
            latestBreakoutSignal: strategyState.latestBreakoutSignal,
            markingCandleState: { ...strategyState.markingCandleState },
            currentVolumeSMA50: strategyState.currentVolumeSMA50,
            lastCumulativeVolume: strategyState.lastCumulativeVolume,
            lastProcessedCandleForBreakout: strategyState.lastProcessedCandleForBreakout,
            lastFiveMinuteBoundary: strategyState.lastFiveMinuteBoundary,
            lastUpdateTime: new Date(),
            lastPersistTime: new Date(),
            version: this.version
        };
    }
}
exports.StrategyStatePersistence = StrategyStatePersistence;
//# sourceMappingURL=StrategyStatePersistence.js.map