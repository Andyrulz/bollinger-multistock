import { Logger } from './Logger';
export declare class InstrumentCache {
    private kiteConnect;
    private logger;
    private static CACHE_DIR;
    constructor(kiteConnect: any, logger: Logger);
    getNFOInstruments(): Promise<any[]>;
    private cleanupOldFiles;
}
//# sourceMappingURL=InstrumentCache.d.ts.map