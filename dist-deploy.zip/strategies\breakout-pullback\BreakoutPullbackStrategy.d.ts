import { Logger } from '../../utils/Logger';
import { TradeExecutionService } from './BreakoutPullbackExecutor';
export interface NiftyFuturesData {
    instrument_token: number;
    tradingsymbol: string;
    name: string;
    expiry: Date;
    strike: number;
    tick_size: number;
    lot_size: number;
    instrument_type: string;
    segment: string;
    exchange: string;
}
export interface TickData {
    instrument_token: number;
    last_price: number;
    volume: number;
    buy_quantity: number;
    sell_quantity: number;
    ohlc: {
        open: number;
        high: number;
        low: number;
        close: number;
    };
    change: number;
    last_trade_time: Date;
    exchange_timestamp: Date;
    timestamp?: Date;
    oi?: number;
    oi_day_high?: number;
    oi_day_low?: number;
}
export interface Candle {
    timestamp: Date;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
}
export interface PivotPoint {
    price: number;
    timestamp: Date;
    type: 'high' | 'low';
}
export interface BreakoutSignal {
    type: 'long_breakout' | 'short_breakout';
    price: number;
    timestamp: Date;
    volume: number;
    volumeMA50: number;
    pivotPrice: number;
    pivotType: 'high' | 'low';
    candleOpen: number;
    candleClose: number;
    candleHigh: number;
    candleLow: number;
    volumeRatio: number;
}
export interface MarkingCandle {
    candle: Candle;
    entryPrice: number;
    stopLoss: number;
    updateCount: number;
    detectedAt: Date;
}
export interface MarkingCandleState {
    isActive: boolean;
    breakoutReference: BreakoutSignal | null;
    startTime: Date | null;
    currentMarkingCandle: MarkingCandle | null;
    searchPhase: 'initial' | 'updates' | 'expired' | 'completed';
    barsProcessedSinceBreakout: number;
    maxUpdatesReached: boolean;
    timeExpired: boolean;
    tradeSkipped: boolean;
}
export declare enum TradeState {
    WAITING_FOR_BREAKOUT = "waiting_for_breakout",
    WAITING_FOR_ENTRY = "waiting_for_entry",
    IN_TRADE = "in_trade"
}
export interface DailyPivotLevels {
    pp: number;
    r1: number;
    r2: number;
    r3: number;
    s1: number;
    s2: number;
    s3: number;
}
export interface TradeSetupRequest {
    strategyId: string;
    direction: 'LONG' | 'SHORT';
    entryLevel: number;
    stopLossLevel: number;
    targetLevel: number;
    underlyingPrice: number;
    timestamp: Date;
    originalStopLossLevel: number;
    trailingTriggerLevel: number;
}
export interface StrategyState {
    isActive: boolean;
    currentContract?: NiftyFuturesData;
    livePrice?: TickData;
    lastUpdateTime?: Date;
    priceStreamingActive: boolean;
    breakoutDetectionActive: boolean;
    tradeState: TradeState;
    currentTradeId?: string;
    tradeSetupRequest?: TradeSetupRequest;
    candles: Candle[];
    latestPivotHigh?: PivotPoint | undefined;
    latestPivotLow?: PivotPoint | undefined;
    latestBreakoutSignal?: BreakoutSignal | undefined;
    markingCandleState: MarkingCandleState;
    currentVolumeSMA50: number;
    lastCumulativeVolume: number;
    lastProcessedCandleForBreakout?: Date | undefined;
    lastFiveMinuteBoundary?: Date | undefined;
}
export declare class BreakoutPullbackStrategy {
    private kiteConnect;
    private logger;
    private strategyState;
    private tradeExecutionService;
    private strategyPersistence;
    private kiteTicker;
    private isWebSocketActive;
    private webSocketReconnectAttempts;
    private maxWebSocketReconnectAttempts;
    private webSocketFailureCount;
    private lastWebSocketFailureTime;
    private webSocketSuccessCount;
    private totalWebSocketAttempts;
    private isWebSocketCircuitBreakerOpen;
    private nextWebSocketRetryTime;
    private isShuttingDown;
    private websocketConnectHandler;
    private websocketDisconnectHandler;
    private websocketErrorHandler;
    private websocketReconnectHandler;
    private websocketNoreconnectHandler;
    private websocketTicksHandler;
    private pricePollingInterval;
    private isManualStreamingActive;
    private pollingFailureCount;
    private lastPollingFailureTime;
    private pollingSuccessCount;
    private totalPollingAttempts;
    private isCircuitBreakerOpen;
    private nextRetryTime;
    private lastApiCallTime;
    private minTimeBetweenCalls;
    private dailyPivots;
    getStateLockStatus(): {
        activeLocks: string[];
        isTradeEntryLocked: boolean;
        isTradeExitLocked: boolean;
        queueStatus: {
            [key: string]: {
                locked: boolean;
                queueLength: number;
            };
        };
    };
    private activeApiCallsCount;
    private maxConcurrentCalls;
    private healthMonitoringInterval;
    private errorCounts;
    private lastErrorTime;
    private healthStatus;
    private breakoutDetectionInterval;
    private persistenceTimer;
    private isDirty;
    private readonly PERSISTENCE_INTERVAL;
    private currentOneMinuteCandle;
    private updateTimer;
    private lastProcessedFiveMinuteTime;
    private isProcessingFiveMinute;
    private isExecutingEntry;
    private isExecutingExit;
    constructor(kiteConnect: any, logger?: Logger);
    startStrategy(): Promise<void>;
    private initializeNiftyFuturesContract;
    private loadHistoricalCandles;
    private calculateDailyPivots;
    private calculateDailyPivotsFromMarketData;
    private initializeDailyPivots;
    private refreshRecentCandles;
    stopStrategy(): Promise<void>;
    dailyCleanup(): Promise<void>;
    private isNewTradingDay;
    startManualPriceStreaming(): Promise<void>;
    private shouldCircuitBreakerBlock;
    private recordPollingSuccess;
    private recordPollingFailure;
    private shouldThrottleApiCall;
    private fetchAndProcessLivePrice;
    private initializeWebSocket;
    private subscribeToInstrument;
    private processWebSocketTicks;
    private updateOptionPriceCache;
    private logWebSocketHealthStatus;
    private recordWebSocketSuccess;
    private recordWebSocketFailure;
    private startRestApiFallback;
    private stopRestApiFallback;
    stopManualPriceStreaming(): Promise<void>;
    getPollingHealthMetrics(): {
        isHealthy: boolean;
        successRate: number;
        totalAttempts: number;
        consecutiveFailures: number;
        circuitBreakerOpen: boolean;
        activeApiCalls: number;
        lastFailureTime: Date | null;
        nextRetryTime: Date | null;
        timeSinceLastSuccess: number | null;
    };
    logHealthStatus(): void;
    getStrategyState(): StrategyState;
    getLatestPivots(): {
        pivotHigh?: PivotPoint | undefined;
        pivotLow?: PivotPoint | undefined;
    };
    getDailyPivots(): DailyPivotLevels | null;
    triggerManualPivotDetection(): Promise<void>;
    getLivePrice(): TickData | undefined;
    isPriceStreamingActive(): boolean;
    isStrategyActive(): boolean;
    getCandleCount(): number;
    isMarketHours(): boolean;
    isBreakoutDetectionActive(): boolean;
    getLatestBreakoutSignal(): BreakoutSignal | undefined;
    getCurrentVolumeSMA50(): number;
    getWebSocketHealthStatus(): {
        websocketActive: boolean;
        connected: boolean;
        reconnectAttempts: number;
        lastDataReceived: string;
        timeSinceLastData: string;
        successRate: string;
        circuitBreakerOpen: boolean;
        totalAttempts: number;
        successCount: number;
    };
    getTradeExecutionService(): TradeExecutionService;
    selectATMOption(direction: 'LONG' | 'SHORT', niftyPrice: number): Promise<import("./BreakoutPullbackExecutor").OptionInstrument>;
    getSelectedInstrument(): any;
    getOptionPriceByToken(instrumentToken: string): Promise<number>;
    getInstrumentsStatus(): {
        loaded: boolean;
        count: number;
        loadedAt?: Date;
        sampleInstruments?: any[];
    };
    private readonly LOOKBACK_PERIOD;
    private readonly INITIAL_SEARCH_BARS;
    private readonly TIME_LIMIT_MINUTES;
    private readonly SL_CAP_RATIO;
    private startBreakoutDetection;
    private scheduleNext5MinutePivotDetection;
    private stopBreakoutDetection;
    private detectPivotPoints;
    private isPivotHigh;
    private isPivotLow;
    private logCurrentPivots;
    private processTick;
    private processFiveMinuteCandle;
    private startPersistenceTimer;
    private stopPersistenceTimer;
    private markStateAsDirty;
    private saveStateIfDirty;
    private saveStateAtomic;
    private saveStateImmediate;
    private validateAndRestoreState;
    private validateTradeStateSync;
    private validateHistoricalVolumeData;
    private updateVolumeSMA50;
    private checkForBreakout;
    private transitionToState;
    private performStateRecovery;
    private resetTradeSetup;
    private disableBreakoutDetection;
    private enableBreakoutDetection;
    private disableMarkingCandleSystem;
    private calculateCappedStopLoss;
    private calculateTargetLevel;
    private createTradeSetupRequest;
    private createAndStoreTradeSetup;
    private monitorTradeLevels;
    private checkEntryTrigger;
    private checkExitTriggers;
    private executeTradeEntry;
    private executeTradeExit;
    handleManualExit(): Promise<void>;
    private startMarkingCandleTracking;
    private processMarkingCandle;
    private checkForInitialMarkingCandle;
    private checkForMarkingCandleUpdate;
    private skipMarkingCandleTrade;
    private logMarkingCandleDetails;
    getMarkingCandleState(): MarkingCandleState;
    getTradeStateInfo(): {
        tradeState: TradeState;
        tradeSetupRequest?: TradeSetupRequest;
        currentTradeId?: string;
    };
    getMarkingCandleDebugInfo(): any;
    testManualPriceFetch(): Promise<void>;
    simulateDirectTestTick(): void;
    getCurrentCapital(): number;
    getActivePosition(): any;
    getDetailedPosition(): any;
    getTradeHistory(): any[];
    getTradingConfig(): any;
    getExecutionStatus(): any;
    updateTradingConfig(updates: any): void;
    initializeInstruments(): Promise<void>;
    private trackError;
    private resetErrorCount;
    getHealthReport(): any;
    private startHealthMonitoring;
    private stopHealthMonitoring;
}
//# sourceMappingURL=BreakoutPullbackStrategy.d.ts.map