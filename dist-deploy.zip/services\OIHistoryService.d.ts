import { Logger } from '../utils/Logger';
import { InstrumentCache } from '../utils/InstrumentCache';
export interface OIHistoryEntry {
    futuresOI: number;
    futuresSymbol: string;
    savedAt: string;
}
export interface OIHistoryData {
    savedAt: string;
    expiryDate: string;
    data: {
        [symbol: string]: OIHistoryEntry;
    };
}
export interface OIAnalysisResult {
    symbol: string;
    prevOI: number;
    currentOI: number;
    oiChangePercent: number;
    priceChangePercent: number;
    isCoiledSpring: boolean;
    smartMoneySignal: 'ACCUMULATION' | 'DISTRIBUTION' | 'SHORT_COVERING' | 'LONG_UNWINDING' | 'NONE' | 'CONFLICT';
    futuresSymbol: string;
}
export declare class OIHistoryService {
    private static OI_HISTORY_FILE;
    private kiteConnect;
    private logger;
    private instrumentCache;
    private MIN_OI_THRESHOLD;
    private OI_CHANGE_THRESHOLD;
    private PRICE_CHANGE_MAX;
    private yesterdayOI;
    private futuresTokenCache;
    constructor(kiteConnect: any, logger: Logger, instrumentCache: InstrumentCache);
    loadYesterdayOI(): Promise<boolean>;
    saveEndOfDayOI(): Promise<{
        success: boolean;
        count: number;
        errors: string[];
    }>;
    private buildFuturesTokenCache;
    private getCurrentMonthExpiry;
    private isSameMonth;
    isExpiryWeek(): boolean;
    analyzeStock(symbol: string, currentPrice: number, prevClose: number): Promise<OIAnalysisResult | null>;
    calculateSmartMoneyBonus(oiAnalysis: OIAnalysisResult | null, bias: 'LONG' | 'SHORT'): number;
    getFullAnalysis(): Promise<OIAnalysisResult[]>;
    getHistoryData(): OIHistoryData | null;
    hasValidData(): boolean;
}
//# sourceMappingURL=OIHistoryService.d.ts.map