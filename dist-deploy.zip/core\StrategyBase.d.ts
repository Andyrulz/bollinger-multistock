import { Logger } from '../utils/Logger';
export interface StrategyConfig {
    id: string;
    name: string;
    enabled: boolean;
    description: string;
    timeframe: string;
    instruments: string[];
    riskPerTrade: number;
    maxPositions: number;
    [key: string]: any;
}
export interface StrategyMetrics {
    isActive: boolean;
    isStreaming: boolean;
    totalTrades: number;
    profitLoss: number;
    winRate: number;
    lastTradeTime?: Date;
    lastUpdateTime: Date;
    errorCount: number;
    healthStatus: 'healthy' | 'warning' | 'error' | 'stopped';
}
export interface StrategyStatus {
    config: StrategyConfig;
    metrics: StrategyMetrics;
    currentPosition?: any;
    recentTrades: any[];
    allTrades?: any[];
    tradeStats?: any;
}
export declare abstract class StrategyBase {
    protected logger: Logger;
    protected kiteConnect: any;
    protected config: StrategyConfig;
    protected metrics: StrategyMetrics;
    protected _isInitialized: boolean;
    constructor(kiteConnect: any, logger: Logger, config: StrategyConfig);
    abstract initialize(): Promise<void>;
    abstract start(): Promise<void>;
    abstract stop(): Promise<void>;
    abstract getStatus(): StrategyStatus;
    abstract processMarketData(data: any): Promise<void>;
    getConfig(): StrategyConfig;
    getMetrics(): StrategyMetrics;
    getId(): string;
    getName(): string;
    isEnabled(): boolean;
    isRunning(): boolean;
    get isInitialized(): boolean;
    protected updateMetrics(updates: Partial<StrategyMetrics>): void;
    protected logStrategyEvent(level: 'info' | 'warn' | 'error', message: string, data?: any): void;
    protected setHealthStatus(status: 'healthy' | 'warning' | 'error' | 'stopped'): void;
}
//# sourceMappingURL=StrategyBase.d.ts.map