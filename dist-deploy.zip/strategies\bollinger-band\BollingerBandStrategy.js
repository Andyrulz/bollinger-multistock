"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.BollingerBandStrategy = void 0;
const path = __importStar(require("path"));
const ChargesCalculator_1 = require("../../utils/ChargesCalculator");
const StrategyBase_1 = require("../../core/StrategyBase");
const StrategyManager_1 = require("../../core/StrategyManager");
class BollingerBandStrategy extends StrategyBase_1.StrategyBase {
    calculateLots() {
        const lotsPerCapital = Math.floor(this.currentCapital / 40000);
        let lots = Math.max(1, lotsPerCapital);
        const expFlags = StrategyManager_1.StrategyManager.getExperimentalFlags();
        if (expFlags.enableVixLotReduction && this.vixChangePct < this.VIX_FALLING_THRESHOLD && lots > 1) {
            const reducedLots = Math.max(1, Math.floor(lots / 2));
            this.logger.info(`⚠️ VIX CAUTION: Reducing lots from ${lots} to ${reducedLots} (VIX change: ${(this.vixChangePct * 100).toFixed(1)}%)`);
            lots = reducedLots;
        }
        this.logger.debug('[LOT CALCULATION]', {
            currentCapital: this.currentCapital.toFixed(2),
            calculatedLots: lotsPerCapital,
            vixChange: `${(this.vixChangePct * 100).toFixed(1)}%`,
            finalLots: lots
        });
        return lots;
    }
    constructor(kiteConnect, logger, quoteManager, instrumentCache, config) {
        super(kiteConnect, logger, config);
        this.INITIAL_CAPITAL = 65000;
        this.NIFTY_50_TOKEN = 256265;
        this.INDIA_VIX_TOKEN = 264969;
        this.EXTREME_INTRADAY_RANGE_PCT = 0.015;
        this.WIDE_RANGE_DAY_THRESHOLD = 1.3;
        this.VIX_FALLING_THRESHOLD = -0.05;
        this.candleHistory = [];
        this.currentIndicators = null;
        this.dailyPivots = null;
        this.previousDayClose = 0;
        this.previousDayHigh = 0;
        this.previousDayLow = 0;
        this.pivotsLoaded = false;
        this.previousDayRangeRatio = 1.0;
        this.vixChangePct = 0;
        this.signalInstrumentToken = 0;
        this.signalSymbol = '';
        this.currentPosition = null;
        this.currentArmedSignal = null;
        this.currentFvgWatch = null;
        this.currentCandle = null;
        this.ltpPollingInterval = null;
        this.currentStockLTP = 0;
        this.candleCheckInterval = null;
        this.isProcessingShortExit = false;
        this.isProcessingLongExit = false;
        this.isExecutingExit = false;
        this.isClearingPosition = false;
        this.isExecutingLongEntry = false;
        this.isExecutingShortEntry = false;
        this.isPollingInProgress = false;
        this.lastPollingTime = null;
        this.consecutivePollingFailures = 0;
        this.MIN_POLLING_INTERVAL = 900;
        this.MAX_CONSECUTIVE_FAILURES = 5;
        this.isFetchingCandle = false;
        this.cachedCurrentPrice = 0;
        this.cachedUnrealizedPnL = 0;
        this.lastPriceUpdateTime = null;
        this.emergencyStopInterval = null;
        this.EMERGENCY_STOP_PERCENT = 5.0;
        this.EMERGENCY_POLL_INTERVAL_MS = 30000;
        this.PREMIUM_HARD_STOP_PCT = 0.08;
        this.healthMonitorInterval = null;
        this.dailyCacheRefreshTimer = null;
        this.optionRsiInterval = null;
        this.optionRsiInitialTimeout = null;
        this.OPTION_RSI_CHECK_INTERVAL = 15 * 60 * 1000;
        this.OPTION_RSI_CLIMAX_THRESHOLD = 85;
        this.OPTION_RSI_MICRO_GRACE_SECONDS = 60;
        this.rsiTrailActivated = false;
        this.rsiTrailFloorPrice = 0;
        this.rsiTrailActivationRsi = 0;
        this.rsiTrailPollingInterval = null;
        this.rsiTrail5MinCheckInterval = null;
        this.rsiTrail5MinInitialTimeout = null;
        this.RSI_TRAIL_ACTIVATION_THRESHOLD = 85;
        this.RSI_TRAIL_SECONDARY_EXIT_THRESHOLD = 75;
        this.RSI_TRAIL_POLL_INTERVAL_MS = 5000;
        this.RSI_CONFIRMATION_WINDOW = 2;
        this.RSI_CONFIRMATION_LONG_THRESHOLD = 62;
        this.RSI_CONFIRMATION_SHORT_THRESHOLD = 32;
        this.errorCounts = new Map();
        this.lastErrorTime = new Map();
        this.healthStatus = {
            dataStreamHealthy: true,
            executionHealthy: true,
            lastHeartbeat: new Date(),
            consecutiveErrors: 0,
            criticalErrorsToday: 0
        };
        this.currentCapital = 65000;
        this.tradeHistory = [];
        this.MAX_RETRY_ATTEMPTS = 10;
        this.CANDLE_RETRY_INTERVAL = 10000;
        this.TRADE_RETRY_DELAYS = [1000, 2000, 5000];
        this.masterCycleInterval = null;
        this.alignmentTimer = null;
        this.currentCyclePhase = 'waiting';
        this.lastSuccessfulFetchTime = null;
        this.lastReconciliationTime = null;
        this.CANDLE_FETCH_TIMEOUT = 45000;
        this.instrumentCache = instrumentCache;
        this.slotIndex = config.config?.strategyIndex ?? 0;
        const slotNumber = this.slotIndex + 1;
        this.BOLLINGER_DATA_FILE = path.join(__dirname, `../../data/bollinger-slot${slotNumber}.json`);
        this.logger.info(`📁 Slot ${slotNumber}: Using data file ${this.BOLLINGER_DATA_FILE} (stagger offset: ${this.slotIndex}s)`);
    }
    loadCapitalData() {
        try {
            const fs = require('fs');
            const path = require('path');
            if (fs.existsSync(this.BOLLINGER_DATA_FILE)) {
                const data = JSON.parse(fs.readFileSync(this.BOLLINGER_DATA_FILE, 'utf8'));
                this.currentCapital = data.capital || this.INITIAL_CAPITAL;
                this.tradeHistory = data.tradeHistory || [];
                if (data.activePosition) {
                    this.logger.info('🔄 Found persisted active position, will recover after initialization');
                }
                if (data.armedSignal) {
                    const restored = data.armedSignal;
                    restored.armedAtCandle = new Date(restored.armedAtCandle);
                    restored.armedAtWallClock = new Date(restored.armedAtWallClock);
                    const configSymbol = this.config.instruments?.[0];
                    if (configSymbol && restored.signalSymbol && restored.signalSymbol !== configSymbol) {
                        this.logger.warn(`⚠️ Discarding armed signal — symbol mismatch (armed for ${restored.signalSymbol}, slot now ${configSymbol})`);
                    }
                    else if ((Date.now() - restored.armedAtWallClock.getTime()) > 30 * 60 * 1000) {
                        const ageMin = ((Date.now() - restored.armedAtWallClock.getTime()) / 60000).toFixed(1);
                        this.logger.warn(`⚠️ Discarding armed signal — stale (${ageMin} min old, max 30 min)`);
                    }
                    else {
                        this.currentArmedSignal = restored;
                        this.logger.info(`🔄 Restored armed ${restored.direction} signal for ${restored.signalSymbol}`, {
                            candlesElapsedSinceArm: restored.candlesElapsedSinceArm,
                            pullbackSeen: restored.pullbackSeen,
                        });
                    }
                }
                if (data.fvgWatch) {
                    const fvgRestored = data.fvgWatch;
                    fvgRestored.armedAtCandle = new Date(fvgRestored.armedAtCandle);
                    fvgRestored.armedAtWallClock = new Date(fvgRestored.armedAtWallClock);
                    if (fvgRestored.fvg)
                        fvgRestored.fvg.impulseTimestamp = new Date(fvgRestored.fvg.impulseTimestamp);
                    if (fvgRestored.triggerCandleTimestamp)
                        fvgRestored.triggerCandleTimestamp = new Date(fvgRestored.triggerCandleTimestamp);
                    if (fvgRestored.lastProgressedCandleTs)
                        fvgRestored.lastProgressedCandleTs = new Date(fvgRestored.lastProgressedCandleTs);
                    const configSymbol = this.config.instruments?.[0];
                    if (configSymbol && fvgRestored.signalSymbol && fvgRestored.signalSymbol !== configSymbol) {
                        this.logger.warn(`⚠️ Discarding FVG watch — symbol mismatch (armed for ${fvgRestored.signalSymbol}, slot now ${configSymbol})`);
                    }
                    else if ((Date.now() - fvgRestored.armedAtWallClock.getTime()) > 60 * 60 * 1000) {
                        const ageMin = ((Date.now() - fvgRestored.armedAtWallClock.getTime()) / 60000).toFixed(1);
                        this.logger.warn(`⚠️ Discarding FVG watch — stale (${ageMin} min old, max 60 min)`);
                    }
                    else {
                        this.currentFvgWatch = fvgRestored;
                        this.logger.info(`🔄 Restored FVG watch for ${fvgRestored.signalSymbol}`, {
                            candlesScanned: fvgRestored.candlesScannedSinceArm,
                            hasFvg: !!fvgRestored.fvg,
                            hasTrigger: fvgRestored.trigger !== null,
                        });
                    }
                }
                this.logger.info('💰 Bollinger Band capital loaded', {
                    capital: this.currentCapital,
                    totalTrades: this.tradeHistory.length,
                    hasActivePosition: !!data.activePosition,
                    hasArmedSignal: !!this.currentArmedSignal,
                    hasFvgWatch: !!this.currentFvgWatch
                });
            }
            else {
                this.saveCapitalData();
                this.logger.info(`Bollinger Band capital initialized at Rs.${this.INITIAL_CAPITAL.toLocaleString()}`);
            }
        }
        catch (error) {
            this.logger.error('Error loading Bollinger Band capital data:', error);
            this.currentCapital = this.INITIAL_CAPITAL;
        }
    }
    saveCapitalData() {
        try {
            const fs = require('fs');
            const path = require('path');
            const dataDir = path.dirname(this.BOLLINGER_DATA_FILE);
            if (!fs.existsSync(dataDir)) {
                fs.mkdirSync(dataDir, { recursive: true });
            }
            const data = {
                capital: this.currentCapital,
                tradeHistory: this.tradeHistory,
                activePosition: this.currentPosition,
                armedSignal: this.currentArmedSignal,
                fvgWatch: this.currentFvgWatch,
                rsiTrailState: this.currentPosition ? {
                    activated: this.rsiTrailActivated,
                    floorPrice: this.rsiTrailFloorPrice,
                    activationRsi: this.rsiTrailActivationRsi
                } : null,
                lastUpdated: new Date().toISOString()
            };
            fs.writeFileSync(this.BOLLINGER_DATA_FILE, JSON.stringify(data, null, 2));
        }
        catch (error) {
            this.logger.error('Error saving Bollinger Band capital data:', error);
        }
    }
    async recoverActivePosition() {
        try {
            const fs = require('fs');
            if (!fs.existsSync(this.BOLLINGER_DATA_FILE)) {
                this.logger.info('📭 No persisted state found');
                return;
            }
            const data = JSON.parse(fs.readFileSync(this.BOLLINGER_DATA_FILE, 'utf8'));
            if (!data.activePosition) {
                this.logger.info('📭 No active position to recover');
                return;
            }
            const position = data.activePosition;
            if (!position.instrument || !position.quantity || !position.type) {
                this.logger.warn('⚠️ Invalid position data found, skipping recovery', position);
                return;
            }
            const savedTradingsymbol = position.instrument?.tradingsymbol || '';
            const savedInstrumentName = position.instrument?.name || '';
            const extractedBaseSymbol = savedTradingsymbol.match(/^([A-Z][A-Z&-]*)/)?.[1];
            const savedBaseSymbol = savedInstrumentName || extractedBaseSymbol;
            const currentConfigSymbol = this.config.instruments?.[0];
            if (savedBaseSymbol && currentConfigSymbol && savedBaseSymbol !== currentConfigSymbol) {
                this.logger.warn(`⚠️ ZOMBIE POSITION DETECTED in Slot!`);
                this.logger.warn(`   Saved Position Symbol: ${savedTradingsymbol} (Base: ${savedBaseSymbol})`);
                this.logger.warn(`   Current Slot Expects: ${currentConfigSymbol}`);
                this.logger.warn(`   ⚠️ PURGING ghost position from memory. Capital preserved.`);
                this.logger.warn(`   ⚠️ ACTION REQUIRED: Manually verify/close ${savedTradingsymbol} in broker terminal!`);
                this.logger.warn(`   Capital (₹${data.capital}) retained for P&L continuity.`);
                this.currentPosition = null;
                this.currentArmedSignal = null;
                this.currentFvgWatch = null;
                this.saveCapitalData();
                return;
            }
            this.currentPosition = position;
            if (this.currentPosition) {
                this.currentPosition.entryTime = new Date(this.currentPosition.entryTime);
                if (this.currentPosition.entryCandleTimestamp) {
                    this.currentPosition.entryCandleTimestamp = new Date(this.currentPosition.entryCandleTimestamp);
                }
                if (this.currentPosition.timeDecayTrailing?.lastHighTime) {
                    this.currentPosition.timeDecayTrailing.lastHighTime = new Date(this.currentPosition.timeDecayTrailing.lastHighTime);
                }
                if (this.currentPosition.breakoutValidation?.breakoutCandleTimestamp) {
                    this.currentPosition.breakoutValidation.breakoutCandleTimestamp = new Date(this.currentPosition.breakoutValidation.breakoutCandleTimestamp);
                }
            }
            if (data.rsiTrailState && this.currentPosition) {
                this.rsiTrailActivated = data.rsiTrailState.activated || false;
                this.rsiTrailFloorPrice = data.rsiTrailState.floorPrice || 0;
                this.rsiTrailActivationRsi = data.rsiTrailState.activationRsi || 0;
                if (this.rsiTrailActivated) {
                    this.logger.info(`🔄 RSI Trail state recovered: activated=true, floor=₹${this.rsiTrailFloorPrice.toFixed(2)}, activationRsi=${this.rsiTrailActivationRsi.toFixed(1)}`);
                }
            }
            this.logger.info('✅ Active position recovered from disk', {
                symbol: position.instrument?.tradingsymbol,
                type: position.type,
                quantity: position.quantity,
                entryPrice: position.entryPrice,
                entryTime: position.entryTime,
                entryCandleLow: position.entryCandleLow,
                entryCandleHigh: position.entryCandleHigh,
                trailingSL: position.trailingSL,
                highestPremium: position.highestPremium,
                timeDecayTrailing: position.timeDecayTrailing
                    ? `Last high: ${new Date(position.timeDecayTrailing.lastHighTime).toLocaleTimeString()}`
                    : 'N/A (no time-decay tracking or LONG position)'
            });
            try {
                this.logger.info('🔄 Starting position monitoring after recovery...');
                await this.startPositionMonitoring();
                if (this.currentPosition?.entryStockPrice) {
                    this.startEmergencyStopMonitoring();
                }
                else {
                    this.logger.warn('⚠️ Cannot start Emergency Hard Stop - no entry stock price in recovered position');
                }
                this.startOptionRsiMonitoring();
                this.startRsiTrail5MinMonitoring();
                if (this.rsiTrailActivated && this.rsiTrailFloorPrice > 0) {
                    this.startRsiTrailLivePolling();
                }
                this.logger.info('✅ Position monitoring restarted successfully after recovery');
            }
            catch (monitoringError) {
                this.logger.error('❌ CRITICAL: Failed to restart position monitoring after recovery:', monitoringError);
                this.logger.error('🚨 Position exists but has NO exit protection - this is a critical risk!');
                try {
                    this.logger.warn('⚠️ Attempting emergency position closure due to monitoring failure...');
                    await this.forceClosePosition('MONITORING_RESTART_FAILED');
                    this.logger.info('✅ Emergency position closure successful');
                }
                catch (closeError) {
                    this.logger.error('❌ Emergency position closure also failed:', closeError);
                    this.logger.error('� MANUAL INTERVENTION REQUIRED: Position exists without monitoring!');
                }
                throw new Error(`Position recovery failed: ${monitoringError instanceof Error ? monitoringError.message : String(monitoringError)}`);
            }
        }
        catch (error) {
            this.logger.error('❌ Error recovering active position:', error);
        }
    }
    async initialize() {
        this.logger.info('BollingerBandStrategy: Starting initialization...');
        try {
            this.loadCapitalData();
            const { token, symbol } = await this.getSignalInstrumentToken();
            this.signalInstrumentToken = token;
            this.signalSymbol = symbol;
            this.logger.info(`🎯 Signal Instrument: ${this.signalSymbol} (Token: ${this.signalInstrumentToken})`);
            await this.loadHistoricalDataWithFallback();
            await this.calculateDailyPivotsWithFallback();
            await this.loadVixData();
            this.updateTechnicalIndicators();
            this.scheduleDailyCacheRefresh();
            await this.recoverActivePosition();
            const validation = this.validateCapitalConsistency();
            if (!validation.valid) {
                this.logger.warn('⚠️ Capital validation failed - manual review recommended', {
                    difference: validation.difference.toFixed(2)
                });
            }
            this._isInitialized = true;
            this.logger.info('BollingerBandStrategy: Initialization complete', {
                signalInstrument: this.signalSymbol,
                instrumentToken: this.signalInstrumentToken,
                candleCount: this.candleHistory.length,
                hasPivots: !!this.dailyPivots,
                hasIndicators: !!this.currentIndicators,
                hasActivePosition: !!this.currentPosition
            });
        }
        catch (error) {
            this.logger.error('BollingerBandStrategy: Initialization failed', error);
            throw error;
        }
    }
    async start() {
        if (!this._isInitialized) {
            throw new Error('Strategy must be initialized before starting');
        }
        this.logger.info('BollingerBandStrategy: Starting strategy...');
        this.startHealthMonitoring();
        this.startRealTimeMonitoring();
        this.scheduleEODExit();
        this.startPositionReconciliation();
        this.metrics.isActive = true;
        this.metrics.healthStatus = 'healthy';
        this.updateMetrics({ isActive: true, healthStatus: 'healthy' });
        this.logger.info('BollingerBandStrategy: Strategy started successfully with health monitoring');
    }
    async stop() {
        this.logger.info('BollingerBandStrategy: Stopping strategy...');
        this.stopPositionMonitoring();
        this.stopEmergencyStopMonitoring();
        this.stopOptionRsiMonitoring();
        this.stopRsiTrailMonitoring();
        this.stopRealTimeMonitoring();
        this.stopCandleRetryMechanism();
        this.cancelEODExit();
        this.stopPositionReconciliation();
        if (this.healthMonitorInterval) {
            clearInterval(this.healthMonitorInterval);
            this.healthMonitorInterval = null;
        }
        if (this.dailyCacheRefreshTimer) {
            clearTimeout(this.dailyCacheRefreshTimer);
            this.dailyCacheRefreshTimer = null;
        }
        if (this.currentPosition) {
            this.logger.warn('⚠️ Strategy stopping with ACTIVE POSITION - position will be preserved for recovery');
            this.logger.warn(`   Position: ${this.currentPosition.instrument?.tradingsymbol} | Entry: ₹${this.currentPosition.entryPrice}`);
        }
        this.saveCapitalData();
        this.logger.info('💾 Strategy data saved to disk on stop()');
        this.metrics.isActive = false;
        this.metrics.healthStatus = 'stopped';
        this.updateMetrics({ isActive: false, healthStatus: 'stopped' });
        this.logger.info('BollingerBandStrategy: Strategy stopped successfully');
    }
    async clearActivePosition() {
        if (this.isClearingPosition) {
            this.logger.warn('⚠️ Position clear already in progress, skipping');
            return;
        }
        this.isClearingPosition = true;
        try {
            if (!this.currentPosition) {
                this.logger.warn('⚠️ No active position to clear');
                return;
            }
            const positionSymbol = this.currentPosition.instrument?.tradingsymbol;
            const entryPrice = this.currentPosition.entryPrice;
            const entryTime = this.currentPosition.entryTime;
            const quantity = this.currentPosition.quantity;
            const entryOrderId = this.currentPosition.entryOrderId;
            const positionType = this.currentPosition.type;
            this.logger.info('🧹 Manually clearing active position', {
                symbol: positionSymbol,
                type: positionType,
                entryPrice: entryPrice,
                quantity: quantity
            });
            let exitPrice = entryPrice;
            let exitOrderId = `MANUAL_CLEAR_${Date.now()}`;
            let exitTime = new Date();
            try {
                const exitOrder = await this.fetchExitOrderFromBroker(positionSymbol, entryOrderId, entryTime, quantity);
                if (exitOrder) {
                    exitPrice = exitOrder.average_price || exitOrder.price || entryPrice;
                    exitOrderId = exitOrder.order_id;
                    exitTime = new Date(exitOrder.order_timestamp);
                    if (exitOrder.quantity !== quantity) {
                        this.logger.warn(`⚠️ Quantity mismatch detected!`, {
                            entryQty: quantity,
                            exitQty: exitOrder.quantity,
                            warning: 'Using this exit order but quantities differ'
                        });
                    }
                    this.logger.info('✅ Found actual exit order from broker', {
                        exitOrderId: exitOrderId,
                        exitPrice: exitPrice,
                        exitTime: exitTime.toLocaleString(),
                        exitQty: exitOrder.quantity
                    });
                }
                else {
                    this.logger.warn('⚠️ Could not find exit order from broker, using entry price for P&L');
                }
            }
            catch (error) {
                this.logger.error('❌ Error fetching exit order from broker:', error);
                this.logger.warn('⚠️ Will use entry price for P&L (P&L = 0)');
            }
            const totalQuantity = quantity * this.currentPosition.instrument.lot_size;
            const pnl = (exitPrice - entryPrice) * totalQuantity;
            this.currentCapital += pnl;
            const tradeRecord = {
                tradeId: `BB_MANUAL_CLEAR_${Date.now()}`,
                entryOrderId: entryOrderId,
                exitOrderId: exitOrderId,
                instrument: this.currentPosition.instrument,
                direction: positionType,
                quantity: totalQuantity,
                entryPrice: entryPrice,
                exitPrice: exitPrice,
                entryTime: entryTime,
                exitTime: exitTime,
                pnl: pnl,
                exitReason: 'MANUAL_CLEAR_BROKER_AUTO_SQUAREOFF',
                status: 'CLOSED',
                strategy: 'BOLLINGER_BAND'
            };
            this.tradeHistory.push(tradeRecord);
            this.logger.info('📊 Trade recorded via manual clear', {
                exitPrice: exitPrice.toFixed(2),
                pnl: pnl.toFixed(2),
                newCapital: this.currentCapital.toFixed(2),
                totalTrades: this.tradeHistory.length
            });
            const baseSymbol = this.signalSymbol || positionSymbol;
            if (baseSymbol) {
                StrategyManager_1.StrategyManager.recordSymbolExitStatic(baseSymbol);
                this.logger.info(`🔒 Cooldown applied for ${baseSymbol} (30 min block after manual/broker exit)`);
            }
            this.currentPosition = null;
            this.stopPositionMonitoring();
            this.stopRsiTrailMonitoring();
            this.saveCapitalData();
            this.cachedCurrentPrice = 0;
            this.cachedUnrealizedPnL = 0;
            this.lastPriceUpdateTime = null;
            this.updateMetrics({
                profitLoss: this.metrics.profitLoss,
                healthStatus: 'healthy',
                lastTradeTime: new Date()
            });
            this.logger.info('✅ Active position cleared successfully with P&L recorded');
        }
        catch (error) {
            this.logger.error('❌ Error clearing active position:', error);
            throw error;
        }
        finally {
            this.isClearingPosition = false;
        }
    }
    async fetchExitOrderFromBroker(symbol, entryOrderId, entryTime, entryQuantity) {
        try {
            const orders = await this.kiteConnect.getOrders();
            let exitCandidates = orders.filter((order) => {
                const orderTime = new Date(order.order_timestamp);
                return order.tradingsymbol === symbol
                    && order.transaction_type === 'SELL'
                    && order.status === 'COMPLETE'
                    && orderTime > entryTime;
            });
            if (exitCandidates.length === 0) {
                this.logger.warn(`⚠️ No SELL orders found for ${symbol} after ${entryTime.toLocaleTimeString()}`);
                return null;
            }
            if (entryQuantity) {
                const exactMatch = exitCandidates.filter((order) => order.quantity === entryQuantity);
                if (exactMatch.length > 0) {
                    exitCandidates = exactMatch;
                    this.logger.info(`✅ Found ${exactMatch.length} quantity-matching exit orders (qty=${entryQuantity})`);
                }
                else {
                    this.logger.warn(`⚠️ No exact quantity match found. Using closest by time.`);
                }
            }
            exitCandidates.sort((a, b) => new Date(a.order_timestamp).getTime() - new Date(b.order_timestamp).getTime());
            const exitOrder = exitCandidates[0];
            this.logger.info(`✅ Selected exit order (${exitCandidates.length} candidates after filters)`, {
                orderId: exitOrder.order_id,
                qty: exitOrder.quantity,
                price: exitOrder.average_price,
                time: exitOrder.order_timestamp,
                tag: exitOrder.tag || 'NONE (manual)',
                quantityMatch: entryQuantity ? (exitOrder.quantity === entryQuantity ? '✅ MATCH' : '⚠️ MISMATCH') : 'N/A'
            });
            return exitOrder;
        }
        catch (error) {
            this.logger.error('Error fetching orders from broker:', error);
            return null;
        }
    }
    async dailyCleanup() {
        this.logger.info('?? Starting daily cleanup for new trading day...');
        try {
            this.candleHistory = [];
            this.currentIndicators = null;
            this.dailyPivots = null;
            this.previousDayHigh = 0;
            this.previousDayLow = 0;
            this.previousDayClose = 0;
            this.pivotsLoaded = false;
            this.currentCandle = null;
            this.currentStockLTP = 0;
            this.currentPosition = null;
            this.saveCapitalData();
            this.logger.info("💾 Position cleared from disk after daily cleanup");
            this.cachedCurrentPrice = 0;
            this.cachedUnrealizedPnL = 0;
            this.lastPriceUpdateTime = null;
            this.healthStatus = {
                dataStreamHealthy: true,
                executionHealthy: true,
                lastHeartbeat: new Date(),
                consecutiveErrors: 0,
                criticalErrorsToday: 0
            };
            this.errorCounts.clear();
            this.lastErrorTime.clear();
            this.logger.info('? Daily cleanup completed - ready for new trading day');
        }
        catch (error) {
            this.logger.error('? Error during daily cleanup:', error);
            throw error;
        }
    }
    getEntryAnalysis() {
        const price = this.getLastCompletedCandleClose();
        const indicators = this.currentIndicators;
        const pivots = this.dailyPivots;
        if (!indicators || !pivots || price === 0) {
            return {
                long: { conditions: [], metCount: 0, totalCount: 4, strength: 'NO_DATA' },
                short: { conditions: [], metCount: 0, totalCount: 4, strength: 'NO_DATA' }
            };
        }
        const { rsi, supertrend, bollingerBands } = indicators;
        const { r1, r2, s1, pp } = pivots;
        const longConditions = [
            {
                name: 'Price > BB Upper',
                met: price > bollingerBands.upper,
                detail: `₹${price.toFixed(2)} ${price > bollingerBands.upper ? '>' : '<='} ₹${bollingerBands.upper.toFixed(2)}`
            },
            {
                name: 'RSI 68-85',
                met: rsi >= 68 && rsi <= 85,
                detail: `${rsi.toFixed(2)} ${rsi >= 68 && rsi <= 85 ? 'in range' : 'out of range'}`
            },
            {
                name: 'Supertrend UP',
                met: supertrend.trend === 'UP',
                detail: supertrend.trend
            },
            {
                name: 'Above R1 or PDH',
                met: price > r1 || price > this.previousDayHigh,
                detail: `₹${price.toFixed(2)} ${price > r1 ? '> R1(' + r1.toFixed(2) + ')' : price > this.previousDayHigh ? '> PDH(' + this.previousDayHigh.toFixed(2) + ')' : '< R1(' + r1.toFixed(2) + ') & PDH(' + this.previousDayHigh.toFixed(2) + ')'}`
            }
        ];
        const shortConditions = [
            {
                name: 'Price < BB Lower',
                met: price < bollingerBands.lower,
                detail: `₹${price.toFixed(2)} ${price < bollingerBands.lower ? '<' : '>='} ₹${bollingerBands.lower.toFixed(2)}`
            },
            {
                name: 'RSI 15-40',
                met: rsi >= 15 && rsi <= 40,
                detail: `${rsi.toFixed(2)} ${rsi >= 15 && rsi <= 40 ? 'in range' : 'out of range'}`
            },
            {
                name: 'Supertrend DOWN',
                met: supertrend.trend === 'DOWN',
                detail: supertrend.trend
            },
            {
                name: 'Below S1 or PDL',
                met: price < s1 || price < this.previousDayLow,
                detail: `₹${price.toFixed(2)} ${price < s1 ? '< S1(' + s1.toFixed(2) + ')' : price < this.previousDayLow ? '< PDL(' + this.previousDayLow.toFixed(2) + ')' : '> S1(' + s1.toFixed(2) + ') & PDL(' + this.previousDayLow.toFixed(2) + ')'}`
            }
        ];
        const longMetCount = longConditions.filter(c => c.met).length;
        const shortMetCount = shortConditions.filter(c => c.met).length;
        const getStrength = (met, total) => {
            if (met === total)
                return 'SIGNAL';
            if (met >= total - 1)
                return 'STRONG';
            if (met >= total / 2)
                return 'WEAK';
            return 'NO_SIGNAL';
        };
        return {
            long: {
                conditions: longConditions,
                metCount: longMetCount,
                totalCount: 4,
                strength: getStrength(longMetCount, 4)
            },
            short: {
                conditions: shortConditions,
                metCount: shortMetCount,
                totalCount: 4,
                strength: getStrength(shortMetCount, 4)
            }
        };
    }
    getSlotPerformanceMetrics() {
        const trades = this.tradeHistory;
        const totalTrades = trades.length;
        const closedTrades = trades.filter(t => t.pnl !== undefined).length;
        const openTrades = totalTrades - closedTrades;
        const wins = trades.filter(t => (t.pnl || 0) > 0).length;
        const losses = trades.filter(t => (t.pnl || 0) <= 0 && t.pnl !== undefined).length;
        const winRate = closedTrades > 0 ? (wins / closedTrades) * 100 : 0;
        const totalPnL = trades.reduce((sum, t) => sum + (t.pnl || 0), 0);
        const winningTrades = trades.filter(t => (t.pnl || 0) > 0);
        const losingTrades = trades.filter(t => (t.pnl || 0) < 0);
        const totalWins = winningTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
        const totalLosses = Math.abs(losingTrades.reduce((sum, t) => sum + (t.pnl || 0), 0));
        const avgWin = wins > 0 ? totalWins / wins : 0;
        const avgLoss = losses > 0 ? totalLosses / losses : 0;
        const profitFactor = totalLosses > 0 ? totalWins / totalLosses : totalWins > 0 ? Infinity : 0;
        const roi = ((this.currentCapital - this.INITIAL_CAPITAL) / this.INITIAL_CAPITAL) * 100;
        return {
            totalTrades,
            closedTrades,
            openTrades,
            wins,
            losses,
            winRate,
            totalPnL,
            avgWin,
            avgLoss,
            profitFactor,
            roi,
            initialCapital: this.INITIAL_CAPITAL,
            currentCapital: this.currentCapital
        };
    }
    getStatus() {
        return {
            config: this.getConfig(),
            metrics: {
                ...this.getMetrics(),
                profitLoss: this.getTotalPnL(),
                isStreaming: false
            },
            recentTrades: this.tradeHistory.slice(-10),
            allTrades: this.getTradeHistory(),
            tradeStats: this.getTradingStats(),
            currentLots: this.calculateLots(),
            capitalAllocation: this.INITIAL_CAPITAL,
            currentCapital: this.currentCapital,
            totalTrades: this.tradeHistory.length,
            indicators: this.currentIndicators,
            pivots: this.dailyPivots,
            previousDayHigh: this.previousDayHigh,
            previousDayLow: this.previousDayLow,
            candleCount: this.candleHistory.length,
            currentStockPrice: this.getLastCompletedCandleClose(),
            signalSymbol: this.signalSymbol,
            currentCandle: this.currentCandle,
            entryAnalysis: this.getEntryAnalysis(),
            slotMetrics: this.getSlotPerformanceMetrics(),
            positionInfo: this.currentPosition ? {
                type: this.currentPosition.type,
                instrument: this.currentPosition.instrument,
                quantity: this.currentPosition.quantity,
                entryPrice: this.currentPosition.entryPrice,
                entryTime: this.currentPosition.entryTime,
                currentPrice: this.cachedCurrentPrice,
                unrealizedPnL: this.cachedUnrealizedPnL,
                lastUpdated: this.lastPriceUpdateTime,
                tradingSymbol: this.currentPosition.instrument.tradingsymbol,
                trailingSL: this.currentPosition.trailingSL,
                highestPremium: this.currentPosition.highestPremium,
                minutesSinceEntry: (Date.now() - this.currentPosition.entryTime.getTime()) / 60000,
                minutesSinceLastHigh: this.currentPosition.timeDecayTrailing
                    ? (Date.now() - this.currentPosition.timeDecayTrailing.lastHighTime.getTime()) / 60000
                    : (Date.now() - this.currentPosition.entryTime.getTime()) / 60000,
                currentTrailPercent: this.currentPosition.trailingSL && this.currentPosition.highestPremium
                    ? ((1 - this.currentPosition.trailingSL / this.currentPosition.highestPremium) * 100)
                    : 12,
                lastHighTime: this.currentPosition.timeDecayTrailing?.lastHighTime,
                entryCandleLow: this.currentPosition.entryCandleLow,
                entryCandleHigh: this.currentPosition.entryCandleHigh,
                strikeType: this.currentPosition.instrument?.strikeType || 'unknown',
                strike: this.currentPosition.instrument?.strike,
                lotSize: this.currentPosition.instrument?.lot_size,
                cushion: this.currentPosition.trailingSL && this.cachedCurrentPrice > 0
                    ? (this.cachedCurrentPrice - this.currentPosition.trailingSL)
                    : null,
                cushionPercent: (this.currentPosition.trailingSL && this.cachedCurrentPrice > 0)
                    ? ((this.cachedCurrentPrice - this.currentPosition.trailingSL) / this.cachedCurrentPrice * 100)
                    : null,
                profitFromEntry: this.cachedCurrentPrice > 0
                    ? (this.cachedCurrentPrice - this.currentPosition.entryPrice)
                    : 0,
                profitPercent: (this.currentPosition.entryPrice > 0 && this.cachedCurrentPrice > 0)
                    ? ((this.cachedCurrentPrice - this.currentPosition.entryPrice) / this.currentPosition.entryPrice * 100)
                    : 0,
                underlyingSafetyThreshold: this.currentPosition.type === 'LONG'
                    ? Math.max(this.currentPosition.entryCandleLow || 0, this.currentIndicators?.bollingerBands?.middle || 0)
                    : this.currentPosition.entryCandleHigh || 0,
                rsiTrail: {
                    activated: this.rsiTrailActivated,
                    floorPrice: this.rsiTrailFloorPrice,
                    activationRsi: this.rsiTrailActivationRsi,
                    isPolling: this.rsiTrailPollingInterval !== null,
                    is5MinMonitoring: this.rsiTrail5MinCheckInterval !== null || this.rsiTrail5MinInitialTimeout !== null
                }
            } : null
        };
    }
    hasActivePosition() {
        return this.currentPosition !== null;
    }
    isStale(direction) {
        const result = this.checkBreakoutStaleness(direction);
        this.logger.debug(`[STALE CHECK] ${this.signalSymbol} ${direction}: isStale=${result.isStale}, consecutive=${result.consecutiveCount}`);
        return result.isStale;
    }
    async processMarketData(data) {
        this.logger.debug('Processing market data:', data);
    }
    async getLiveOptionPremium(instrumentToken) {
        if (!instrumentToken)
            return 0;
        try {
            const quote = await this.kiteConnect.getQuote([instrumentToken.toString()]);
            const data = quote[instrumentToken.toString()];
            if (data && data.last_price && data.last_price > 0) {
                return data.last_price;
            }
            return 0;
        }
        catch (error) {
            this.logger.error(`Error fetching live premium for token ${instrumentToken}:`, error);
            return 0;
        }
    }
    async calculateUnrealizedPnL() {
        if (!this.currentPosition)
            return 0;
        const currentPrice = await this.getLiveOptionPremium(this.currentPosition.instrument.instrument_token);
        if (currentPrice === 0)
            return 0;
        const priceDiff = currentPrice - this.currentPosition.entryPrice;
        const totalQuantity = this.currentPosition.quantity * this.currentPosition.instrument.lot_size;
        return priceDiff * totalQuantity;
    }
    calculateRSI(candles, period = 10) {
        if (candles.length < period + 1)
            return 50;
        const changes = [];
        for (let i = 1; i < candles.length; i++) {
            const currentCandle = candles[i];
            const prevCandle = candles[i - 1];
            if (currentCandle && prevCandle) {
                changes.push(currentCandle.close - prevCandle.close);
            }
        }
        if (changes.length < period)
            return 50;
        let avgGain = 0;
        let avgLoss = 0;
        for (let i = 0; i < period; i++) {
            const change = changes[i];
            if (change !== undefined) {
                if (change > 0) {
                    avgGain += change;
                }
                else {
                    avgLoss += Math.abs(change);
                }
            }
        }
        avgGain /= period;
        avgLoss /= period;
        for (let i = period; i < changes.length; i++) {
            const change = changes[i];
            if (change !== undefined) {
                const gain = change > 0 ? change : 0;
                const loss = change < 0 ? Math.abs(change) : 0;
                avgGain = (avgGain * (period - 1) + gain) / period;
                avgLoss = (avgLoss * (period - 1) + loss) / period;
            }
        }
        if (avgLoss === 0)
            return 100;
        if (avgGain === 0)
            return 0;
        const rs = avgGain / avgLoss;
        return 100 - (100 / (1 + rs));
    }
    calculateOptionRSI(candles) {
        const period = 14;
        if (candles.length < period + 1) {
            this.logger.debug(`Option RSI: Insufficient data (${candles.length}/${period + 1} candles)`);
            return -1;
        }
        const changes = [];
        for (let i = 1; i < candles.length; i++) {
            const curr = candles[i];
            const prev = candles[i - 1];
            if (curr && prev) {
                changes.push(curr.close - prev.close);
            }
        }
        if (changes.length < period)
            return -1;
        let avgGain = 0;
        let avgLoss = 0;
        for (let i = 0; i < period; i++) {
            const change = changes[i] || 0;
            if (change > 0)
                avgGain += change;
            else
                avgLoss += Math.abs(change);
        }
        avgGain /= period;
        avgLoss /= period;
        for (let i = period; i < changes.length; i++) {
            const change = changes[i] || 0;
            if (change > 0) {
                avgGain = (avgGain * (period - 1) + change) / period;
                avgLoss = (avgLoss * (period - 1)) / period;
            }
            else {
                avgGain = (avgGain * (period - 1)) / period;
                avgLoss = (avgLoss * (period - 1) + Math.abs(change)) / period;
            }
        }
        if (avgLoss === 0)
            return 100;
        const rs = avgGain / avgLoss;
        return 100 - (100 / (1 + rs));
    }
    async fetchOption15MinCandles() {
        if (!this.currentPosition)
            return [];
        const optionToken = this.currentPosition.instrument.instrument_token;
        const optionSymbol = this.currentPosition.instrument.tradingsymbol;
        try {
            const toDate = new Date();
            const fromDate = new Date(toDate);
            fromDate.setDate(fromDate.getDate() - 5);
            this.logger.debug(`Fetching 15-min option data: ${optionSymbol} from ${fromDate.toISOString().split('T')[0]}`);
            const historicalData = await this.kiteConnect.getHistoricalData(optionToken, '15minute', fromDate, toDate);
            if (!historicalData || historicalData.length < 20) {
                this.logger.warn(`Insufficient 15-min option data: ${historicalData?.length || 0} candles`);
                return [];
            }
            const candles = historicalData.map((kiteCandle) => ({
                timestamp: new Date(kiteCandle.date),
                open: kiteCandle.open,
                high: kiteCandle.high,
                low: kiteCandle.low,
                close: kiteCandle.close,
                volume: kiteCandle.volume || 0,
                isComplete: true
            }));
            this.logger.debug(`Fetched ${candles.length} 15-min option candles for RSI calculation`);
            return candles;
        }
        catch (error) {
            this.logger.error(`Failed to fetch 15-min option data for ${optionSymbol}:`, error);
            return [];
        }
    }
    async fetchOption5MinCandles() {
        if (!this.currentPosition)
            return [];
        const optionToken = this.currentPosition.instrument.instrument_token;
        const optionSymbol = this.currentPosition.instrument.tradingsymbol;
        try {
            const toDate = new Date();
            const fromDate = new Date(toDate);
            fromDate.setDate(fromDate.getDate() - 5);
            this.logger.debug(`Fetching 5-min option data: ${optionSymbol} from ${fromDate.toISOString().split('T')[0]}`);
            const historicalData = await this.kiteConnect.getHistoricalData(optionToken, '5minute', fromDate, toDate);
            if (!historicalData || historicalData.length < 20) {
                this.logger.warn(`Insufficient 5-min option data: ${historicalData?.length || 0} candles`);
                return [];
            }
            const candles = historicalData.map((kiteCandle) => ({
                timestamp: new Date(kiteCandle.date),
                open: kiteCandle.open,
                high: kiteCandle.high,
                low: kiteCandle.low,
                close: kiteCandle.close,
                volume: kiteCandle.volume || 0,
                isComplete: true
            }));
            this.logger.debug(`Fetched ${candles.length} 5-min option candles for RSI Trail calculation`);
            return candles;
        }
        catch (error) {
            this.logger.error(`Failed to fetch 5-min option data for ${optionSymbol}:`, error);
            return [];
        }
    }
    calculateBollingerBands(candles, period = 20, stdDevMultiplier = 2) {
        if (candles.length < period) {
            const lastClose = candles[candles.length - 1]?.close || 0;
            return {
                upper: lastClose * 1.02,
                middle: lastClose,
                lower: lastClose * 0.98
            };
        }
        const closes = candles.slice(-period).map(c => c.close);
        const sma = closes.reduce((sum, close) => sum + close, 0) / period;
        const variance = closes.reduce((sum, close) => sum + Math.pow(close - sma, 2), 0) / period;
        const stdDev = Math.sqrt(variance);
        return {
            upper: sma + (stdDev * stdDevMultiplier),
            middle: sma,
            lower: sma - (stdDev * stdDevMultiplier)
        };
    }
    checkBreakoutStaleness(direction) {
        if (this.candleHistory.length < 3) {
            return { isStale: false, consecutiveCount: 0 };
        }
        const checkCandleMeetsCondition = (candleIndex) => {
            const historicalSlice = this.candleHistory.slice(0, candleIndex + 1);
            if (historicalSlice.length < 20)
                return false;
            const candle = historicalSlice[historicalSlice.length - 1];
            if (!candle)
                return false;
            const bb = this.calculateBollingerBands(historicalSlice, 20, 2);
            const rsi = this.calculateRSI(historicalSlice, 10);
            const close = candle.close;
            if (direction === 'LONG') {
                return close > bb.upper && rsi >= 68;
            }
            else {
                return close < bb.lower && rsi <= 40;
            }
        };
        const idx1 = this.candleHistory.length - 1;
        const idx2 = this.candleHistory.length - 2;
        const idx3 = this.candleHistory.length - 3;
        const MAX_CANDLE_GAP_MS = 6 * 60 * 1000;
        const isConsecutiveSession = (newerIdx, olderIdx) => {
            const newer = this.candleHistory[newerIdx];
            const older = this.candleHistory[olderIdx];
            if (!newer || !older)
                return false;
            return (newer.timestamp.getTime() - older.timestamp.getTime()) <= MAX_CANDLE_GAP_MS;
        };
        const candle1Meets = checkCandleMeetsCondition(idx1);
        const candle2Meets = checkCandleMeetsCondition(idx2);
        const candle3Meets = checkCandleMeetsCondition(idx3);
        const gap1to2 = isConsecutiveSession(idx1, idx2);
        const gap2to3 = isConsecutiveSession(idx2, idx3);
        let consecutiveCount = 0;
        if (candle1Meets) {
            consecutiveCount = 1;
            if (candle2Meets && gap1to2) {
                consecutiveCount = 2;
                if (candle3Meets && gap2to3) {
                    consecutiveCount = 3;
                }
            }
        }
        const isStale = consecutiveCount >= 3;
        this.logger.debug(`[STALENESS CHECK] ${direction}: Candle1=${candle1Meets}, Candle2=${candle2Meets}, Candle3=${candle3Meets}, Gap1-2=${gap1to2}, Gap2-3=${gap2to3}, Consecutive=${consecutiveCount}, IsStale=${isStale}`);
        return { isStale, consecutiveCount };
    }
    calculateSupertrend(candles, period = 10, multiplier = 2) {
        if (candles.length < Math.max(period + 1, 3)) {
            const lastClose = candles[candles.length - 1]?.close || 0;
            return { value: lastClose, trend: 'UP' };
        }
        const supertrendValues = [];
        for (let i = period; i < candles.length; i++) {
            const currentCandles = candles.slice(0, i + 1);
            const atr = this.calculateATR(currentCandles, period);
            const candle = candles[i];
            const prevCandle = i > 0 ? candles[i - 1] : null;
            if (!candle)
                continue;
            const hl2 = (candle.high + candle.low) / 2;
            const basicUB = hl2 + (multiplier * atr);
            const basicLB = hl2 - (multiplier * atr);
            let finalUB, finalLB, trend, supertrend;
            if (supertrendValues.length === 0) {
                finalUB = basicUB;
                finalLB = basicLB;
                trend = candle.close <= finalUB ? -1 : 1;
                supertrend = trend === 1 ? finalLB : finalUB;
            }
            else {
                const prev = supertrendValues[supertrendValues.length - 1];
                const prevClose = prevCandle?.close || candle.close;
                if (!prev) {
                    finalUB = basicUB;
                    finalLB = basicLB;
                    trend = candle.close <= finalUB ? -1 : 1;
                    supertrend = trend === 1 ? finalLB : finalUB;
                }
                else {
                    finalUB = (basicUB < prev.finalUB || prevClose > prev.finalUB) ? basicUB : prev.finalUB;
                    finalLB = (basicLB > prev.finalLB || prevClose < prev.finalLB) ? basicLB : prev.finalLB;
                    if (prev.trend === 1) {
                        if (candle.close < prev.supertrend) {
                            trend = -1;
                        }
                        else {
                            trend = 1;
                        }
                    }
                    else {
                        if (candle.close > prev.supertrend) {
                            trend = 1;
                        }
                        else {
                            trend = -1;
                        }
                    }
                    supertrend = trend === 1 ? finalLB : finalUB;
                }
            }
            supertrendValues.push({
                close: candle.close,
                basicUB,
                basicLB,
                finalUB,
                finalLB,
                trend,
                supertrend
            });
        }
        if (supertrendValues.length === 0) {
            const lastClose = candles[candles.length - 1]?.close || 0;
            return { value: lastClose, trend: 'UP' };
        }
        const lastST = supertrendValues[supertrendValues.length - 1];
        if (!lastST) {
            const lastClose = candles[candles.length - 1]?.close || 0;
            return { value: lastClose, trend: 'UP' };
        }
        const debugCount = Math.min(3, supertrendValues.length);
        const recentValues = supertrendValues.slice(-debugCount);
        this.logger.info('Supertrend calculation debug (TradingView compatible)', {
            parameters: { period, multiplier },
            totalCandles: candles.length,
            lastCandle: {
                timestamp: candles[candles.length - 1]?.timestamp,
                ohlc: {
                    open: candles[candles.length - 1]?.open.toFixed(2),
                    high: candles[candles.length - 1]?.high.toFixed(2),
                    low: candles[candles.length - 1]?.low.toFixed(2),
                    close: candles[candles.length - 1]?.close.toFixed(2)
                }
            },
            recentSupertrend: recentValues.map(st => ({
                close: st.close.toFixed(2),
                basicUB: st.basicUB.toFixed(2),
                basicLB: st.basicLB.toFixed(2),
                finalUB: st.finalUB.toFixed(2),
                finalLB: st.finalLB.toFixed(2),
                trend: st.trend === 1 ? 'UP' : 'DOWN',
                supertrend: st.supertrend.toFixed(2)
            })),
            finalResult: {
                value: lastST.supertrend.toFixed(2),
                trend: lastST.trend === 1 ? 'UP' : 'DOWN'
            }
        });
        return {
            value: lastST.supertrend,
            trend: lastST.trend === 1 ? 'UP' : 'DOWN'
        };
    }
    calculateATR(candles, period) {
        if (candles.length < period + 1)
            return 1;
        const trueRanges = [];
        for (let i = 1; i < candles.length; i++) {
            const currentCandle = candles[i];
            const prevCandle = candles[i - 1];
            if (currentCandle && prevCandle) {
                const high = currentCandle.high;
                const low = currentCandle.low;
                const prevClose = prevCandle.close;
                const tr1 = high - low;
                const tr2 = Math.abs(high - prevClose);
                const tr3 = Math.abs(low - prevClose);
                trueRanges.push(Math.max(tr1, tr2, tr3));
            }
        }
        if (trueRanges.length < period)
            return 1;
        let atr = trueRanges.slice(0, period).reduce((sum, tr) => sum + tr, 0) / period;
        for (let i = period; i < trueRanges.length; i++) {
            const currentTR = trueRanges[i];
            if (currentTR !== undefined) {
                atr = (atr * (period - 1) + currentTR) / period;
            }
        }
        return atr;
    }
    calculateDailyPivots(previousDayOHLC) {
        const { high, low, close } = previousDayOHLC;
        const pp = (high + low + close) / 3;
        return {
            pp,
            r1: (2 * pp) - low,
            s1: (2 * pp) - high,
            r2: pp + (high - low),
            s2: pp - (high - low),
            r3: high + 2 * (pp - low),
            s3: low - 2 * (high - pp)
        };
    }
    floorTo5Min(date) {
        const FIVE_MIN_MS = 5 * 60 * 1000;
        return new Date(Math.floor(date.getTime() / FIVE_MIN_MS) * FIVE_MIN_MS);
    }
    async loadHistoricalData() {
        this.logger.info(`Loading historical ${this.signalSymbol} candle data...`);
        const maxLookbackDays = 14;
        const requiredCandles = 25;
        for (let lookbackDays = 7; lookbackDays <= maxLookbackDays; lookbackDays++) {
            try {
                const toDate = new Date();
                const fromDate = new Date(toDate);
                fromDate.setDate(fromDate.getDate() - lookbackDays);
                this.logger.info(`Fetching ${this.signalSymbol} historical data: ${fromDate.toISOString().split('T')[0]} to ${toDate.toISOString().split('T')[0]}`);
                const historicalData = await this.kiteConnect.getHistoricalData(this.signalInstrumentToken, '5minute', fromDate, toDate);
                if (historicalData && historicalData.length >= requiredCandles) {
                    this.candleHistory = historicalData.map((kiteCandle) => ({
                        timestamp: this.floorTo5Min(new Date(kiteCandle.date)),
                        open: kiteCandle.open,
                        high: kiteCandle.high,
                        low: kiteCandle.low,
                        close: kiteCandle.close,
                        volume: kiteCandle.volume || 0
                    }));
                    this.logger.info(`✅ ${this.signalSymbol} historical data loaded: ${this.candleHistory.length} candles`);
                    return;
                }
                else {
                    this.logger.warn(`Insufficient ${this.signalSymbol} data with ${lookbackDays} days: ${historicalData?.length || 0} candles`);
                }
            }
            catch (error) {
                this.logger.error(`Failed to fetch ${this.signalSymbol} historical data for ${lookbackDays} days:`, error);
                if (error && typeof error === 'object') {
                    this.logger.error(`Error details: ${JSON.stringify(error, null, 2)}`);
                }
            }
        }
        throw new Error(`Failed to load sufficient ${this.signalSymbol} historical data after ${maxLookbackDays} days`);
    }
    async loadHistoricalDataWithFallback() {
        this.logger.info(`Loading ${this.signalSymbol} historical data with production fallback...`);
        try {
            await this.loadHistoricalData();
            this.logger.info('? Historical data loaded successfully via API');
            return;
        }
        catch (error) {
            this.logger.warn('?? API historical data failed, trying cache fallback', error);
            try {
                await this.loadCachedHistoricalData();
                this.logger.info('? Historical data loaded from cache');
                return;
            }
            catch (cacheError) {
                this.logger.error('? Both API and cache failed - cannot initialize strategy safely', {
                    apiError: error instanceof Error ? error.message : String(error),
                    cacheError: cacheError instanceof Error ? cacheError.message : String(cacheError)
                });
                throw new Error('Failed to load historical data from both API and cache. Strategy cannot start safely without proper market data.');
            }
        }
    }
    async loadCachedHistoricalData() {
        const fs = require('fs');
        const path = require('path');
        const cacheFile = path.join(__dirname, '../../data/bollinger-historical-cache.json');
        if (!fs.existsSync(cacheFile)) {
            throw new Error('No cached historical data available');
        }
        const cacheData = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
        const cacheAge = Date.now() - new Date(cacheData.timestamp).getTime();
        const maxCacheAge = 7 * 24 * 60 * 60 * 1000;
        if (cacheAge > maxCacheAge) {
            throw new Error('Cached data too old');
        }
        this.candleHistory = cacheData.candles.map((candle) => ({
            timestamp: this.floorTo5Min(new Date(candle.timestamp)),
            open: candle.open,
            high: candle.high,
            low: candle.low,
            close: candle.close,
            volume: candle.volume
        }));
        this.logger.info(`Loaded ${this.candleHistory.length} candles from cache`);
    }
    async cacheHistoricalData() {
        if (this.candleHistory.length === 0)
            return;
        const fs = require('fs');
        const path = require('path');
        const cacheFile = path.join(__dirname, '../../data/bollinger-historical-cache.json');
        try {
            const dataDir = path.dirname(cacheFile);
            if (!fs.existsSync(dataDir)) {
                fs.mkdirSync(dataDir, { recursive: true });
            }
            const cacheData = {
                timestamp: new Date().toISOString(),
                candles: this.candleHistory,
                symbol: this.signalSymbol,
                timeframe: '5min'
            };
            fs.writeFileSync(cacheFile, JSON.stringify(cacheData, null, 2));
            this.logger.info(`📦 ${this.signalSymbol} historical data cached successfully`);
        }
        catch (error) {
            this.logger.error('? Failed to cache historical data:', error);
        }
    }
    scheduleDailyCacheRefresh() {
        const now = new Date();
        const refreshTime = new Date();
        refreshTime.setHours(15, 25, 0, 0);
        if (now >= refreshTime) {
            refreshTime.setDate(refreshTime.getDate() + 1);
            if (refreshTime.getDay() === 6)
                refreshTime.setDate(refreshTime.getDate() + 2);
            if (refreshTime.getDay() === 0)
                refreshTime.setDate(refreshTime.getDate() + 1);
        }
        const timeUntilRefresh = refreshTime.getTime() - now.getTime();
        this.logger.info(`?? Scheduled daily cache refresh at: ${refreshTime.toLocaleString()}`);
        if (this.dailyCacheRefreshTimer) {
            clearTimeout(this.dailyCacheRefreshTimer);
        }
        this.dailyCacheRefreshTimer = setTimeout(async () => {
            try {
                this.logger.info('?? Daily cache refresh starting at 3:25 PM...');
                if (this.candleHistory.length > 0) {
                    await this.cacheHistoricalData();
                    this.logger.info('? Daily cache refresh completed successfully');
                }
                else {
                    this.logger.warn('?? No candle data available for cache refresh');
                }
                this.scheduleDailyCacheRefresh();
            }
            catch (error) {
                this.logger.error('? Daily cache refresh failed:', error);
                this.scheduleDailyCacheRefresh();
            }
        }, timeUntilRefresh);
    }
    async calculateDailyPivotsWithFallback() {
        try {
            await this.calculateDailyPivotsFromMarketData();
            this.logger.info(`✅ ${this.signalSymbol} daily pivots calculated from market data`);
        }
        catch (error) {
            this.logger.warn(`⚠️ Failed to fetch ${this.signalSymbol} pivot data, using fallback`, error);
            this.calculateFallbackPivots();
        }
    }
    calculateFallbackPivots() {
        this.logger.warn(`⚠️ Using placeholder pivot levels for ${this.signalSymbol} - will update when market data available`);
        const approximateOHLC = {
            high: 1000,
            low: 990,
            close: 995
        };
        this.dailyPivots = this.calculateDailyPivots(approximateOHLC);
        this.previousDayHigh = approximateOHLC.high;
        this.previousDayLow = approximateOHLC.low;
        this.logger.info(`⚠️ Using placeholder pivot levels for ${this.signalSymbol} pre-market operation`, this.dailyPivots);
    }
    async calculateDailyPivotsFromMarketData() {
        this.logger.info(`Calculating ${this.signalSymbol} daily pivot levels...`);
        try {
            const toDate = new Date();
            toDate.setDate(toDate.getDate() - 1);
            const fromDate = new Date(toDate);
            fromDate.setDate(fromDate.getDate() - 10);
            this.logger.info(`Fetching ${this.signalSymbol} daily pivot data`, {
                fromDate: fromDate.toISOString().split('T')[0],
                toDate: toDate.toISOString().split('T')[0]
            });
            const dailyData = await this.kiteConnect.getHistoricalData(this.signalInstrumentToken, 'day', fromDate, toDate);
            if (!dailyData || dailyData.length < 1) {
                throw new Error(`No daily data available for ${this.signalSymbol} pivot calculation`);
            }
            const previousDay = dailyData[dailyData.length - 1];
            this.previousDayClose = previousDay.close;
            this.previousDayHigh = previousDay.high;
            this.previousDayLow = previousDay.low;
            this.pivotsLoaded = true;
            if (dailyData.length >= 6) {
                const recentDays = dailyData.slice(-6);
                const prevDayForRatio = recentDays[recentDays.length - 1];
                const adrDays = recentDays.slice(0, -1);
                const avgDailyRange = adrDays.reduce((sum, d) => sum + (d.high - d.low), 0) / adrDays.length;
                const previousDayRange = prevDayForRatio.high - prevDayForRatio.low;
                this.previousDayRangeRatio = avgDailyRange > 0 ? previousDayRange / avgDailyRange : 1.0;
                this.logger.info(`📊 Previous day range ratio: ${this.previousDayRangeRatio.toFixed(2)} (${previousDayRange.toFixed(2)} / ADR ${avgDailyRange.toFixed(2)})`, {
                    isWideDay: this.previousDayRangeRatio > this.WIDE_RANGE_DAY_THRESHOLD,
                    isNarrowDay: this.previousDayRangeRatio < 0.7
                });
            }
            this.dailyPivots = this.calculateDailyPivots({
                high: previousDay.high,
                low: previousDay.low,
                close: previousDay.close
            });
            this.logger.info(`${this.signalSymbol} daily candles:`, {
                totalCandles: dailyData.length,
                dateRange: dailyData.length > 0 ? {
                    oldest: dailyData[0].date,
                    newest: dailyData[dailyData.length - 1].date
                } : 'No data',
                allDates: dailyData.map((d) => d.date).slice(-5)
            });
            this.logger.info(`${this.signalSymbol} daily pivots calculated`, {
                symbol: this.signalSymbol,
                date: previousDay.date,
                forTradingDay: 'Using most recent completed trading day for pivot calculation',
                pp: this.dailyPivots.pp.toFixed(2),
                r1: this.dailyPivots.r1.toFixed(2),
                s1: this.dailyPivots.s1.toFixed(2),
                previousDayHigh: this.previousDayHigh.toFixed(2),
                previousDayLow: this.previousDayLow.toFixed(2)
            });
        }
        catch (error) {
            this.logger.error(`Failed to calculate ${this.signalSymbol} daily pivots:`, error);
            throw error;
        }
    }
    async loadVixData() {
        try {
            const toDate = new Date();
            toDate.setDate(toDate.getDate() - 1);
            const fromDate = new Date(toDate);
            fromDate.setDate(fromDate.getDate() - 10);
            const vixData = await this.kiteConnect.getHistoricalData(this.INDIA_VIX_TOKEN, 'day', fromDate, toDate);
            if (vixData && vixData.length >= 2) {
                const latest = vixData[vixData.length - 1];
                const prior = vixData[vixData.length - 2];
                this.vixChangePct = (latest.close - prior.close) / prior.close;
                this.logger.info(`📊 VIX regime data loaded`, {
                    latestVix: latest.close.toFixed(2),
                    priorVix: prior.close.toFixed(2),
                    changePct: `${(this.vixChangePct * 100).toFixed(1)}%`,
                    isVixFalling: this.vixChangePct < this.VIX_FALLING_THRESHOLD
                });
            }
            else {
                this.logger.warn('⚠️ Insufficient VIX data for regime filter, using neutral default');
            }
        }
        catch (error) {
            this.logger.warn('⚠️ Failed to load VIX data for regime filter:', error);
            this.vixChangePct = 0;
        }
    }
    async getNiftyIntradayRange() {
        try {
            const now = new Date();
            const todayStart = new Date(now);
            todayStart.setHours(9, 15, 0, 0);
            const niftyData = await this.kiteConnect.getHistoricalData(this.NIFTY_50_TOKEN, '5minute', todayStart, now);
            if (!niftyData || niftyData.length === 0)
                return 0;
            let sessionHigh = -Infinity;
            let sessionLow = Infinity;
            const sessionOpen = niftyData[0].open;
            for (const candle of niftyData) {
                if (candle.high > sessionHigh)
                    sessionHigh = candle.high;
                if (candle.low < sessionLow)
                    sessionLow = candle.low;
            }
            return sessionOpen > 0 ? (sessionHigh - sessionLow) / sessionOpen : 0;
        }
        catch (error) {
            this.logger.warn('⚠️ Failed to fetch NIFTY intraday range:', error);
            return 0;
        }
    }
    async getSignalInstrumentToken() {
        const stockSymbol = this.config.instruments?.[0];
        if (!stockSymbol) {
            throw new Error('No stock symbol configured in config.instruments[0]. Strategy needs a signal instrument.');
        }
        this.logger.info(`🔍 Looking up instrument token for stock: ${stockSymbol}`);
        try {
            const nseInstruments = await this.kiteConnect.getInstruments('NSE');
            const stockInstrument = nseInstruments.find((inst) => inst.tradingsymbol === stockSymbol &&
                inst.instrument_type === 'EQ');
            if (stockInstrument) {
                this.logger.info(`✅ Found stock instrument: ${stockSymbol}`, {
                    token: stockInstrument.instrument_token,
                    tradingsymbol: stockInstrument.tradingsymbol,
                    name: stockInstrument.name,
                    instrument_type: stockInstrument.instrument_type,
                    exchange: stockInstrument.exchange
                });
                return {
                    token: stockInstrument.instrument_token,
                    symbol: stockSymbol
                };
            }
            const stockInstrumentCaseInsensitive = nseInstruments.find((inst) => inst.tradingsymbol?.toUpperCase() === stockSymbol.toUpperCase() &&
                inst.instrument_type === 'EQ');
            if (stockInstrumentCaseInsensitive) {
                this.logger.info(`✅ Found stock instrument (case-insensitive): ${stockSymbol}`, {
                    token: stockInstrumentCaseInsensitive.instrument_token,
                    tradingsymbol: stockInstrumentCaseInsensitive.tradingsymbol,
                    name: stockInstrumentCaseInsensitive.name
                });
                return {
                    token: stockInstrumentCaseInsensitive.instrument_token,
                    symbol: stockInstrumentCaseInsensitive.tradingsymbol
                };
            }
            throw new Error(`Stock ${stockSymbol} not found in NSE instruments`);
        }
        catch (error) {
            this.logger.error(`Failed to get instrument token for ${stockSymbol}:`, error);
            throw new Error(`Cannot initialize strategy without signal instrument token for ${stockSymbol}`);
        }
    }
    updateTechnicalIndicators() {
        if (this.candleHistory.length === 0)
            return;
        this.currentIndicators = {
            rsi: this.calculateRSI(this.candleHistory, 10),
            supertrend: this.calculateSupertrend(this.candleHistory, 10, 2),
            bollingerBands: this.calculateBollingerBands(this.candleHistory, 20, 2)
        };
        this.logger.info('[BOLLINGER] Technical indicators updated', {
            rsi: this.currentIndicators.rsi,
            supertrend: this.currentIndicators.supertrend.trend,
            bb_upper: this.currentIndicators.bollingerBands.upper,
            bb_middle: this.currentIndicators.bollingerBands.middle,
            bb_lower: this.currentIndicators.bollingerBands.lower
        });
    }
    startRealTimeMonitoring() {
        this.logger.info('🔄 Starting simplified 5-minute monitoring (5th minute entry only - no prediction)...');
        this.stopRealTimeMonitoring();
        const now = new Date();
        const currentMinutes = now.getMinutes();
        const currentSeconds = now.getSeconds();
        const currentMilliseconds = now.getMilliseconds();
        const nextInterval = Math.ceil(currentMinutes / 5) * 5;
        const minutesUntilNext = (nextInterval === 60) ? (60 - currentMinutes) : (nextInterval - currentMinutes);
        const targetSecond = 5;
        let millisecondsUntilAlignment;
        if (minutesUntilNext === 0) {
            if (currentSeconds < targetSecond) {
                millisecondsUntilAlignment = (targetSecond - currentSeconds) * 1000 - currentMilliseconds;
            }
            else {
                millisecondsUntilAlignment = (5 * 60 - currentSeconds + targetSecond) * 1000 - currentMilliseconds;
            }
        }
        else {
            millisecondsUntilAlignment = (minutesUntilNext * 60 - currentSeconds + targetSecond) * 1000 - currentMilliseconds;
        }
        const slotStaggerMs = this.slotIndex * 1000;
        millisecondsUntilAlignment += slotStaggerMs;
        const alignmentTime = new Date(now.getTime() + millisecondsUntilAlignment);
        this.logger.info(`⏰ Current time: ${now.toLocaleTimeString()}.${now.getMilliseconds()}`);
        this.logger.info(`⏰ Slot ${this.slotIndex + 1} aligning to: ${alignmentTime.toLocaleTimeString()}.${alignmentTime.getMilliseconds()} (${(millisecondsUntilAlignment / 1000).toFixed(1)}s, includes ${this.slotIndex}s stagger)`);
        this.alignmentTimer = setTimeout(() => {
            this.alignmentTimer = null;
            const triggerTime = new Date();
            this.logger.info(`✅ Slot ${this.slotIndex + 1} alignment triggered at ${triggerTime.toLocaleTimeString()}.${triggerTime.getMilliseconds()}`);
            this.startMasterCycle();
        }, millisecondsUntilAlignment);
        if (this.currentPosition) {
            this.startPositionMonitoring().catch(error => {
                this.logger.error('Failed to start position monitoring:', error);
            });
        }
    }
    stopRealTimeMonitoring() {
        if (this.ltpPollingInterval) {
            clearInterval(this.ltpPollingInterval);
            this.ltpPollingInterval = null;
        }
        if (this.candleCheckInterval) {
            clearInterval(this.candleCheckInterval);
            this.candleCheckInterval = null;
        }
        if (this.alignmentTimer) {
            clearTimeout(this.alignmentTimer);
            this.alignmentTimer = null;
            this.logger.info('🔒 Alignment timer cancelled - preventing zombie strategy');
        }
        if (this.masterCycleInterval) {
            clearInterval(this.masterCycleInterval);
            this.masterCycleInterval = null;
        }
        this.lastSuccessfulFetchTime = null;
        this.lastReconciliationTime = null;
        this.currentCyclePhase = 'waiting';
        if (!this.currentPosition) {
        }
        this.logger.info('Real-time monitoring stopped');
    }
    startMasterCycle() {
        if (this.masterCycleInterval) {
            this.logger.warn('⚠️ Master cycle already running, ignoring duplicate start request');
            return;
        }
        const cycleStartTime = new Date();
        this.logger.info(`🔄 Starting Bollinger Band strategy master cycle at ${cycleStartTime.toLocaleTimeString()}.${cycleStartTime.getMilliseconds()}`);
        const fetchCandleIfMarketOpen = async () => {
            const wasDisrupted = this.detectMasterCycleDisruption();
            const now = new Date();
            const hours = now.getHours();
            const minutes = now.getMinutes();
            const currentTime = hours * 60 + minutes;
            const marketStart = 9 * 60 + 15;
            const marketEnd = 15 * 60 + 30;
            if (currentTime >= marketStart && currentTime <= marketEnd) {
                if (this.isFetchingCandle) {
                    this.logger.warn('[BOLLINGER] ⚠️ Previous candle fetch still in progress, skipping this cycle');
                    return;
                }
                this.isFetchingCandle = true;
                const fetchTimeout = setTimeout(() => {
                    if (this.isFetchingCandle) {
                        this.logger.error(`[BOLLINGER] 🚨 TIMEOUT: Candle fetch exceeded ${this.CANDLE_FETCH_TIMEOUT}ms - forcing flag reset`);
                        this.isFetchingCandle = false;
                        this.healthStatus.dataStreamHealthy = false;
                        this.updateMetrics({ healthStatus: 'error' });
                    }
                }, this.CANDLE_FETCH_TIMEOUT);
                try {
                    const fetchTime = new Date();
                    this.logger.info(`[BOLLINGER] ⏰ Fetching candle at ${fetchTime.toLocaleTimeString()}.${fetchTime.getMilliseconds()}`);
                    await this.fetchLatest5MinuteCandle();
                    this.lastSuccessfulFetchTime = Date.now();
                    this.resetErrorCount();
                    this.logger.debug('[BOLLINGER] ✅ Health status reset after successful candle fetch');
                    if (wasDisrupted) {
                        this.logger.info('🔄 Realigning master cycle to 5-minute boundary...');
                        if (this.masterCycleInterval) {
                            clearInterval(this.masterCycleInterval);
                            this.masterCycleInterval = null;
                        }
                        const alignedTime = new Date();
                        const currentMinute = alignedTime.getMinutes();
                        const currentSecond = alignedTime.getSeconds();
                        const minutesToNext5 = 5 - (currentMinute % 5);
                        const secondsToNext5 = minutesToNext5 * 60 - currentSecond + 5;
                        const msToNext5 = secondsToNext5 * 1000;
                        this.logger.info(`⏰ Next fetch scheduled in ${secondsToNext5} seconds at ${new Date(Date.now() + msToNext5).toLocaleTimeString()}`);
                        setTimeout(() => {
                            this.logger.info('✅ Realignment complete - restarting master cycle interval');
                            fetchCandleIfMarketOpen();
                            this.masterCycleInterval = setInterval(fetchCandleIfMarketOpen, 5 * 60 * 1000);
                        }, msToNext5);
                    }
                    clearTimeout(fetchTimeout);
                }
                catch (error) {
                    clearTimeout(fetchTimeout);
                    this.logger.error('[BOLLINGER] 🔴 Error fetching 5-minute candle:', error);
                }
                finally {
                    this.isFetchingCandle = false;
                }
            }
            else {
                this.logger.debug(`[BOLLINGER] ⏸️ Market closed, skipping fetch at ${now.toLocaleTimeString()}`);
            }
        };
        fetchCandleIfMarketOpen();
        this.masterCycleInterval = setInterval(fetchCandleIfMarketOpen, 5 * 60 * 1000);
        this.logger.info('✅ Master cycle started - fetched current candle and set 5-min interval');
    }
    startHealthMonitoring() {
        if (this.healthMonitorInterval) {
            clearInterval(this.healthMonitorInterval);
        }
        this.healthMonitorInterval = setInterval(() => {
            this.healthStatus.lastHeartbeat = new Date();
            const healthReport = this.getHealthReport();
            if (!healthReport.overall) {
                this.logger.warn('💊 STRATEGY HEALTH REPORT (UNHEALTHY):', healthReport);
            }
            else {
                this.logger.info('💚 Strategy health: OK', {
                    consecutiveErrors: healthReport.consecutiveErrors,
                    timeSinceHeartbeat: healthReport.timeSinceHeartbeat,
                    candleCount: healthReport.candleHistoryLength
                });
            }
            const now = new Date();
            if (now.getHours() === 9 && now.getMinutes() === 15) {
                this.healthStatus.criticalErrorsToday = 0;
                this.errorCounts.clear();
                this.logger.info('🔄 Daily error counts reset');
            }
        }, 5 * 60 * 1000);
    }
    async fetchLatest5MinuteCandle() {
        try {
            const fetchStartTime = new Date();
            this.logger.info(`📥 Fetching ${this.signalSymbol} 5-minute candle at ${fetchStartTime.toLocaleTimeString()}.${fetchStartTime.getMilliseconds()}`);
            const toDate = new Date();
            const fromDate = new Date(toDate.getTime() - 10 * 60 * 1000);
            const historicalData = await this.kiteConnect.getHistoricalData(this.signalInstrumentToken, '5minute', fromDate, toDate);
            if (historicalData && historicalData.length > 0) {
                const latestCandle = historicalData[historicalData.length - 1];
                const newCandle = {
                    timestamp: this.floorTo5Min(new Date(latestCandle.date)),
                    open: latestCandle.open,
                    high: latestCandle.high,
                    low: latestCandle.low,
                    close: latestCandle.close,
                    volume: latestCandle.volume
                };
                const candleAge = (fetchStartTime.getTime() - newCandle.timestamp.getTime()) / 1000;
                const candleAgeMinutes = Math.floor(candleAge / 60);
                const candleAgeSeconds = Math.floor(candleAge % 60);
                this.logger.info(`📊 ${this.signalSymbol} candle: ${newCandle.timestamp.toLocaleTimeString()} | Age: ${candleAgeMinutes}m ${candleAgeSeconds}s | OHLC: ${newCandle.open}/${newCandle.high}/${newCandle.low}/${newCandle.close} V:${newCandle.volume}`);
                if (candleAge > 6 * 60) {
                    this.logger.warn(`⚠️ STALE CANDLE WARNING: ${this.signalSymbol} candle is ${candleAgeMinutes}m ${candleAgeSeconds}s old! Expected ~5m for 5-minute bars.`);
                }
                else if (candleAge > 5.5 * 60) {
                    this.logger.info(`ℹ️ ${this.signalSymbol} candle age: ${candleAgeMinutes}m ${candleAgeSeconds}s (slightly delayed but acceptable)`);
                }
                else if (candleAge >= 4 * 60) {
                    this.logger.info(`✅ Fresh ${this.signalSymbol} 5-minute candle: ${candleAgeMinutes}m ${candleAgeSeconds}s age (expected ~5m)`);
                }
                else {
                    this.logger.info(`✅ Very fresh ${this.signalSymbol} candle: ${candleAgeMinutes}m ${candleAgeSeconds}s age`);
                }
                const lastHistoricalCandle = this.candleHistory[this.candleHistory.length - 1];
                const isDuplicate = lastHistoricalCandle &&
                    newCandle.timestamp.getTime() === lastHistoricalCandle.timestamp.getTime() &&
                    newCandle.open === lastHistoricalCandle.open &&
                    newCandle.high === lastHistoricalCandle.high &&
                    newCandle.low === lastHistoricalCandle.low &&
                    newCandle.close === lastHistoricalCandle.close;
                if (!isDuplicate) {
                    const isNewerCandle = !lastHistoricalCandle || newCandle.timestamp.getTime() > lastHistoricalCandle.timestamp.getTime();
                    if (isNewerCandle) {
                        this.candleHistory.push(newCandle);
                        this.logger.info(`[BOLLINGER] ✅ Added new 5-minute candle: ${this.signalSymbol} ${newCandle.close} (${newCandle.timestamp.toLocaleTimeString()})`);
                    }
                    else {
                        if (lastHistoricalCandle && newCandle.timestamp.getTime() === lastHistoricalCandle.timestamp.getTime()) {
                            this.candleHistory[this.candleHistory.length - 1] = newCandle;
                            this.logger.debug(`[BOLLINGER] 🔄 Updated current 5-minute candle: ${this.signalSymbol} ${newCandle.close}`);
                        }
                    }
                    if (this.candleHistory.length > 50) {
                        this.candleHistory = this.candleHistory.slice(-50);
                    }
                    this.updateTechnicalIndicators();
                    if (this.currentPosition) {
                        try {
                            const optionPremium = await this.getLiveOptionPremium(this.currentPosition.instrument.instrument_token);
                            if (optionPremium > 0) {
                                this.cachedCurrentPrice = optionPremium;
                                if (optionPremium > (this.currentPosition.highestPremium || 0)) {
                                    this.currentPosition.highestPremium = optionPremium;
                                }
                                const priceDiff = optionPremium - this.currentPosition.entryPrice;
                                const totalQuantity = this.currentPosition.quantity * this.currentPosition.instrument.lot_size;
                                this.cachedUnrealizedPnL = priceDiff * totalQuantity;
                                this.lastPriceUpdateTime = new Date();
                                this.logger.info(`📊 Dashboard price updated: ${this.currentPosition.instrument.tradingsymbol} @ ₹${optionPremium.toFixed(2)} | P&L: ₹${this.cachedUnrealizedPnL.toFixed(2)}`);
                                if (this.currentPosition) {
                                    const premiumDropPct = (this.currentPosition.entryPrice - optionPremium) / this.currentPosition.entryPrice;
                                    const expFlags = StrategyManager_1.StrategyManager.getExperimentalFlags();
                                    if (expFlags.enablePremiumHardStop && premiumDropPct >= this.PREMIUM_HARD_STOP_PCT) {
                                        this.logger.warn(`🛑 PREMIUM HARD STOP: Premium ₹${optionPremium.toFixed(2)} is ${(premiumDropPct * 100).toFixed(1)}% below entry ₹${this.currentPosition.entryPrice.toFixed(2)} (threshold: ${this.PREMIUM_HARD_STOP_PCT * 100}%)`, {
                                            entryPrice: this.currentPosition.entryPrice,
                                            currentPremium: optionPremium,
                                            dropPct: (premiumDropPct * 100).toFixed(1),
                                        });
                                        await this.executeExit('PREMIUM_HARD_STOP_8PCT');
                                    }
                                }
                            }
                        }
                        catch (priceError) {
                            this.logger.warn('⚠️ Failed to update dashboard price:', priceError);
                        }
                    }
                    const hadPositionBeforeExitCheck = this.currentPosition !== null;
                    if (this.currentPosition) {
                        if (this.currentPosition?.rsiConfirmation && !this.currentPosition.rsiConfirmation.confirmed) {
                            await this.checkRsiConfirmation();
                        }
                        if (this.currentPosition) {
                            await this.checkPositionExit(newCandle.close);
                        }
                        if (this.currentPosition?.breakoutValidation && !this.currentPosition.breakoutValidation.validated) {
                            await this.checkBreakoutValidation(newCandle);
                        }
                    }
                    if (!hadPositionBeforeExitCheck) {
                        await this.checkEntrySignals();
                    }
                    else if (!this.currentPosition) {
                        this.logger.debug(`[CANDLE PROCESSING] Position exited on current candle - waiting for next candle before checking entry signals`);
                    }
                    this.updateMetrics({ healthStatus: 'healthy' });
                }
                else {
                    this.logger.debug(` Duplicate 5-minute candle detected, skipping: ${newCandle.timestamp.toLocaleTimeString()}`);
                    this.updateMetrics({ healthStatus: 'healthy' });
                }
            }
        }
        catch (error) {
            this.trackError('candle_fetch', error, true);
            this.healthStatus.dataStreamHealthy = false;
            this.updateMetrics({ healthStatus: 'error' });
        }
    }
    stopPositionMonitoring() {
        this.stopShortPositionMonitoring();
        this.logger.info('Position monitoring stopped (no active positions)');
    }
    async startPositionMonitoring() {
        if (!this.currentPosition) {
            this.logger.warn('Cannot start position monitoring - no active position');
            return;
        }
        this.logger.info(`?? Starting ${this.currentPosition.type} position monitoring (REST API polling)`);
        this.stopShortPositionMonitoring();
        const instrumentToken = this.currentPosition.instrument.instrument_token;
        this.startPollingBasedMonitoring(instrumentToken);
    }
    stopShortPositionMonitoring() {
        if (this.shortMonitoringInterval) {
            clearTimeout(this.shortMonitoringInterval);
            delete this.shortMonitoringInterval;
        }
        this.isPollingInProgress = false;
        this.consecutivePollingFailures = 0;
        this.lastPollingTime = null;
        this.logger.info('🛑 Position monitoring stopped');
    }
    startEmergencyStopMonitoring() {
        this.stopEmergencyStopMonitoring();
        if (!this.currentPosition || !this.currentPosition.entryStockPrice) {
            this.logger.warn('⚠️ Cannot start Emergency Stop monitoring - no position or entry stock price');
            return;
        }
        const entryStockPrice = this.currentPosition.entryStockPrice;
        const positionType = this.currentPosition.type;
        this.logger.info(`🚨 Emergency Hard Stop monitoring STARTED`, {
            pollInterval: `${this.EMERGENCY_POLL_INTERVAL_MS / 1000}s`,
            threshold: `${this.EMERGENCY_STOP_PERCENT}%`,
            entryStockPrice: entryStockPrice.toFixed(2),
            positionType,
            triggerPrice: positionType === 'LONG'
                ? (entryStockPrice * (1 - this.EMERGENCY_STOP_PERCENT / 100)).toFixed(2)
                : (entryStockPrice * (1 + this.EMERGENCY_STOP_PERCENT / 100)).toFixed(2)
        });
        this.emergencyStopInterval = setInterval(async () => {
            await this.checkEmergencyStop();
        }, this.EMERGENCY_POLL_INTERVAL_MS);
    }
    stopEmergencyStopMonitoring() {
        if (this.emergencyStopInterval) {
            clearInterval(this.emergencyStopInterval);
            this.emergencyStopInterval = null;
            this.logger.info('🛑 Emergency Hard Stop monitoring stopped');
        }
    }
    async checkEmergencyStop() {
        if (!this.currentPosition || !this.currentPosition.entryStockPrice) {
            return;
        }
        try {
            const quoteKey = `NSE:${this.signalSymbol}`;
            const quotes = await this.kiteConnect.getQuote([quoteKey]);
            const currentStockLTP = quotes[quoteKey]?.last_price;
            if (!currentStockLTP || currentStockLTP <= 0) {
                this.logger.warn('⚠️ Emergency Stop: Failed to fetch stock LTP');
                return;
            }
            const entryStockPrice = this.currentPosition.entryStockPrice;
            const movePercent = ((currentStockLTP - entryStockPrice) / entryStockPrice) * 100;
            const ss = this.currentPosition.structuralStop;
            const expFlagsLocal = StrategyManager_1.StrategyManager.getExperimentalFlags();
            if (ss && expFlagsLocal.useStructuralStockStop) {
                const breached = ss.direction === 'LONG' ? currentStockLTP < ss.stockPrice : currentStockLTP > ss.stockPrice;
                if (breached) {
                    this.logger.warn(`🛑 STRUCTURAL STOCK STOP HIT — ${ss.direction} stock ${currentStockLTP.toFixed(2)} crossed ${ss.stockPrice.toFixed(2)} (pullback level ${ss.basedOnPullbackLevel.toFixed(2)})`, {
                        symbol: this.signalSymbol,
                        slot: this.slotIndex + 1,
                        entryStockPrice: entryStockPrice.toFixed(2),
                        movePercent: movePercent.toFixed(2),
                        note: 'Structural stop overrides min-holding guard',
                    });
                    this.stopEmergencyStopMonitoring();
                    await this.executeExit('STRUCTURAL_STOCK_STOP');
                    return;
                }
            }
            if (this.currentPosition.type === 'LONG') {
                if (currentStockLTP < entryStockPrice * (1 - this.EMERGENCY_STOP_PERCENT / 100)) {
                    this.logger.error(`🚨🚨🚨 EMERGENCY HARD STOP TRIGGERED!`, {
                        symbol: this.signalSymbol,
                        positionType: 'LONG',
                        entryStockPrice: entryStockPrice.toFixed(2),
                        currentStockPrice: currentStockLTP.toFixed(2),
                        dropPercent: movePercent.toFixed(2),
                        threshold: `-${this.EMERGENCY_STOP_PERCENT}%`,
                        action: 'FORCE EXIT LONG position'
                    });
                    this.stopEmergencyStopMonitoring();
                    await this.executeExit('EMERGENCY_HARD_STOP');
                    return;
                }
            }
            if (this.currentPosition.type === 'SHORT') {
                if (currentStockLTP > entryStockPrice * (1 + this.EMERGENCY_STOP_PERCENT / 100)) {
                    this.logger.error(`🚨🚨🚨 EMERGENCY HARD STOP TRIGGERED!`, {
                        symbol: this.signalSymbol,
                        positionType: 'SHORT',
                        entryStockPrice: entryStockPrice.toFixed(2),
                        currentStockPrice: currentStockLTP.toFixed(2),
                        risePercent: movePercent.toFixed(2),
                        threshold: `+${this.EMERGENCY_STOP_PERCENT}%`,
                        action: 'FORCE EXIT SHORT position'
                    });
                    this.stopEmergencyStopMonitoring();
                    await this.executeExit('EMERGENCY_HARD_STOP');
                    return;
                }
            }
            this.logger.debug(`🔍 Emergency Stop check: ${this.signalSymbol} at ₹${currentStockLTP.toFixed(2)} (${movePercent >= 0 ? '+' : ''}${movePercent.toFixed(2)}% from entry ₹${entryStockPrice.toFixed(2)})`);
        }
        catch (error) {
            this.logger.error('❌ Emergency Stop check failed:', error);
        }
    }
    startPollingBasedMonitoring(instrumentToken) {
        this.logger.info('📴 Real-time position monitoring DISABLED - using 5-min candle close ONLY');
        this.logger.info('📊 Exit logic: LONG exits when close < Supertrend | SHORT exits when close > MIN(Supertrend, BB Mid)');
        this.logger.info('⏰ Exit checks run at each 5-minute candle close (XX:00, XX:05, XX:10, etc.)');
        return;
    }
    async checkPositionExit(candleClose) {
        if (!this.currentPosition)
            return;
        try {
            if (this.currentPosition.type === 'LONG') {
                if (candleClose !== undefined) {
                    this.currentStockLTP = candleClose;
                    await this.checkLongExitOnCandleClose(candleClose);
                }
                else {
                    this.logger.warn('LONG position exit called without candle close price');
                }
            }
            else if (this.currentPosition.type === 'SHORT') {
                if (candleClose !== undefined) {
                    this.currentStockLTP = candleClose;
                    await this.checkShortExitOnCandleClose(candleClose);
                }
                else {
                    this.logger.warn('SHORT position exit called without candle close price');
                }
            }
            this.updateMetrics({
                healthStatus: 'healthy'
            });
        }
        catch (error) {
            this.logger.error('Error checking position exit:', error);
            this.updateMetrics({
                healthStatus: 'error'
            });
        }
    }
    async checkBreakoutValidation(newCandle) {
        if (!this.currentPosition?.breakoutValidation)
            return;
        if (this.currentPosition.breakoutValidation.validated)
            return;
        const validation = this.currentPosition.breakoutValidation;
        validation.candlesSinceBreakout++;
        const isLong = this.currentPosition.type === 'LONG';
        if (isLong) {
            validation.bestHighSinceBreakout = Math.max(validation.bestHighSinceBreakout, newCandle.high);
            if (validation.bestHighSinceBreakout > validation.breakoutCandleHigh) {
                validation.validated = true;
                this.logger.info('✅ BREAKOUT VALIDATED: New HIGH exceeded breakout candle HIGH', {
                    symbol: this.signalSymbol,
                    breakoutCandleHigh: validation.breakoutCandleHigh.toFixed(2),
                    newHigh: validation.bestHighSinceBreakout.toFixed(2),
                    candlesAfterEntry: validation.candlesSinceBreakout
                });
                this.saveCapitalData();
                return;
            }
        }
        else {
            validation.bestLowSinceBreakout = Math.min(validation.bestLowSinceBreakout, newCandle.low);
            if (validation.bestLowSinceBreakout < validation.breakoutCandleLow) {
                validation.validated = true;
                this.logger.info('✅ BREAKOUT VALIDATED (SHORT): New LOW exceeded breakout candle LOW', {
                    symbol: this.signalSymbol,
                    breakoutCandleLow: validation.breakoutCandleLow.toFixed(2),
                    newLow: validation.bestLowSinceBreakout.toFixed(2),
                    candlesAfterEntry: validation.candlesSinceBreakout
                });
                this.saveCapitalData();
                return;
            }
        }
        if (validation.candlesSinceBreakout >= 3) {
            const target = isLong ? validation.breakoutCandleHigh : validation.breakoutCandleLow;
            const best = isLong ? validation.bestHighSinceBreakout : validation.bestLowSinceBreakout;
            const label = isLong ? 'HIGH' : 'LOW';
            this.logger.warn(`⚠️ BREAKOUT FAILED — No ${label} follow-through in 15 min`, {
                symbol: this.signalSymbol,
                direction: this.currentPosition.type,
                [`breakoutCandle${label}`]: target.toFixed(2),
                [`best${label}InWindow`]: best.toFixed(2),
                candlesChecked: validation.candlesSinceBreakout
            });
            const expFlags = StrategyManager_1.StrategyManager.getExperimentalFlags();
            if (expFlags.enableBreakoutNoFollowThroughExit) {
                await this.executeExit('BREAKOUT_NO_FOLLOWTHROUGH');
            }
            else {
                validation.validated = true;
                this.logger.info('🔕 BREAKOUT_NO_FOLLOWTHROUGH exit disabled by flag — letting position run');
                this.saveCapitalData();
            }
            return;
        }
        this.logger.info(`🔍 BREAKOUT VALIDATION: Candle ${validation.candlesSinceBreakout}/3 — ${isLong ? 'HIGH' : 'LOW'} not yet exceeded`, {
            symbol: this.signalSymbol,
            target: isLong ? validation.breakoutCandleHigh.toFixed(2) : validation.breakoutCandleLow.toFixed(2),
            best: isLong ? validation.bestHighSinceBreakout.toFixed(2) : validation.bestLowSinceBreakout.toFixed(2)
        });
        this.saveCapitalData();
    }
    async checkRsiConfirmation() {
        if (!this.currentPosition?.rsiConfirmation)
            return;
        if (this.currentPosition.rsiConfirmation.confirmed)
            return;
        if (!this.currentIndicators)
            return;
        const conf = this.currentPosition.rsiConfirmation;
        conf.candlesSinceEntry++;
        const currentRsi = this.currentIndicators.rsi;
        const isLong = conf.direction === 'LONG';
        const breached = isLong
            ? currentRsi < conf.threshold
            : currentRsi > conf.threshold;
        if (breached) {
            const expFlags = StrategyManager_1.StrategyManager.getExperimentalFlags();
            if (!expFlags.enableRsiConfirmationExit) {
                this.logger.info(`🔕 RSI confirmation breach IGNORED (exit disabled by flag): ${isLong ? 'LONG' : 'SHORT'} RSI ${currentRsi.toFixed(2)} vs threshold ${conf.threshold}`);
            }
            else {
                this.logger.warn(`⚠️ RSI CONFIRMATION FAILED: ${isLong ? 'LONG' : 'SHORT'} RSI ${isLong ? 'dropped below' : 'rose above'} ${conf.threshold}`, {
                    symbol: this.signalSymbol,
                    direction: conf.direction,
                    currentRsi: currentRsi.toFixed(2),
                    threshold: conf.threshold,
                    entryRsi: conf.entryRsi.toFixed(2),
                    candleNumber: conf.candlesSinceEntry,
                    maxCandles: conf.maxCandles
                });
                await this.executeExit('RSI_CONFIRMATION_FAILED');
                return;
            }
        }
        if (conf.candlesSinceEntry >= conf.maxCandles) {
            conf.confirmed = true;
            this.logger.info(`✅ RSI CONFIRMATION PASSED: ${conf.direction} RSI held ${isLong ? 'above' : 'below'} ${conf.threshold} for ${conf.maxCandles} candles`, {
                symbol: this.signalSymbol,
                direction: conf.direction,
                currentRsi: currentRsi.toFixed(2),
                threshold: conf.threshold,
                entryRsi: conf.entryRsi.toFixed(2)
            });
            this.saveCapitalData();
            return;
        }
        this.logger.info(`🔍 RSI CONFIRMATION: Candle ${conf.candlesSinceEntry}/${conf.maxCandles} — RSI ${currentRsi.toFixed(2)} ${isLong ? '≥' : '≤'} ${conf.threshold} ✓`, {
            symbol: this.signalSymbol,
            direction: conf.direction,
            candlesRemaining: conf.maxCandles - conf.candlesSinceEntry
        });
        this.saveCapitalData();
    }
    isMarketHours() {
        const now = new Date();
        const hour = now.getHours();
        const minute = now.getMinutes();
        const marketStart = 9 * 60 + 15;
        const marketEnd = 15 * 60 + 30;
        const currentTime = hour * 60 + minute;
        return currentTime >= marketStart && currentTime <= marketEnd;
    }
    async checkEntrySignals() {
        if (!this.currentIndicators || !this.dailyPivots)
            return;
        if (!this.isMarketHours()) {
            this.logger.debug('🔒 Signal check skipped - Outside market hours (9:15 AM - 3:30 PM)');
            return;
        }
        const expFlags = StrategyManager_1.StrategyManager.getExperimentalFlags();
        if (StrategyManager_1.StrategyManager.isSlotLockedTodayStatic(this.slotIndex)) {
            this.logger.debug(`🔒 Entry blocked - Slot ${this.slotIndex + 1} locked (had losing trade today)`);
            return;
        }
        if (StrategyManager_1.StrategyManager.isKillSwitchActiveStatic()) {
            this.logger.debug('🛑 Entry blocked - kill switch active (consecutive losses limit reached for today)');
            return;
        }
        const now = new Date();
        const currentMinutes = now.getHours() * 60 + now.getMinutes();
        const lunchEnd = expFlags.lunchBlockEndMinutesIst;
        if (currentMinutes >= 11 * 60 && currentMinutes < lunchEnd) {
            const allowLateArm = this.isPullbackActiveForThisSlot(expFlags) || this.isFvgActiveForThisSlot(expFlags);
            if (!allowLateArm) {
                this.logger.debug(`🍽️ Entry blocked - Lunch zone (11:00 IST until ${Math.floor(lunchEnd / 60)}:${String(lunchEnd % 60).padStart(2, '0')}) (immediate slot)`);
                return;
            }
        }
        if (currentMinutes >= 14 * 60) {
            const allowLateArm = this.isPullbackActiveForThisSlot(expFlags) || this.isFvgActiveForThisSlot(expFlags);
            if (!allowLateArm) {
                this.logger.debug('🕐 Entry blocked - After 2:00 PM cutoff (immediate slot)');
                return;
            }
        }
        if (expFlags.enableWideRangeDayFilter && this.previousDayRangeRatio > this.WIDE_RANGE_DAY_THRESHOLD) {
            this.logger.info(`🚫 Entry blocked - Post-wide-range day (ratio: ${this.previousDayRangeRatio.toFixed(2)}, threshold: ${this.WIDE_RANGE_DAY_THRESHOLD})`);
            return;
        }
        if (currentMinutes === 9 * 60 + 20) {
            this.logger.info('✅ First 5-minute candle ready for entry evaluation', {
                candleTime: '9:15-9:20',
                currentTime: now.toLocaleTimeString(),
                candlesAvailable: this.candleHistory.length,
                timestamp: new Date().toISOString()
            });
        }
        if (this.candleHistory.length === 0)
            return;
        const latestCandle = this.candleHistory[this.candleHistory.length - 1];
        if (!latestCandle)
            return;
        const { rsi, supertrend, bollingerBands } = this.currentIndicators;
        const { r1, r2, s1, pp } = this.dailyPivots;
        const close = latestCandle.close;
        const open = latestCandle.open;
        const candleIsBullish = close >= open;
        const candleIsBearish = close <= open;
        const isFirstCandleWindow = (now.getHours() === 9 && now.getMinutes() < 25);
        const candleBullishCheck = isFirstCandleWindow ? true : candleIsBullish;
        const candleBearishCheck = isFirstCandleWindow ? true : candleIsBearish;
        this.logger.info('[BOLLINGER] 🔥 ENTRY ANALYSIS - Checking signals...');
        this.logger.info(`[BOLLINGER] 📊 Current Indicators: RSI=${rsi.toFixed(2)}, BB_Upper=${bollingerBands.upper.toFixed(2)}, BB_Lower=${bollingerBands.lower.toFixed(2)}, Supertrend=${supertrend.trend}, Price=${close}`);
        this.logger.info(`[BOLLINGER] 📊 Candle Direction: ${candleIsBullish ? 'Bullish (close>open)' : candleIsBearish ? 'Bearish (close<open)' : 'Neutral'} | Open=${open.toFixed(2)}, Close=${close.toFixed(2)}`);
        if (!this.pivotsLoaded) {
            this.logger.error('[BOLLINGER] 🚫 ALL entries blocked - Pivot data not loaded! PDH/PDL/PDC are uninitialized.', {
                previousDayHigh: this.previousDayHigh,
                previousDayLow: this.previousDayLow,
                previousDayClose: this.previousDayClose,
                pivotsLoaded: this.pivotsLoaded
            });
            return;
        }
        if (this.isPullbackActiveForThisSlot(expFlags) && this.currentArmedSignal) {
            await this.progressArmedSignal(latestCandle, rsi, expFlags);
            return;
        }
        if (this.isFvgActiveForThisSlot(expFlags) && this.currentFvgWatch) {
            await this.progressFvgWatch(latestCandle, expFlags);
            return;
        }
        const longConditions = {
            priceAboveUpperBB: close > bollingerBands.upper,
            rsiInRange: rsi >= 68 && rsi <= 85,
            supertrendBullish: supertrend.trend === 'UP',
            aboveR1OrPDH: close > r1 || close > this.previousDayHigh,
            candleIsBullish: candleBullishCheck
        };
        const longSignal = Object.values(longConditions).every(Boolean);
        if (longSignal) {
            this.logger.info('[BOLLINGER] 🚀 LONG entry signal detected', {
                close: close.toFixed(2),
                rsi: rsi.toFixed(2),
                supertrend: supertrend.trend,
                upperBB: bollingerBands.upper.toFixed(2),
                r1: r1.toFixed(2),
                previousDayHigh: this.previousDayHigh.toFixed(2)
            });
            this.logSignalLifecycle('DETECTED', 'LONG', null, { close, rsi, mode: this.isFvgActiveForThisSlot(expFlags) ? 'fvg' : this.isPullbackActiveForThisSlot(expFlags) ? 'pullback' : 'immediate' });
            if (expFlags.enableExtendedGapTrap) {
                const todayChangePctLong = this.previousDayClose > 0
                    ? ((close - this.previousDayClose) / this.previousDayClose) * 100
                    : 0;
                const isExtendedLong = todayChangePctLong > 3.0;
                const isLateLong = currentMinutes > 10 * 60 + 30;
                const rsi5CandlesAgoLong = this.candleHistory.length >= 6
                    ? this.calculateRSI(this.candleHistory.slice(0, -5), 10)
                    : rsi;
                const isRsiFalling = rsi < (rsi5CandlesAgoLong - 2.0);
                if (isExtendedLong && isLateLong && isRsiFalling) {
                    this.logger.warn('[BOLLINGER] 🚫 LONG blocked - Extended Gap Trap detected', {
                        todayChange: `+${todayChangePctLong.toFixed(2)}% (threshold: +3%)`,
                        time: now.toLocaleTimeString(),
                        rsiNow: rsi.toFixed(2),
                        rsi5CandlesAgo: rsi5CandlesAgoLong.toFixed(2),
                        rsiFall: (rsi5CandlesAgoLong - rsi).toFixed(2)
                    });
                    return;
                }
            }
            const longStaleness = this.checkBreakoutStaleness('LONG');
            if (expFlags.enableStaleBreakoutFilter && longStaleness.isStale) {
                this.logger.warn('[BOLLINGER] 🚫 LONG blocked - Stale Breakout detected', {
                    consecutiveCandles: longStaleness.consecutiveCount,
                    message: `${longStaleness.consecutiveCount} candles already outside band`,
                    reason: 'Move is 10-15+ minutes old, likely exhausted'
                });
                return;
            }
            if (StrategyManager_1.StrategyManager.isSymbolInCooldownStatic(this.signalSymbol)) {
                this.logger.warn('[BOLLINGER] 🚫 LONG blocked - Symbol in cooldown', {
                    symbol: this.signalSymbol,
                    reason: 'Symbol in cooldown (30-min or same-day re-entry block)'
                });
                return;
            }
            if (expFlags.enableExtremeNiftyRangeFilter) {
                const niftyRangeLong = await this.getNiftyIntradayRange();
                if (niftyRangeLong > this.EXTREME_INTRADAY_RANGE_PCT) {
                    this.logger.warn('[BOLLINGER] 🚫 LONG blocked - Extreme NIFTY intraday range', {
                        niftyRange: `${(niftyRangeLong * 100).toFixed(2)}%`,
                        threshold: `${this.EXTREME_INTRADAY_RANGE_PCT * 100}%`
                    });
                    return;
                }
            }
            const entryCandleHigh = latestCandle.high;
            const entryCandleLow = latestCandle.low;
            const entryCandleTimestamp = latestCandle.timestamp;
            if (this.isFvgActiveForThisSlot(expFlags)) {
                this.armFvgSignal(latestCandle, expFlags);
                return;
            }
            if (this.isPullbackActiveForThisSlot(expFlags)) {
                this.armSignal('LONG', latestCandle, rsi, expFlags);
                return;
            }
            await this.executeLongEntryWithRetry(close, entryCandleHigh, entryCandleLow, entryCandleTimestamp, longStaleness.consecutiveCount);
        }
        else {
            this.logger.info('[BOLLINGER] ❌ LONG conditions not met:', {
                priceAboveUpperBB: `${longConditions.priceAboveUpperBB} (${close.toFixed(2)} > ${bollingerBands.upper.toFixed(2)})`,
                rsiInRange: `${longConditions.rsiInRange} (${rsi.toFixed(2)} in 68-85)`,
                supertrendBullish: `${longConditions.supertrendBullish} (${supertrend.trend})`,
                aboveR1OrPDH: `${longConditions.aboveR1OrPDH} (${close.toFixed(2)} > R1:${r1.toFixed(2)} or PDH:${this.previousDayHigh.toFixed(2)})`,
                candleIsBullish: `${longConditions.candleIsBullish}`
            });
        }
        const shortConditions = {
            priceBelowLowerBB: close < bollingerBands.lower,
            rsiInRange: rsi >= 15 && rsi <= 40,
            supertrendBearish: supertrend.trend === 'DOWN',
            belowS1OrPDL: close < s1 || close < this.previousDayLow,
            candleIsBearish: candleBearishCheck
        };
        const shortSignal = Object.values(shortConditions).every(Boolean);
        if (shortSignal) {
            if (!expFlags.enableShortEntries) {
                this.logger.info('🚫 SHORT entry blocked - SHORTs disabled in experimental flags');
                return;
            }
            this.logger.info('[BOLLINGER] 🔻 SHORT entry signal detected', {
                close: close.toFixed(2),
                rsi: rsi.toFixed(2),
                supertrend: supertrend.trend,
                lowerBB: bollingerBands.lower.toFixed(2),
                s1: s1.toFixed(2),
                previousDayLow: this.previousDayLow.toFixed(2)
            });
            this.logSignalLifecycle('DETECTED', 'SHORT', null, { close, rsi, mode: this.isFvgActiveForThisSlot(expFlags) ? 'fvg_long_only_skip' : this.isPullbackActiveForThisSlot(expFlags) ? 'pullback' : 'immediate' });
            if (this.isFvgActiveForThisSlot(expFlags)) {
                this.logger.info('[BOLLINGER] 🚫 SHORT skipped — FVG slot is LONG-only in v1', {
                    slot: this.slotIndex + 1, symbol: this.signalSymbol,
                });
                return;
            }
            if (expFlags.enableExtendedGapTrap) {
                const todayChangePctShort = this.previousDayClose > 0
                    ? ((close - this.previousDayClose) / this.previousDayClose) * 100
                    : 0;
                const isExtendedShort = todayChangePctShort < -3.0;
                const isLateShort = currentMinutes > 10 * 60 + 30;
                const rsi5CandlesAgoShort = this.candleHistory.length >= 6
                    ? this.calculateRSI(this.candleHistory.slice(0, -5), 10)
                    : rsi;
                const isRsiRecovering = rsi > (rsi5CandlesAgoShort + 2.0);
                if (isExtendedShort && isLateShort && isRsiRecovering) {
                    this.logger.warn('[BOLLINGER] 🚫 SHORT blocked - Extended Gap Trap detected', {
                        todayChange: `${todayChangePctShort.toFixed(2)}% (threshold: -3%)`,
                        time: now.toLocaleTimeString(),
                        rsiNow: rsi.toFixed(2),
                        rsi5CandlesAgo: rsi5CandlesAgoShort.toFixed(2),
                        rsiRise: (rsi - rsi5CandlesAgoShort).toFixed(2)
                    });
                    return;
                }
            }
            const shortStaleness = this.checkBreakoutStaleness('SHORT');
            if (expFlags.enableStaleBreakoutFilter && shortStaleness.isStale) {
                this.logger.warn('[BOLLINGER] 🚫 SHORT blocked - Stale Breakout detected', {
                    consecutiveCandles: shortStaleness.consecutiveCount,
                    message: `${shortStaleness.consecutiveCount} candles already outside band`,
                    reason: 'Move is 10-15+ minutes old, likely exhausted'
                });
                return;
            }
            if (StrategyManager_1.StrategyManager.isSymbolInCooldownStatic(this.signalSymbol)) {
                this.logger.warn('[BOLLINGER] 🚫 SHORT blocked - Symbol in cooldown', {
                    symbol: this.signalSymbol,
                    reason: 'Symbol in cooldown (30-min or same-day re-entry block)'
                });
                return;
            }
            if (expFlags.enableExtremeNiftyRangeFilter) {
                const niftyRangeShort = await this.getNiftyIntradayRange();
                if (niftyRangeShort > this.EXTREME_INTRADAY_RANGE_PCT) {
                    this.logger.warn('[BOLLINGER] 🚫 SHORT blocked - Extreme NIFTY intraday range', {
                        niftyRange: `${(niftyRangeShort * 100).toFixed(2)}%`,
                        threshold: `${this.EXTREME_INTRADAY_RANGE_PCT * 100}%`
                    });
                    return;
                }
            }
            const entryCandleHigh = latestCandle.high;
            const entryCandleLow = latestCandle.low;
            const entryCandleTimestamp = latestCandle.timestamp;
            if (this.isPullbackActiveForThisSlot(expFlags)) {
                this.armSignal('SHORT', latestCandle, rsi, expFlags);
                return;
            }
            await this.executeShortEntryWithRetry(close, entryCandleHigh, entryCandleLow, entryCandleTimestamp, shortStaleness.consecutiveCount);
        }
        else {
            this.logger.info('[BOLLINGER] ❌ SHORT conditions not met:', {
                priceBelowLowerBB: `${shortConditions.priceBelowLowerBB} (${close.toFixed(2)} < ${bollingerBands.lower.toFixed(2)})`,
                rsiInRange: `${shortConditions.rsiInRange} (${rsi.toFixed(2)} in 15-40)`,
                supertrendBearish: `${shortConditions.supertrendBearish} (${supertrend.trend})`,
                belowS1OrPDL: `${shortConditions.belowS1OrPDL} (${close.toFixed(2)} < S1:${s1.toFixed(2)} or PDL:${this.previousDayLow.toFixed(2)})`,
                candleIsBearish: `${shortConditions.candleIsBearish}`
            });
        }
    }
    hasArmedSignal() {
        return this.currentArmedSignal !== null;
    }
    hasFvgWatch() {
        return this.currentFvgWatch !== null;
    }
    logSignalLifecycle(stage, direction, reason = null, extra = {}) {
        this.logger.info('SIGNAL_LIFECYCLE', {
            event: 'SIGNAL_LIFECYCLE',
            stage,
            direction,
            slot: this.slotIndex + 1,
            symbol: this.signalSymbol,
            reason,
            ...extra,
        });
    }
    isPullbackActiveForThisSlot(flags) {
        return !!flags.enablePullbackEntry && Array.isArray(flags.pullbackSlots) && flags.pullbackSlots.includes(this.slotIndex);
    }
    armSignal(direction, signalCandle, signalRsi, flags) {
        this.currentArmedSignal = {
            direction,
            signalSymbol: this.signalSymbol,
            armedAtCandle: signalCandle.timestamp,
            armedAtWallClock: new Date(),
            signalCandleHigh: signalCandle.high,
            signalCandleLow: signalCandle.low,
            signalCandleClose: signalCandle.close,
            signalCandleRsi: signalRsi,
            candlesElapsedSinceArm: 0,
            pullbackSeen: false,
            pullbackLow: direction === 'LONG' ? signalCandle.low : Number.POSITIVE_INFINITY,
            pullbackHigh: direction === 'SHORT' ? signalCandle.high : Number.NEGATIVE_INFINITY,
            candlesSincePullback: 0,
        };
        this.logger.info(`🎯 ${direction} signal ARMED — waiting for pullback`, {
            symbol: this.signalSymbol,
            slot: this.slotIndex + 1,
            signalClose: signalCandle.close.toFixed(2),
            signalHigh: signalCandle.high.toFixed(2),
            signalLow: signalCandle.low.toFixed(2),
            signalRsi: signalRsi.toFixed(2),
            armTimeoutCandles: flags.pullbackArmTimeoutCandles,
        });
        this.logSignalLifecycle('ARMED', direction, null, { signalClose: signalCandle.close, signalRsi });
        this.saveCapitalData();
    }
    async progressArmedSignal(latestCandle, currentRsi, flags) {
        const armed = this.currentArmedSignal;
        if (!armed)
            return;
        armed.candlesElapsedSinceArm++;
        const abandonReason = this.shouldAbandonArmedSignal(latestCandle, currentRsi, flags);
        if (abandonReason) {
            this.logger.info(`❌ Armed ${armed.direction} signal ABANDONED: ${abandonReason}`, {
                symbol: this.signalSymbol,
                slot: this.slotIndex + 1,
                candlesElapsed: armed.candlesElapsedSinceArm,
                pullbackSeen: armed.pullbackSeen,
            });
            this.logSignalLifecycle('ABANDONED', armed.direction, abandonReason, { candlesElapsed: armed.candlesElapsedSinceArm, pullbackSeen: armed.pullbackSeen });
            this.currentArmedSignal = null;
            this.saveCapitalData();
            return;
        }
        if (!armed.pullbackSeen) {
            if (armed.direction === 'LONG') {
                armed.pullbackLow = Math.min(armed.pullbackLow, latestCandle.low);
                const pullbackHappened = currentRsi < flags.pullbackLongRsiThreshold && latestCandle.close < armed.signalCandleHigh;
                if (pullbackHappened) {
                    armed.pullbackSeen = true;
                    armed.candlesSincePullback = 0;
                    this.logger.info(`📉 LONG pullback DETECTED — waiting for confirmation`, {
                        symbol: this.signalSymbol,
                        slot: this.slotIndex + 1,
                        pullbackLow: armed.pullbackLow.toFixed(2),
                        currentClose: latestCandle.close.toFixed(2),
                        currentRsi: currentRsi.toFixed(2),
                        confirmTimeoutCandles: flags.pullbackConfirmTimeoutCandles,
                    });
                    this.logSignalLifecycle('PULLBACK_SEEN', 'LONG', null, { pullbackLow: armed.pullbackLow, currentClose: latestCandle.close, currentRsi });
                    this.saveCapitalData();
                }
            }
            else {
                armed.pullbackHigh = Math.max(armed.pullbackHigh, latestCandle.high);
                const pullbackHappened = currentRsi > flags.pullbackShortRsiThreshold && latestCandle.close > armed.signalCandleLow;
                if (pullbackHappened) {
                    armed.pullbackSeen = true;
                    armed.candlesSincePullback = 0;
                    this.logger.info(`📈 SHORT pullback DETECTED — waiting for confirmation`, {
                        symbol: this.signalSymbol,
                        slot: this.slotIndex + 1,
                        pullbackHigh: armed.pullbackHigh.toFixed(2),
                        currentClose: latestCandle.close.toFixed(2),
                        currentRsi: currentRsi.toFixed(2),
                        confirmTimeoutCandles: flags.pullbackConfirmTimeoutCandles,
                    });
                    this.logSignalLifecycle('PULLBACK_SEEN', 'SHORT', null, { pullbackHigh: armed.pullbackHigh, currentClose: latestCandle.close, currentRsi });
                    this.saveCapitalData();
                }
            }
        }
        else {
            armed.candlesSincePullback++;
            if (this.checkConfirmation(latestCandle, currentRsi, armed, flags)) {
                await this.enterAfterConfirmation(latestCandle, armed, flags);
            }
        }
    }
    shouldAbandonArmedSignal(candle, _currentRsi, flags) {
        const armed = this.currentArmedSignal;
        if (!armed)
            return null;
        if (!armed.pullbackSeen && armed.candlesElapsedSinceArm > flags.pullbackArmTimeoutCandles) {
            return `No pullback in ${flags.pullbackArmTimeoutCandles} candles`;
        }
        if (armed.pullbackSeen && armed.candlesSincePullback > flags.pullbackConfirmTimeoutCandles) {
            return `No confirmation in ${flags.pullbackConfirmTimeoutCandles} candles after pullback`;
        }
        if (armed.direction === 'LONG' && candle.close > armed.signalCandleClose * (1 + flags.pullbackAbandonOnExtensionPct)) {
            const pct = ((candle.close / armed.signalCandleClose - 1) * 100).toFixed(2);
            return `Price extended +${pct}% above signal — won't chase`;
        }
        if (armed.direction === 'SHORT' && candle.close < armed.signalCandleClose * (1 - flags.pullbackAbandonOnExtensionPct)) {
            const pct = ((1 - candle.close / armed.signalCandleClose) * 100).toFixed(2);
            return `Price extended -${pct}% below signal — won't chase`;
        }
        const trend = this.currentIndicators?.supertrend?.trend;
        if (armed.direction === 'LONG' && trend === 'DOWN') {
            return 'Supertrend flipped DOWN before confirmation';
        }
        if (armed.direction === 'SHORT' && trend === 'UP') {
            return 'Supertrend flipped UP before confirmation';
        }
        return null;
    }
    checkConfirmation(candle, currentRsi, armed, flags) {
        if (armed.direction === 'LONG') {
            const isBullish = candle.close > candle.open;
            const breaksLevel = candle.close > armed.signalCandleHigh;
            const rsiStrong = currentRsi > flags.pullbackLongConfirmRsiThreshold;
            return isBullish && breaksLevel && rsiStrong;
        }
        const isBearish = candle.close < candle.open;
        const breaksLevel = candle.close < armed.signalCandleLow;
        const rsiWeak = currentRsi < flags.pullbackShortConfirmRsiThreshold;
        return isBearish && breaksLevel && rsiWeak;
    }
    async enterAfterConfirmation(latestCandle, armed, flags) {
        const close = latestCandle.close;
        const entryCandleHigh = latestCandle.high;
        const entryCandleLow = latestCandle.low;
        const entryCandleTimestamp = latestCandle.timestamp;
        const pullbackLevel = armed.direction === 'LONG' ? armed.pullbackLow : armed.pullbackHigh;
        const stopBuffer = flags.structuralStopBufferPct;
        const structuralStopPrice = armed.direction === 'LONG'
            ? pullbackLevel * (1 - stopBuffer)
            : pullbackLevel * (1 + stopBuffer);
        this.logger.info(`✅ ${armed.direction} pullback CONFIRMED — entering`, {
            symbol: this.signalSymbol,
            slot: this.slotIndex + 1,
            signalClose: armed.signalCandleClose.toFixed(2),
            pullbackLevel: pullbackLevel.toFixed(2),
            confirmClose: close.toFixed(2),
            structuralStop: structuralStopPrice.toFixed(2),
            armedToConfirmCandles: armed.candlesElapsedSinceArm,
        });
        this.logSignalLifecycle('CONFIRMED', armed.direction, null, { signalClose: armed.signalCandleClose, pullbackLevel, confirmClose: close, structuralStop: structuralStopPrice, armedToConfirmCandles: armed.candlesElapsedSinceArm });
        if (armed.direction === 'LONG') {
            await this.executeLongEntryWithRetry(close, entryCandleHigh, entryCandleLow, entryCandleTimestamp, 0);
        }
        else {
            await this.executeShortEntryWithRetry(close, entryCandleHigh, entryCandleLow, entryCandleTimestamp, 0);
        }
        if (this.currentPosition && flags.useStructuralStockStop) {
            this.currentPosition.structuralStop = {
                stockPrice: structuralStopPrice,
                basedOnPullbackLevel: pullbackLevel,
                direction: armed.direction,
            };
            this.logger.info(`🛡️ Structural stock stop set at ${structuralStopPrice.toFixed(2)} (pullback level ${pullbackLevel.toFixed(2)})`);
        }
        this.currentArmedSignal = null;
        this.saveCapitalData();
    }
    isFvgActiveForThisSlot(flags) {
        return !!flags.enableFvgEntry && Array.isArray(flags.fvgSlots) && flags.fvgSlots.includes(this.slotIndex);
    }
    detectBullishFvg(c1, c2, c3, impulseClose, minGapPct) {
        if (!(c1.high < c3.low))
            return null;
        const width = c3.low - c1.high;
        const minGap = impulseClose * minGapPct;
        if (width < minGap)
            return null;
        return {
            floor: c1.high,
            ceiling: c3.low,
            slLevel: c2.low,
            width,
        };
    }
    findRecentUntouchedBullishFvg(signalCandle, lookbackCandles, minGapPct, invalidateOnFloorClose) {
        const hist = this.candleHistory;
        if (hist.length < 3)
            return null;
        let signalIdx = hist.length - 1;
        for (let i = hist.length - 1; i >= 0; i--) {
            if (hist[i] && hist[i].timestamp.getTime() === signalCandle.timestamp.getTime()) {
                signalIdx = i;
                break;
            }
        }
        const oldestC3 = Math.max(2, signalIdx - lookbackCandles + 1);
        for (let c3Idx = signalIdx; c3Idx >= oldestC3; c3Idx--) {
            const c1 = hist[c3Idx - 2], c2 = hist[c3Idx - 1], c3 = hist[c3Idx];
            if (!c1 || !c2 || !c3)
                continue;
            const fvg = this.detectBullishFvg(c1, c2, c3, signalCandle.close, minGapPct);
            if (!fvg)
                continue;
            let touched = false;
            for (let k = c3Idx + 1; k <= signalIdx; k++) {
                const cand = hist[k];
                if (!cand)
                    continue;
                if (cand.low <= fvg.ceiling) {
                    touched = true;
                    break;
                }
                if (invalidateOnFloorClose && cand.close < fvg.floor) {
                    touched = true;
                    break;
                }
            }
            if (touched)
                continue;
            return { ...fvg, impulseTimestamp: c2.timestamp };
        }
        return null;
    }
    maybeUpgradeFvg(_latestCandle, flags) {
        const watch = this.currentFvgWatch;
        if (!watch || !watch.fvg || watch.trigger !== null)
            return false;
        const hist = this.candleHistory;
        if (hist.length < 3)
            return false;
        const c1 = hist[hist.length - 3];
        const c2 = hist[hist.length - 2];
        const c3 = hist[hist.length - 1];
        if (!c1 || !c2 || !c3)
            return false;
        const armTs = watch.armedAtCandle.getTime();
        if (c2.timestamp.getTime() < armTs)
            return false;
        if (c2.timestamp.getTime() <= watch.fvg.impulseTimestamp.getTime())
            return false;
        const fvg = this.detectBullishFvg(c1, c2, c3, watch.signalCandleClose, flags.fvgMinGapPct);
        if (!fvg)
            return false;
        const prev = watch.fvg;
        watch.fvg = { ...fvg, impulseTimestamp: c2.timestamp };
        this.logger.info(`🔄 FVG UPGRADED on ${this.signalSymbol} — fresher impulse superseded prior zone`, {
            slot: this.slotIndex + 1,
            fromFloor: prev.floor.toFixed(2),
            fromCeiling: prev.ceiling.toFixed(2),
            fromImpulse: prev.impulseTimestamp.toISOString(),
            toFloor: fvg.floor.toFixed(2),
            toCeiling: fvg.ceiling.toFixed(2),
            toWidth: fvg.width.toFixed(2),
            toSlLevel: fvg.slLevel.toFixed(2),
            toImpulse: c2.timestamp.toISOString(),
        });
        this.logSignalLifecycle('FVG_UPGRADED', 'LONG', null, {
            fromFloor: prev.floor, fromCeiling: prev.ceiling, fromImpulse: prev.impulseTimestamp.toISOString(),
            toFloor: fvg.floor, toCeiling: fvg.ceiling, toWidth: fvg.width, toSlLevel: fvg.slLevel,
            toImpulse: c2.timestamp.toISOString(),
        });
        this.saveCapitalData();
        return true;
    }
    armFvgSignal(signalCandle, flags) {
        if (this.currentArmedSignal) {
            this.logger.warn(`⚠️ FVG arm pre-empts existing pullback state (config conflict?) — clearing armedSignal`);
            this.currentArmedSignal = null;
        }
        this.currentFvgWatch = {
            direction: 'LONG',
            signalSymbol: this.signalSymbol,
            armedAtCandle: signalCandle.timestamp,
            armedAtWallClock: new Date(),
            signalCandleClose: signalCandle.close,
            candlesScannedSinceArm: 0,
            lastProgressedCandleTs: null,
            fvg: null,
            trigger: null,
            triggerCandleTimestamp: null,
        };
        this.logger.info(`🎯 LONG FVG signal ARMED — scanning for FVG`, {
            symbol: this.signalSymbol,
            slot: this.slotIndex + 1,
            signalClose: signalCandle.close.toFixed(2),
        });
        this.logSignalLifecycle('FVG_ARMED', 'LONG', null, { signalClose: signalCandle.close });
        if (flags.enableFvgLookback) {
            const preExisting = this.findRecentUntouchedBullishFvg(signalCandle, flags.fvgLookbackCandles, flags.fvgMinGapPct, flags.fvgInvalidateOnFloorClose);
            if (preExisting) {
                this.currentFvgWatch.fvg = preExisting;
                this.logger.info(`📐 FVG PRE-FORMED on ${this.signalSymbol} (lookback hit)`, {
                    slot: this.slotIndex + 1,
                    floor: preExisting.floor.toFixed(2),
                    ceiling: preExisting.ceiling.toFixed(2),
                    width: preExisting.width.toFixed(2),
                    slLevel: preExisting.slLevel.toFixed(2),
                    impulseTime: preExisting.impulseTimestamp.toISOString(),
                });
                this.logSignalLifecycle('FVG_FORMED', 'LONG', null, {
                    floor: preExisting.floor, ceiling: preExisting.ceiling,
                    width: preExisting.width, slLevel: preExisting.slLevel,
                    source: 'lookback',
                });
            }
        }
        this.saveCapitalData();
    }
    async progressFvgWatch(latestCandle, flags) {
        const watch = this.currentFvgWatch;
        if (!watch)
            return;
        const latestTs = latestCandle.timestamp.getTime();
        if (watch.lastProgressedCandleTs !== null
            && watch.lastProgressedCandleTs.getTime() === latestTs) {
            return;
        }
        watch.lastProgressedCandleTs = latestCandle.timestamp;
        watch.candlesScannedSinceArm++;
        if (watch.fvg && flags.fvgInvalidateOnFloorClose && latestCandle.close < watch.fvg.floor) {
            this.clearFvgWatch(`Candle close ${latestCandle.close.toFixed(2)} < FVG floor ${watch.fvg.floor.toFixed(2)}`);
            return;
        }
        if (watch.candlesScannedSinceArm > flags.fvgMaxLifeCandles) {
            this.clearFvgWatch(`FVG watch lifetime exceeded (${flags.fvgMaxLifeCandles} candles since arm)`);
            return;
        }
        if (!watch.fvg) {
            const hist = this.candleHistory;
            if (hist.length >= 3) {
                const c1 = hist[hist.length - 3];
                const c2 = hist[hist.length - 2];
                const c3 = hist[hist.length - 1];
                const armTs = watch.armedAtCandle.getTime();
                if (c1 && c2 && c3 && c2.timestamp.getTime() >= armTs) {
                    const fvg = this.detectBullishFvg(c1, c2, c3, watch.signalCandleClose, flags.fvgMinGapPct);
                    if (fvg) {
                        watch.fvg = { ...fvg, impulseTimestamp: c2.timestamp };
                        this.logger.info(`📐 FVG FORMED on ${this.signalSymbol}`, {
                            slot: this.slotIndex + 1,
                            floor: fvg.floor.toFixed(2),
                            ceiling: fvg.ceiling.toFixed(2),
                            width: fvg.width.toFixed(2),
                            slLevel: fvg.slLevel.toFixed(2),
                            impulseTime: c2.timestamp.toISOString(),
                        });
                        this.logSignalLifecycle('FVG_FORMED', 'LONG', null, {
                            floor: fvg.floor, ceiling: fvg.ceiling, width: fvg.width, slLevel: fvg.slLevel,
                        });
                        this.saveCapitalData();
                        return;
                    }
                }
            }
            if (watch.candlesScannedSinceArm >= flags.fvgMaxScanCandles) {
                this.clearFvgWatch(`No FVG formed in ${flags.fvgMaxScanCandles} candles`);
            }
            return;
        }
        if (flags.enableFvgUpgrade && watch.trigger === null) {
            if (this.maybeUpgradeFvg(latestCandle, flags))
                return;
        }
        const fvg = watch.fvg;
        const wickInsideFvg = latestCandle.low <= fvg.ceiling && latestCandle.high >= fvg.floor;
        const isSameAsTriggerCandle = watch.triggerCandleTimestamp !== null
            && latestCandle.timestamp.getTime() === watch.triggerCandleTimestamp.getTime();
        if (watch.trigger === null) {
            if (wickInsideFvg) {
                watch.trigger = latestCandle.high;
                watch.triggerCandleTimestamp = latestCandle.timestamp;
                this.logger.info(`🎯 FVG TRIGGER set at ${watch.trigger.toFixed(2)} on ${this.signalSymbol}`, {
                    slot: this.slotIndex + 1,
                    candleHigh: latestCandle.high.toFixed(2),
                    candleClose: latestCandle.close.toFixed(2),
                });
                this.logSignalLifecycle('FVG_TRIGGER_SET', 'LONG', null, { trigger: watch.trigger });
                this.saveCapitalData();
            }
            return;
        }
        if (!isSameAsTriggerCandle && latestCandle.high >= watch.trigger) {
            await this.enterAfterFvgTrigger(latestCandle, watch, flags);
            return;
        }
        if (!isSameAsTriggerCandle && wickInsideFvg && latestCandle.high < watch.trigger) {
            const oldTrigger = watch.trigger;
            watch.trigger = latestCandle.high;
            watch.triggerCandleTimestamp = latestCandle.timestamp;
            this.logger.info(`📉 FVG trigger LOWERED ${oldTrigger.toFixed(2)} → ${watch.trigger.toFixed(2)}`, {
                symbol: this.signalSymbol,
                slot: this.slotIndex + 1,
            });
            this.logSignalLifecycle('FVG_TRIGGER_LOWERED', 'LONG', null, { from: oldTrigger, to: watch.trigger });
            this.saveCapitalData();
        }
    }
    clearFvgWatch(reason) {
        const w = this.currentFvgWatch;
        if (!w)
            return;
        this.logger.info(`❌ FVG watch INVALIDATED: ${reason}`, {
            symbol: this.signalSymbol,
            slot: this.slotIndex + 1,
            candlesScanned: w.candlesScannedSinceArm,
            hadFvg: !!w.fvg,
            hadTrigger: w.trigger !== null,
        });
        this.logSignalLifecycle('FVG_INVALIDATED', 'LONG', reason, {
            candlesScanned: w.candlesScannedSinceArm, hadFvg: !!w.fvg, hadTrigger: w.trigger !== null,
        });
        this.currentFvgWatch = null;
        this.saveCapitalData();
    }
    async enterAfterFvgTrigger(latestCandle, watch, flags) {
        if (!watch.fvg || watch.trigger === null) {
            this.clearFvgWatch('Internal: trigger fired without FVG/trigger state');
            return;
        }
        const close = latestCandle.close;
        const entryCandleHigh = latestCandle.high;
        const entryCandleLow = latestCandle.low;
        const entryCandleTimestamp = latestCandle.timestamp;
        const slLevel = watch.fvg.slLevel;
        const stopBuffer = flags.structuralStopBufferPct;
        const structuralStopPrice = slLevel * (1 - stopBuffer);
        this.logger.info(`✅ FVG LONG ENTRY — trigger ${watch.trigger.toFixed(2)} breached`, {
            symbol: this.signalSymbol,
            slot: this.slotIndex + 1,
            candleHigh: entryCandleHigh.toFixed(2),
            close: close.toFixed(2),
            fvgFloor: watch.fvg.floor.toFixed(2),
            fvgCeiling: watch.fvg.ceiling.toFixed(2),
            slLevel: slLevel.toFixed(2),
            structuralStop: structuralStopPrice.toFixed(2),
        });
        this.logSignalLifecycle('FVG_ENTRY', 'LONG', null, {
            trigger: watch.trigger, fvgFloor: watch.fvg.floor, fvgCeiling: watch.fvg.ceiling,
            slLevel, structuralStop: structuralStopPrice,
        });
        await this.executeLongEntryWithRetry(close, entryCandleHigh, entryCandleLow, entryCandleTimestamp, 0);
        if (this.currentPosition && flags.useStructuralStockStop) {
            this.currentPosition.structuralStop = {
                stockPrice: structuralStopPrice,
                basedOnPullbackLevel: slLevel,
                direction: 'LONG',
            };
            this.logger.info(`🛡️ Structural stock stop set at ${structuralStopPrice.toFixed(2)} (FVG SL ${slLevel.toFixed(2)})`);
        }
        this.currentFvgWatch = null;
        this.saveCapitalData();
    }
    async executeLongEntry(stockPrice, entryCandleHigh, entryCandleLow, entryCandleTimestamp, breakoutConsecutiveCount) {
        if (this.currentPosition !== null) {
            this.logger.warn('Skipping LONG entry - position already exists', {
                existingPosition: this.currentPosition.type,
                instrument: this.currentPosition.instrument?.tradingsymbol
            });
            return;
        }
        if (this.isExecutingLongEntry) {
            this.logger.debug('🔒 LONG entry execution already in progress, skipping duplicate trigger');
            return;
        }
        this.isExecutingLongEntry = true;
        try {
            const ceOption = await this.selectOptionInstrument('CE', stockPrice);
            if (!ceOption) {
                this.logger.error(`❌ LONG entry failed: Could not find suitable ${this.signalSymbol} CE option (ATM with premium ≥ ₹40)`);
                return;
            }
            this.logger.info(`🎯 ${this.signalSymbol} CE Option selected for LONG entry`, {
                symbol: ceOption.tradingsymbol,
                strike: ceOption.strike,
                premium: ceOption.last_price,
                stockPrice: stockPrice.toFixed(2),
                strikeType: ceOption.strikeType,
                timestamp: new Date().toLocaleTimeString()
            });
            const lots = this.calculateLots();
            this.logger.info(`🚀 Executing LONG entry with real-time selected option: ${ceOption.tradingsymbol}`);
            const orderResult = await this.executeOrder('BUY', ceOption, lots);
            if (orderResult.success) {
                this.currentPosition = {
                    type: 'LONG',
                    instrument: ceOption,
                    entryPrice: orderResult.price,
                    quantity: lots,
                    entryTime: new Date(),
                    entryCandle15MinTimestamp: new Date(),
                    ...(entryCandleTimestamp !== undefined && { entryCandleTimestamp: entryCandleTimestamp }),
                    ...(entryCandleLow !== undefined && { entryCandleLow: entryCandleLow }),
                    ...(entryCandleHigh !== undefined && { entryCandleHigh: entryCandleHigh }),
                    entryStockPrice: stockPrice,
                    highestPremium: orderResult.price,
                    entryOrderId: orderResult.orderId || `BB_ENTRY_${Date.now()}`,
                    timeDecayTrailing: { lastHighTime: new Date() }
                };
                if (breakoutConsecutiveCount !== undefined && breakoutConsecutiveCount <= 1) {
                    this.currentPosition.breakoutValidation = {
                        breakoutCandleHigh: entryCandleHigh ?? stockPrice,
                        breakoutCandleLow: entryCandleLow ?? stockPrice,
                        breakoutCandleTimestamp: entryCandleTimestamp ?? new Date(),
                        candlesSinceBreakout: 0,
                        bestHighSinceBreakout: 0,
                        bestLowSinceBreakout: Infinity,
                        validated: false
                    };
                    this.logger.info('🔍 BREAKOUT VALIDATION ARMED (first breakout — LONG)', {
                        breakoutCandleHigh: this.currentPosition.breakoutValidation.breakoutCandleHigh.toFixed(2),
                        deadline: '3 candles (15 min)'
                    });
                }
                else {
                    this.currentPosition.breakoutValidation = {
                        breakoutCandleHigh: entryCandleHigh ?? stockPrice,
                        breakoutCandleLow: entryCandleLow ?? stockPrice,
                        breakoutCandleTimestamp: entryCandleTimestamp ?? new Date(),
                        candlesSinceBreakout: 0,
                        bestHighSinceBreakout: 0,
                        bestLowSinceBreakout: Infinity,
                        validated: true
                    };
                    this.logger.info('✅ BREAKOUT PRE-VALIDATED (entering on candle #2, breakout has follow-through — LONG)');
                }
                this.currentPosition.rsiConfirmation = {
                    candlesSinceEntry: 0,
                    maxCandles: this.RSI_CONFIRMATION_WINDOW,
                    threshold: this.RSI_CONFIRMATION_LONG_THRESHOLD,
                    direction: 'LONG',
                    confirmed: false,
                    entryRsi: this.currentIndicators?.rsi ?? 0
                };
                this.logger.info('🔍 RSI CONFIRMATION ARMED (LONG)', {
                    threshold: `<${this.RSI_CONFIRMATION_LONG_THRESHOLD}`,
                    window: `${this.RSI_CONFIRMATION_WINDOW} candles (${this.RSI_CONFIRMATION_WINDOW * 5} min)`,
                    entryRsi: this.currentPosition.rsiConfirmation.entryRsi.toFixed(2)
                });
                this.saveCapitalData();
                this.logger.info('✅ LONG position created with pre-captured candle data', {
                    entryCandleLow: entryCandleLow?.toFixed(2),
                    entryCandleHigh: entryCandleHigh?.toFixed(2),
                    entryStockPrice: stockPrice.toFixed(2)
                });
                this.startPositionMonitoring().catch(error => {
                    this.logger.error('Failed to start position monitoring:', error);
                });
                this.startEmergencyStopMonitoring();
                this.startOptionRsiMonitoring();
                this.startRsiTrail5MinMonitoring();
                this.metrics.totalTrades++;
                this.updateMetrics({
                    totalTrades: this.metrics.totalTrades,
                    healthStatus: 'healthy',
                    lastTradeTime: new Date()
                });
                this.logger.info('✅ LONG position opened', {
                    instrument: ceOption.tradingsymbol,
                    entryPrice: orderResult.price,
                    quantity: lots
                });
            }
        }
        catch (error) {
            this.logger.error('❌ Error executing LONG entry:', error);
            if (this.currentPosition) {
                this.logger.warn('⚠️ LONG entry error but position exists - order likely succeeded');
                this.logger.info('✅ Position monitoring will continue normally');
            }
            else {
                this.logger.info('📉 LONG entry failed - no position created');
                this.trackError('execution_long_entry', error, true);
            }
        }
        finally {
            this.isExecutingLongEntry = false;
        }
    }
    async executeShortEntry(stockPrice, entryCandleHigh, entryCandleLow, entryCandleTimestamp, breakoutConsecutiveCount) {
        if (this.currentPosition !== null) {
            this.logger.warn('Skipping SHORT entry - position already exists', {
                existingPosition: this.currentPosition.type,
                instrument: this.currentPosition.instrument?.tradingsymbol
            });
            return;
        }
        if (this.isExecutingShortEntry) {
            this.logger.debug('🔒 SHORT entry execution already in progress, skipping duplicate trigger');
            return;
        }
        this.isExecutingShortEntry = true;
        try {
            const candleHigh = entryCandleHigh !== undefined ? entryCandleHigh : stockPrice;
            const peOption = await this.selectOptionInstrument('PE', stockPrice);
            if (!peOption) {
                this.logger.error(`❌ SHORT entry failed: Could not find suitable ${this.signalSymbol} PE option (ATM with premium ≥ ₹40)`);
                return;
            }
            this.logger.info(`🎯 ${this.signalSymbol} PE Option selected for SHORT entry`, {
                symbol: peOption.tradingsymbol,
                strike: peOption.strike,
                premium: peOption.last_price,
                stockPrice: stockPrice.toFixed(2),
                strikeType: peOption.strikeType,
                timestamp: new Date().toLocaleTimeString()
            });
            this.logger.info(`📉 Executing SHORT entry with real-time selected option: ${peOption.tradingsymbol}`);
            const lots = this.calculateLots();
            const orderResult = await this.executeOrder('BUY', peOption, lots);
            if (orderResult.success) {
                this.logger.info(`[SHORT ENTRY] Using entry candle high: ${candleHigh.toFixed(2)}`);
                this.currentPosition = {
                    type: 'SHORT',
                    instrument: peOption,
                    entryPrice: orderResult.price,
                    quantity: lots,
                    entryTime: new Date(),
                    entryCandle15MinTimestamp: new Date(),
                    ...(entryCandleTimestamp !== undefined && { entryCandleTimestamp: entryCandleTimestamp }),
                    entryCandleHigh: candleHigh,
                    entryStockPrice: stockPrice,
                    highestPremium: orderResult.price,
                    entryOrderId: orderResult.orderId || `BB_ENTRY_${Date.now()}`,
                    timeDecayTrailing: { lastHighTime: new Date() }
                };
                if (breakoutConsecutiveCount !== undefined && breakoutConsecutiveCount <= 1) {
                    this.currentPosition.breakoutValidation = {
                        breakoutCandleHigh: candleHigh,
                        breakoutCandleLow: entryCandleLow ?? stockPrice,
                        breakoutCandleTimestamp: entryCandleTimestamp ?? new Date(),
                        candlesSinceBreakout: 0,
                        bestHighSinceBreakout: 0,
                        bestLowSinceBreakout: Infinity,
                        validated: false
                    };
                    this.logger.info('🔍 BREAKOUT VALIDATION ARMED (first breakout — SHORT)', {
                        breakoutCandleLow: this.currentPosition.breakoutValidation.breakoutCandleLow.toFixed(2),
                        deadline: '3 candles (15 min)'
                    });
                }
                else {
                    this.currentPosition.breakoutValidation = {
                        breakoutCandleHigh: candleHigh,
                        breakoutCandleLow: entryCandleLow ?? stockPrice,
                        breakoutCandleTimestamp: entryCandleTimestamp ?? new Date(),
                        candlesSinceBreakout: 0,
                        bestHighSinceBreakout: 0,
                        bestLowSinceBreakout: Infinity,
                        validated: true
                    };
                    this.logger.info('✅ BREAKOUT PRE-VALIDATED (entering on candle #2, breakout has follow-through — SHORT)');
                }
                this.currentPosition.rsiConfirmation = {
                    candlesSinceEntry: 0,
                    maxCandles: this.RSI_CONFIRMATION_WINDOW,
                    threshold: this.RSI_CONFIRMATION_SHORT_THRESHOLD,
                    direction: 'SHORT',
                    confirmed: false,
                    entryRsi: this.currentIndicators?.rsi ?? 0
                };
                this.logger.info('🔍 RSI CONFIRMATION ARMED (SHORT)', {
                    threshold: `>${this.RSI_CONFIRMATION_SHORT_THRESHOLD}`,
                    window: `${this.RSI_CONFIRMATION_WINDOW} candles (${this.RSI_CONFIRMATION_WINDOW * 5} min)`,
                    entryRsi: this.currentPosition.rsiConfirmation.entryRsi.toFixed(2)
                });
                this.saveCapitalData();
                this.startPositionMonitoring().catch(error => {
                    this.logger.error('Failed to start position monitoring:', error);
                });
                this.startEmergencyStopMonitoring();
                this.startOptionRsiMonitoring();
                this.startRsiTrail5MinMonitoring();
                this.metrics.totalTrades++;
                this.updateMetrics({
                    totalTrades: this.metrics.totalTrades,
                    healthStatus: 'healthy',
                    lastTradeTime: new Date()
                });
                this.logger.info('✅ SHORT position opened', {
                    instrument: peOption.tradingsymbol,
                    entryPrice: orderResult.price,
                    quantity: lots,
                    trailingSL: this.currentPosition?.trailingSL
                });
            }
        }
        catch (error) {
            this.logger.error('❌ Error executing SHORT entry:', error);
            if (this.currentPosition) {
                this.logger.warn('⚠️ SHORT entry error but position exists - order likely succeeded');
                this.logger.info('✅ Position monitoring will continue normally');
            }
            else {
                this.logger.info('📉 SHORT entry failed - no position created');
                this.trackError('execution_short_entry', error, true);
            }
        }
        finally {
            this.isExecutingShortEntry = false;
        }
    }
    async checkExitConditions(stockLTP) {
        if (!this.currentPosition)
            return;
        this.logger.debug('⚠️ checkExitConditions() called but all exit logic moved to dedicated systems', {
            positionType: this.currentPosition.type,
            stockLTP: stockLTP.toFixed(2)
        });
    }
    async checkLongExitOnCandleClose(candleClosePrice) {
        if (!this.currentIndicators || !this.currentPosition)
            return;
        if (this.currentPosition.type !== 'LONG')
            return;
        if (this.isProcessingLongExit) {
            this.logger.debug('[LONG EXIT CHECK] Exit already in progress, skipping');
            return;
        }
        const supertrend = this.currentIndicators.supertrend.value;
        const supertrendTrend = this.currentIndicators.supertrend.trend;
        this.logger.info(`[LONG EXIT CHECK] 5-min candle close: ${candleClosePrice.toFixed(2)} | Supertrend: ${supertrend.toFixed(2)} (${supertrendTrend})`);
        if (candleClosePrice < supertrend) {
            this.isProcessingLongExit = true;
            try {
                this.logger.info('🔴 LONG EXIT SIGNAL: 5-min candle closed below Supertrend', {
                    candleClose: candleClosePrice.toFixed(2),
                    supertrend: supertrend.toFixed(2),
                    supertrendTrend: supertrendTrend,
                    breachAmount: (supertrend - candleClosePrice).toFixed(2),
                    exitType: 'SUPERTREND_BREAK',
                    timestamp: new Date().toLocaleTimeString()
                });
                await this.executeExit('LONG_SUPERTREND_BREAK');
            }
            finally {
                this.isProcessingLongExit = false;
            }
        }
        else {
            const cushion = candleClosePrice - supertrend;
            this.logger.info(`✅ LONG position held: Close ${candleClosePrice.toFixed(2)} > Supertrend ${supertrend.toFixed(2)} (cushion: +${cushion.toFixed(2)})`);
        }
    }
    async checkShortExitOnCandleClose(candleClosePrice) {
        if (!this.currentIndicators || !this.currentPosition)
            return;
        if (this.currentPosition.type !== 'SHORT')
            return;
        if (this.isProcessingShortExit) {
            this.logger.debug('[SHORT EXIT CHECK] Exit already in progress, skipping');
            return;
        }
        const supertrend = this.currentIndicators.supertrend.value;
        const supertrendTrend = this.currentIndicators.supertrend.trend;
        const bbMiddle = this.currentIndicators.bollingerBands.middle;
        const exitThreshold = Math.min(supertrend, bbMiddle);
        const usedIndicator = exitThreshold === supertrend ? 'Supertrend' : 'BB Middle';
        this.logger.info(`[SHORT EXIT CHECK] 5-min candle close: ${candleClosePrice.toFixed(2)} | Supertrend: ${supertrend.toFixed(2)} | BB Mid: ${bbMiddle.toFixed(2)} | Exit threshold: ${exitThreshold.toFixed(2)} (${usedIndicator})`);
        if (candleClosePrice > exitThreshold) {
            this.isProcessingShortExit = true;
            try {
                const breachAmount = candleClosePrice - exitThreshold;
                this.logger.info('🔴 SHORT EXIT SIGNAL: 5-min candle closed above exit threshold', {
                    candleClose: candleClosePrice.toFixed(2),
                    supertrend: supertrend.toFixed(2),
                    supertrendTrend: supertrendTrend,
                    bbMiddle: bbMiddle.toFixed(2),
                    exitThreshold: exitThreshold.toFixed(2),
                    usedIndicator: usedIndicator,
                    breachAmount: breachAmount.toFixed(2),
                    exitType: 'SUPERTREND_BB_BREAK',
                    timestamp: new Date().toLocaleTimeString()
                });
                await this.executeExit('SHORT_SUPERTREND_BB_BREAK');
            }
            finally {
                this.isProcessingShortExit = false;
            }
        }
        else {
            const cushion = exitThreshold - candleClosePrice;
            this.logger.info(`✅ SHORT position held: Close ${candleClosePrice.toFixed(2)} < Threshold ${exitThreshold.toFixed(2)} (${usedIndicator}) (cushion: +${cushion.toFixed(2)})`);
        }
    }
    async checkOptionRsiExit() {
        if (!this.currentPosition)
            return;
        const now = new Date();
        const entryTime = this.currentPosition.entryTime;
        const secondsSinceEntry = (now.getTime() - entryTime.getTime()) / 1000;
        if (secondsSinceEntry < this.OPTION_RSI_MICRO_GRACE_SECONDS) {
            this.logger.debug(`[RSI EXIT] Skipping: Entry was ${secondsSinceEntry.toFixed(0)}s ago (micro-grace)`);
            return;
        }
        const optionCandles = await this.fetchOption15MinCandles();
        if (optionCandles.length < 15) {
            this.logger.warn(`[RSI EXIT] Insufficient option candles: ${optionCandles.length} (need 15+)`);
            return;
        }
        const latestCandle = optionCandles[optionCandles.length - 1];
        if (!latestCandle) {
            this.logger.warn(`[RSI EXIT] No latest candle available`);
            return;
        }
        const candleCloseTime = new Date(latestCandle.timestamp.getTime() + 15 * 60 * 1000);
        if (candleCloseTime > now) {
            this.logger.debug(`[RSI EXIT] Latest candle not yet closed: ${latestCandle.timestamp.toLocaleTimeString()}`);
            return;
        }
        const optionRsi = this.calculateOptionRSI(optionCandles);
        if (optionRsi < 0) {
            this.logger.warn(`[RSI EXIT] Invalid RSI calculation`);
            return;
        }
        const optionSymbol = this.currentPosition.instrument.tradingsymbol;
        const positionType = this.currentPosition.type;
        this.logger.info(`[RSI EXIT] ${optionSymbol} | RSI(14): ${optionRsi.toFixed(1)} | Threshold: ${this.OPTION_RSI_CLIMAX_THRESHOLD}`);
        if (optionRsi >= this.OPTION_RSI_CLIMAX_THRESHOLD) {
            this.logger.info(`🔥 GAMMA CLIMAX DETECTED: ${optionSymbol} | RSI: ${optionRsi.toFixed(1)} >= ${this.OPTION_RSI_CLIMAX_THRESHOLD}`);
            this.logger.info(`   Position: ${positionType} | Entry: ₹${this.currentPosition.entryPrice.toFixed(2)} | Time in trade: ${(secondsSinceEntry / 60).toFixed(1)} mins`);
            this.logger.info(`   Action: FULL EXIT (Capturing blow-off top)`);
            await this.executeExit(`GAMMA_CLIMAX_RSI${optionRsi.toFixed(0)}`);
        }
        else {
            this.logger.info(`[RSI EXIT] ✅ RSI ${optionRsi.toFixed(1)} < ${this.OPTION_RSI_CLIMAX_THRESHOLD} - Held (no gamma climax)`);
        }
    }
    startOptionRsiMonitoring() {
        if (this.optionRsiInterval || this.optionRsiInitialTimeout) {
            this.logger.debug('[RSI MONITOR] Already running');
            return;
        }
        const now = new Date();
        const currentMinute = now.getMinutes();
        const currentSecond = now.getSeconds();
        const nextBoundaryMinute = Math.ceil((currentMinute + 1) / 15) * 15;
        const minutesUntil = nextBoundaryMinute - currentMinute;
        const msUntilBoundary = (minutesUntil * 60 - currentSecond) * 1000;
        const nextCheckTime = new Date(now.getTime() + msUntilBoundary);
        this.logger.info(`[RSI MONITOR] Starting. Next RSI check at ${nextCheckTime.toLocaleTimeString()} (in ${Math.round(msUntilBoundary / 1000)}s)`);
        this.optionRsiInitialTimeout = setTimeout(() => {
            this.optionRsiInitialTimeout = null;
            if (!this.currentPosition) {
                this.logger.debug('[RSI MONITOR] Position closed before first check, aborting');
                return;
            }
            const firstCheckTime = new Date();
            this.logger.info(`[RSI MONITOR] First check triggered at ${firstCheckTime.toLocaleTimeString()}`);
            this.checkOptionRsiExit().catch(err => this.logger.error('[RSI MONITOR] Error in initial check:', err));
            this.optionRsiInterval = setInterval(async () => {
                if (!this.currentPosition) {
                    this.stopOptionRsiMonitoring();
                    return;
                }
                const checkTime = new Date();
                this.logger.info(`[RSI MONITOR] 15-min check triggered at ${checkTime.toLocaleTimeString()}`);
                try {
                    await this.checkOptionRsiExit();
                }
                catch (error) {
                    this.logger.error('[RSI MONITOR] Error in periodic check:', error);
                }
            }, this.OPTION_RSI_CHECK_INTERVAL);
        }, msUntilBoundary);
    }
    stopOptionRsiMonitoring() {
        if (this.optionRsiInitialTimeout) {
            clearTimeout(this.optionRsiInitialTimeout);
            this.optionRsiInitialTimeout = null;
        }
        if (this.optionRsiInterval) {
            clearInterval(this.optionRsiInterval);
            this.optionRsiInterval = null;
            this.logger.info('[RSI MONITOR] Stopped');
        }
    }
    async check5MinOptionRsiForTrail() {
        if (!this.currentPosition)
            return;
        const now = new Date();
        const secondsSinceEntry = (now.getTime() - this.currentPosition.entryTime.getTime()) / 1000;
        if (secondsSinceEntry < this.OPTION_RSI_MICRO_GRACE_SECONDS) {
            this.logger.debug(`[RSI TRAIL] Skipping: Entry was ${secondsSinceEntry.toFixed(0)}s ago (micro-grace)`);
            return;
        }
        const optionCandles = await this.fetchOption5MinCandles();
        if (optionCandles.length < 15) {
            this.logger.warn(`[RSI TRAIL] Insufficient 5-min option candles: ${optionCandles.length} (need 15+)`);
            return;
        }
        const latestCandle = optionCandles[optionCandles.length - 1];
        if (!latestCandle) {
            this.logger.warn(`[RSI TRAIL] No latest candle available`);
            return;
        }
        const candleCloseTime = new Date(latestCandle.timestamp.getTime() + 5 * 60 * 1000);
        if (candleCloseTime > now) {
            this.logger.debug(`[RSI TRAIL] Latest 5-min candle not yet closed: ${latestCandle.timestamp.toLocaleTimeString()}`);
            return;
        }
        const optionRsi = this.calculateOptionRSI(optionCandles);
        if (optionRsi < 0) {
            this.logger.warn(`[RSI TRAIL] Invalid RSI calculation`);
            return;
        }
        const optionSymbol = this.currentPosition.instrument.tradingsymbol;
        if (!this.rsiTrailActivated) {
            this.logger.info(`[RSI TRAIL] ${optionSymbol} | 5-min RSI(14): ${optionRsi.toFixed(1)} | Activation threshold: ${this.RSI_TRAIL_ACTIVATION_THRESHOLD}`);
            if (optionRsi >= this.RSI_TRAIL_ACTIVATION_THRESHOLD) {
                this.rsiTrailActivated = true;
                this.rsiTrailActivationRsi = optionRsi;
                this.rsiTrailFloorPrice = latestCandle.low;
                this.logger.info(`🔥 RSI TRAIL ACTIVATED: ${optionSymbol} | 5-min RSI: ${optionRsi.toFixed(1)} >= ${this.RSI_TRAIL_ACTIVATION_THRESHOLD}`);
                this.logger.info(`   Floor price: ₹${this.rsiTrailFloorPrice.toFixed(2)} (LOW of ${latestCandle.timestamp.toLocaleTimeString()} candle)`);
                this.logger.info(`   Starting live premium polling every ${this.RSI_TRAIL_POLL_INTERVAL_MS / 1000}s`);
                this.saveCapitalData();
                this.startRsiTrailLivePolling();
            }
        }
        else {
            const previousFloor = this.rsiTrailFloorPrice;
            this.rsiTrailFloorPrice = Math.max(this.rsiTrailFloorPrice, latestCandle.low);
            this.logger.info(`[RSI TRAIL] ${optionSymbol} | 5-min RSI: ${optionRsi.toFixed(1)} | Floor updated: ₹${previousFloor.toFixed(2)} → ₹${this.rsiTrailFloorPrice.toFixed(2)}`);
            if (optionRsi < this.RSI_TRAIL_SECONDARY_EXIT_THRESHOLD) {
                this.logger.info(`🔥 RSI TRAIL SECONDARY EXIT: ${optionSymbol} | 5-min RSI: ${optionRsi.toFixed(1)} < ${this.RSI_TRAIL_SECONDARY_EXIT_THRESHOLD}`);
                this.logger.info(`   Activation RSI was: ${this.rsiTrailActivationRsi.toFixed(1)} | Entry: ₹${this.currentPosition.entryPrice.toFixed(2)}`);
                this.stopRsiTrailMonitoring();
                await this.executeExit(`RSI_TRAIL_SECONDARY_EXIT_RSI${optionRsi.toFixed(0)}`);
            }
        }
    }
    startRsiTrail5MinMonitoring() {
        if (this.rsiTrail5MinCheckInterval || this.rsiTrail5MinInitialTimeout) {
            this.logger.debug('[RSI TRAIL] 5-min monitoring already running');
            return;
        }
        const now = new Date();
        const currentMinute = now.getMinutes();
        const currentSecond = now.getSeconds();
        const nextBoundaryMinute = Math.ceil((currentMinute + 1) / 5) * 5;
        const minutesUntil = nextBoundaryMinute - currentMinute;
        const msUntilBoundary = (minutesUntil * 60 - currentSecond) * 1000;
        const slotStaggerMs = this.slotIndex * 1000 + 2000;
        const totalDelay = msUntilBoundary + slotStaggerMs;
        const nextCheckTime = new Date(now.getTime() + totalDelay);
        this.logger.info(`[RSI TRAIL] Starting 5-min monitoring. Next check at ${nextCheckTime.toLocaleTimeString()} (in ${Math.round(totalDelay / 1000)}s)`);
        if (this.rsiTrailActivated) {
            this.logger.info(`[RSI TRAIL] Resuming with activation state: floor ₹${this.rsiTrailFloorPrice.toFixed(2)}`);
        }
        this.rsiTrail5MinInitialTimeout = setTimeout(() => {
            this.rsiTrail5MinInitialTimeout = null;
            if (!this.currentPosition) {
                this.logger.debug('[RSI TRAIL] Position closed before first check, aborting');
                return;
            }
            this.logger.info(`[RSI TRAIL] First 5-min check triggered at ${new Date().toLocaleTimeString()}`);
            this.check5MinOptionRsiForTrail().catch(err => this.logger.error('[RSI TRAIL] Error in initial check:', err));
            this.rsiTrail5MinCheckInterval = setInterval(async () => {
                if (!this.currentPosition) {
                    this.stopRsiTrailMonitoring();
                    return;
                }
                this.logger.info(`[RSI TRAIL] 5-min check triggered at ${new Date().toLocaleTimeString()}`);
                try {
                    await this.check5MinOptionRsiForTrail();
                }
                catch (error) {
                    this.logger.error('[RSI TRAIL] Error in periodic check:', error);
                }
            }, 5 * 60 * 1000);
        }, totalDelay);
    }
    startRsiTrailLivePolling() {
        if (this.rsiTrailPollingInterval) {
            clearInterval(this.rsiTrailPollingInterval);
            this.rsiTrailPollingInterval = null;
        }
        if (!this.currentPosition || !this.rsiTrailActivated) {
            this.logger.warn('[RSI TRAIL POLL] Cannot start: no position or trail not activated');
            return;
        }
        const optionSymbol = this.currentPosition.instrument.tradingsymbol;
        this.logger.info(`🎯 RSI TRAIL LIVE POLLING STARTED: ${optionSymbol}`, {
            pollInterval: `${this.RSI_TRAIL_POLL_INTERVAL_MS / 1000}s`,
            floorPrice: `₹${this.rsiTrailFloorPrice.toFixed(2)}`,
            activationRsi: this.rsiTrailActivationRsi.toFixed(1)
        });
        this.rsiTrailPollingInterval = setInterval(async () => {
            if (!this.currentPosition) {
                this.stopRsiTrailMonitoring();
                return;
            }
            try {
                const optionTradingSymbol = this.currentPosition.instrument.tradingsymbol;
                const quoteKey = `NFO:${optionTradingSymbol}`;
                const quotes = await this.kiteConnect.getQuote([quoteKey]);
                const optionLTP = quotes[quoteKey]?.last_price;
                if (!optionLTP || optionLTP <= 0) {
                    this.logger.warn('[RSI TRAIL POLL] Failed to fetch option LTP');
                    return;
                }
                if (optionLTP <= this.rsiTrailFloorPrice) {
                    this.logger.info(`🔥 RSI TRAIL EXIT: ${optionTradingSymbol} | LTP ₹${optionLTP.toFixed(2)} <= Floor ₹${this.rsiTrailFloorPrice.toFixed(2)}`);
                    this.logger.info(`   Entry: ₹${this.currentPosition.entryPrice.toFixed(2)} | Activation RSI: ${this.rsiTrailActivationRsi.toFixed(1)}`);
                    this.stopRsiTrailMonitoring();
                    await this.executeExit('RSI_TRAIL_CANDLE_LOW_BREAK');
                    return;
                }
                this.logger.debug(`[RSI TRAIL POLL] ${optionTradingSymbol} LTP: ₹${optionLTP.toFixed(2)} | Floor: ₹${this.rsiTrailFloorPrice.toFixed(2)} | Safe`);
            }
            catch (error) {
                this.logger.error('[RSI TRAIL POLL] Error fetching option quote:', error);
            }
        }, this.RSI_TRAIL_POLL_INTERVAL_MS);
    }
    stopRsiTrailMonitoring() {
        if (this.rsiTrailPollingInterval) {
            clearInterval(this.rsiTrailPollingInterval);
            this.rsiTrailPollingInterval = null;
            this.logger.info('[RSI TRAIL] Live polling stopped');
        }
        if (this.rsiTrail5MinCheckInterval) {
            clearInterval(this.rsiTrail5MinCheckInterval);
            this.rsiTrail5MinCheckInterval = null;
        }
        if (this.rsiTrail5MinInitialTimeout) {
            clearTimeout(this.rsiTrail5MinInitialTimeout);
            this.rsiTrail5MinInitialTimeout = null;
        }
        this.rsiTrailActivated = false;
        this.rsiTrailFloorPrice = 0;
        this.rsiTrailActivationRsi = 0;
        this.logger.info('[RSI TRAIL] Monitoring stopped and state reset');
    }
    async checkShortExitUnified(currentPremium, source) {
        this.logger.warn('⚠️ DEPRECATED: checkShortExitUnified called but real-time polling is disabled');
        return;
    }
    async checkLongExitSimple(currentPremium, source) {
        this.logger.warn('⚠️ DEPRECATED: checkLongExitSimple called but real-time polling is disabled');
        return;
    }
    async executeExit(reason) {
        if (!this.currentPosition)
            return;
        const expFlags = StrategyManager_1.StrategyManager.getExperimentalFlags();
        if (expFlags.minHoldingTimeMinutes > 0) {
            const heldMinutes = (Date.now() - new Date(this.currentPosition.entryTime).getTime()) / 60000;
            const isExempt = reason === 'EMERGENCY_HARD_STOP' ||
                reason === 'STRUCTURAL_STOCK_STOP' ||
                reason.startsWith('EOD_') ||
                reason.startsWith('MANUAL_') ||
                reason.startsWith('GAMMA_CLIMAX_') ||
                reason.startsWith('RSI_TRAIL_') ||
                reason === 'MONITORING_RESTART_FAILED';
            if (!isExempt && heldMinutes < expFlags.minHoldingTimeMinutes) {
                this.logger.info(`⏸️ Exit '${reason}' DEFERRED — held only ${heldMinutes.toFixed(1)} min (min ${expFlags.minHoldingTimeMinutes})`);
                return;
            }
        }
        if (this.isExecutingExit) {
            this.logger.warn(`⚠️ Exit already in progress, skipping duplicate exit trigger: ${reason}`);
            return;
        }
        this.isExecutingExit = true;
        try {
            const orderResult = await this.executeOrder('SELL', this.currentPosition.instrument, this.currentPosition.quantity);
            if (orderResult.success) {
                const totalQuantity = this.currentPosition.quantity * this.currentPosition.instrument.lot_size;
                const grossPnl = (orderResult.price - this.currentPosition.entryPrice) * totalQuantity;
                const charges = (0, ChargesCalculator_1.calculateRoundTripCharges)(this.currentPosition.entryPrice, orderResult.price, totalQuantity);
                const netPnl = grossPnl - charges.totalCharges;
                this.currentCapital += netPnl;
                const tradeRecord = {
                    tradeId: `BB_${Date.now()}`,
                    entryOrderId: this.currentPosition.entryOrderId,
                    exitOrderId: orderResult.orderId || `BB_EXIT_${Date.now()}`,
                    instrument: this.currentPosition.instrument,
                    direction: this.currentPosition.type,
                    quantity: this.currentPosition.quantity * this.currentPosition.instrument.lot_size,
                    entryPrice: this.currentPosition.entryPrice,
                    exitPrice: orderResult.price,
                    entryTime: this.currentPosition.entryTime,
                    exitTime: new Date(),
                    grossPnl: grossPnl,
                    charges: {
                        buy: charges.buy,
                        sell: charges.sell,
                        totalCharges: charges.totalCharges
                    },
                    pnl: netPnl,
                    exitReason: reason,
                    status: 'CLOSED',
                    strategy: 'BOLLINGER_BAND'
                };
                this.tradeHistory.push(tradeRecord);
                this.logger.info('✅ Position closed', {
                    reason,
                    instrument: this.currentPosition.instrument.tradingsymbol,
                    entryPrice: this.currentPosition.entryPrice,
                    exitPrice: orderResult.price,
                    grossPnl: grossPnl.toFixed(2),
                    charges: charges.totalCharges.toFixed(2),
                    netPnl: netPnl.toFixed(2),
                    newCapital: this.currentCapital.toFixed(2)
                });
                StrategyManager_1.StrategyManager.recordSymbolExitStatic(this.signalSymbol);
                if (netPnl < 0) {
                    StrategyManager_1.StrategyManager.recordSlotLossStatic(this.slotIndex);
                }
                StrategyManager_1.StrategyManager.recordTradeOutcomeStatic(netPnl);
                this.currentPosition = null;
                try {
                    this.saveCapitalData();
                    this.logger.info("💾 Position cleared from disk after exit");
                    this.validateCapitalConsistency();
                }
                catch (saveError) {
                    this.logger.error("🚨 CRITICAL: Failed to save cleared position, retrying...", saveError);
                    try {
                        this.saveCapitalData();
                        this.logger.info("💾 Position cleared from disk after exit (retry successful)");
                    }
                    catch (retryError) {
                        this.logger.error("🚨 CRITICAL: Failed to save cleared position after retry!", retryError);
                        throw new Error("Failed to persist position clear - manual intervention required");
                    }
                }
                this.cachedCurrentPrice = 0;
                this.cachedUnrealizedPnL = 0;
                this.lastPriceUpdateTime = null;
                this.updateMetrics({
                    profitLoss: this.metrics.profitLoss,
                    healthStatus: 'healthy',
                    lastTradeTime: new Date()
                });
                this.stopPositionMonitoring();
                this.stopEmergencyStopMonitoring();
                this.stopOptionRsiMonitoring();
                this.stopRsiTrailMonitoring();
            }
            else {
                this.logger.error(`🚨 EXIT FAILED: Could not close ${this.currentPosition?.instrument?.tradingsymbol} | Reason: ${reason} | Position remains OPEN`, {
                    instrument: this.currentPosition?.instrument?.tradingsymbol,
                    reason
                });
            }
        }
        catch (error) {
            this.logger.error('❌ Error executing exit:', error);
            if (this.currentPosition) {
                this.logger.warn('⚠️ Exit error but position object still exists in strategy state');
                this.logger.warn('🔧 Keeping position state to continue monitoring');
                this.logger.warn('📊 Position monitoring will continue - manual intervention may be needed if position actually closed');
                return;
            }
            else {
                this.logger.info('✅ Position already cleared - error occurred after successful exit');
                this.logger.info('📝 This is likely a benign error during cleanup');
            }
        }
        finally {
            this.isExecutingExit = false;
        }
    }
    async forceClosePosition(reason) {
        if (!this.currentPosition)
            return;
        this.logger.warn('🔴 Force closing position:', reason);
        await this.executeExit(reason);
    }
    scheduleEODExit() {
        const now = new Date();
        const eodTime = new Date();
        eodTime.setHours(15, 19, 0, 0);
        if (this.eodExitTimer) {
            clearTimeout(this.eodExitTimer);
            delete this.eodExitTimer;
        }
        if (now < eodTime) {
            const delay = eodTime.getTime() - now.getTime();
            this.logger.info(`📅 EOD safety exit scheduled for 3:19 PM (in ${Math.round(delay / 60000)} minutes)`);
            this.eodExitTimer = setTimeout(async () => {
                if (this.currentPosition) {
                    this.logger.warn('🕒 EOD safety exit triggered at 3:19 PM');
                    await this.forceClosePosition('EOD_SAFETY_EXIT_3:19PM');
                }
                else {
                    this.logger.info('✅ No active position at 3:19 PM, no EOD exit needed');
                }
            }, delay);
        }
        else {
            this.logger.info('⏰ Already past 3:19 PM today, no EOD exit scheduled');
        }
    }
    cancelEODExit() {
        if (this.eodExitTimer) {
            clearTimeout(this.eodExitTimer);
            delete this.eodExitTimer;
            this.logger.info('🛑 EOD safety exit timer cancelled');
        }
    }
    startPositionReconciliation() {
        this.stopPositionReconciliation();
        const slotStaggerMs = this.slotIndex * 1000;
        setTimeout(() => {
            this.positionReconciliationInterval = setInterval(async () => {
                if (this.currentPosition) {
                    await this.reconcilePositions();
                }
            }, 2 * 60 * 1000);
            this.logger.info(`✅ Slot ${this.slotIndex + 1} position reconciliation started (checks every 2 minutes, stagger: ${this.slotIndex}s)`);
        }, slotStaggerMs);
    }
    stopPositionReconciliation() {
        if (this.positionReconciliationInterval) {
            clearInterval(this.positionReconciliationInterval);
            delete this.positionReconciliationInterval;
            this.logger.info('🛑 Position reconciliation stopped');
        }
    }
    async reconcilePositions() {
        const wasDisrupted = this.detectReconciliationDisruption();
        if (!this.currentPosition) {
            this.lastReconciliationTime = Date.now();
            return;
        }
        const ourSymbol = this.currentPosition.instrument.tradingsymbol;
        try {
            this.logger.info(`🔄 Reconciling position: ${ourSymbol} (checking broker...)`);
            const brokerPositions = await this.kiteConnect.getPositions();
            const brokerPosition = brokerPositions.net.find((p) => p.tradingsymbol === ourSymbol && p.quantity !== 0);
            if (!brokerPosition || brokerPosition.quantity === 0) {
                this.logger.warn('⚠️ POSITION MISMATCH DETECTED!');
                this.logger.warn(`📊 Bot has position ${ourSymbol} but broker does not`);
                this.logger.warn('🔍 Likely causes: Broker auto-squareoff (MIS), manual exit on broker platform, or connection issue');
                this.logger.info('🔄 Auto-reconciling: Fetching exit details and recording P&L...');
                await this.clearActivePosition();
                this.logger.info('✅ Position reconciliation completed successfully');
            }
            else {
                this.logger.info(`✅ Position reconciliation OK: ${ourSymbol} exists at broker (qty: ${brokerPosition.quantity})`);
            }
        }
        catch (error) {
            this.logger.error('❌ Error during position reconciliation:', error);
        }
        finally {
            this.lastReconciliationTime = Date.now();
        }
    }
    detectMasterCycleDisruption() {
        if (!this.lastSuccessfulFetchTime) {
            return false;
        }
        const now = Date.now();
        const timeSinceLastFetch = now - this.lastSuccessfulFetchTime;
        const EXPECTED_INTERVAL = 5 * 60 * 1000;
        const DISRUPTION_THRESHOLD = EXPECTED_INTERVAL * 1.2;
        if (timeSinceLastFetch > DISRUPTION_THRESHOLD) {
            const gapMinutes = Math.floor(timeSinceLastFetch / 60000);
            this.logger.warn('⚠️ MASTER CYCLE DISRUPTION DETECTED!');
            this.logger.warn(`⏱️ Gap: ${gapMinutes} minutes (${timeSinceLastFetch}ms), expected: 5 minutes (${EXPECTED_INTERVAL}ms)`);
            this.logger.warn('💤 Likely cause: System sleep/hibernate disrupted setInterval alignment');
            this.logger.info('🔄 Recovery: Will realign to next 5-minute boundary after this fetch');
            return true;
        }
        return false;
    }
    detectPositionMonitoringDisruption() {
        if (!this.lastPollingTime) {
            return false;
        }
        const now = Date.now();
        const timeSinceLastPoll = now - this.lastPollingTime.getTime();
        const EXPECTED_INTERVAL = 1000;
        const DISRUPTION_THRESHOLD = 10000;
        if (timeSinceLastPoll > DISRUPTION_THRESHOLD) {
            const gapSeconds = Math.floor(timeSinceLastPoll / 1000);
            this.logger.error('🚨 POSITION MONITORING DISRUPTION DETECTED!');
            this.logger.error(`⏱️ Gap: ${gapSeconds} seconds (${timeSinceLastPoll}ms), expected: <2 seconds`);
            this.logger.error('💤 Likely cause: System sleep/hibernate disrupted position monitoring');
            this.logger.error('⚠️ CRITICAL: Stop loss may have been breached during sleep gap');
            this.logger.info('🔄 Recovery: Forcing immediate position check with current premium');
            this.healthStatus.dataStreamHealthy = false;
            this.updateMetrics({ healthStatus: 'warning' });
            return true;
        }
        return false;
    }
    detectReconciliationDisruption() {
        if (!this.lastReconciliationTime) {
            return false;
        }
        const now = Date.now();
        const timeSinceLastReconciliation = now - this.lastReconciliationTime;
        const EXPECTED_INTERVAL = 5 * 60 * 1000;
        const DISRUPTION_THRESHOLD = 10 * 60 * 1000;
        if (timeSinceLastReconciliation > DISRUPTION_THRESHOLD) {
            const gapMinutes = Math.floor(timeSinceLastReconciliation / 60000);
            this.logger.warn('⚠️ RECONCILIATION DISRUPTION DETECTED!');
            this.logger.warn(`⏱️ Gap: ${gapMinutes} minutes, expected: 5 minutes`);
            this.logger.warn('💤 Likely cause: System sleep disrupted reconciliation cycle');
            this.logger.info('🔄 Recovery: Executing reconciliation now to detect broker changes');
            return true;
        }
        return false;
    }
    getLastCompletedCandleClose() {
        if (this.candleHistory.length === 0) {
            return 0;
        }
        const lastCandle = this.candleHistory[this.candleHistory.length - 1];
        return lastCandle ? lastCandle.close : 0;
    }
    getNextTuesdayExpiry() {
        const today = new Date();
        const currentDay = today.getDay();
        const tuesday = 2;
        let daysToAdd = tuesday - currentDay;
        if (daysToAdd <= 0) {
            daysToAdd += 7;
        }
        const nextTuesday = new Date(today);
        nextTuesday.setDate(today.getDate() + daysToAdd);
        nextTuesday.setHours(15, 30, 0, 0);
        return nextTuesday;
    }
    getNextStockOptionExpiry(stockOptions) {
        const uniqueExpiries = [...new Set(stockOptions.map((opt) => new Date(opt.expiry).getTime()))]
            .sort((a, b) => a - b)
            .map(ts => new Date(ts));
        const now = new Date();
        for (const expiry of uniqueExpiries) {
            if (expiry.getTime() > now.getTime()) {
                this.logger.info(`📅 Found ${this.signalSymbol} expiry: ${expiry.toDateString()} (${uniqueExpiries.length} total expiries available)`);
                return expiry;
            }
        }
        if (uniqueExpiries.length > 0) {
            const latestExpiry = uniqueExpiries[uniqueExpiries.length - 1];
            this.logger.warn(`⚠️ No future ${this.signalSymbol} expiries found, using latest available: ${latestExpiry.toDateString()}`);
            return latestExpiry;
        }
        throw new Error(`No expiry dates found for ${this.signalSymbol} options`);
    }
    findATMStrike(options, currentPrice) {
        if (options.length === 0) {
            throw new Error('No options available to find ATM strike');
        }
        let atmStrike = options[0].strike;
        let smallestDiff = Math.abs(options[0].strike - currentPrice);
        for (const option of options) {
            const diff = Math.abs(option.strike - currentPrice);
            if (diff < smallestDiff) {
                smallestDiff = diff;
                atmStrike = option.strike;
            }
        }
        this.logger.debug(`🎯 ATM Strike calculation: Price=${currentPrice}, ATM=${atmStrike}, Diff=${smallestDiff.toFixed(2)}`);
        return atmStrike;
    }
    async selectOptionInstrument(optionType, spotPrice) {
        const MIN_PREMIUM = 40;
        try {
            const instruments = await this.instrumentCache.getNFOInstruments();
            const stockOptions = instruments.filter((inst) => inst.name === this.signalSymbol &&
                inst.instrument_type === optionType &&
                new Date(inst.expiry) > new Date());
            if (stockOptions.length === 0) {
                this.logger.warn(`⚠️ No ${this.signalSymbol} options found.`);
                const availableNames = [...new Set(instruments.map((i) => i.name))].sort();
                this.logger.debug(`Available option names in NFO: ${availableNames.slice(0, 20).join(', ')}...`);
                throw new Error(`No ${this.signalSymbol} options found in NFO instruments`);
            }
            const nextExpiry = this.getNextStockOptionExpiry(stockOptions);
            this.logger.info(`🎯 Selecting ${optionType} option using ATM-BASED selection for ${this.signalSymbol}`);
            this.logger.info(`📅 Target expiry: ${nextExpiry.toDateString()}`);
            const expiryOptions = stockOptions.filter((opt) => {
                const isSameExpiry = Math.abs(new Date(opt.expiry).getTime() - nextExpiry.getTime()) < 24 * 60 * 60 * 1000;
                return isSameExpiry;
            });
            if (expiryOptions.length === 0) {
                throw new Error(`No suitable ${this.signalSymbol} options found for expiry ${nextExpiry.toDateString()}`);
            }
            expiryOptions.sort((a, b) => a.strike - b.strike);
            const atmStrike = this.findATMStrike(expiryOptions, spotPrice);
            const atmOption = expiryOptions.find((opt) => opt.strike === atmStrike);
            if (!atmOption) {
                throw new Error(`ATM strike ${atmStrike} not found in ${this.signalSymbol} options`);
            }
            this.logger.info(`🎯 ATM Strike: ₹${atmStrike} (${this.signalSymbol} Spot: ₹${spotPrice.toFixed(2)})`);
            const atmIndex = expiryOptions.findIndex((opt) => opt.strike === atmStrike);
            const otmIndex = optionType === 'CE' ? atmIndex + 1 : atmIndex - 1;
            const candidates = [];
            candidates.push({ option: atmOption, strikeType: 'ATM' });
            if (otmIndex >= 0 && otmIndex < expiryOptions.length) {
                candidates.push({ option: expiryOptions[otmIndex], strikeType: '1-OTM' });
            }
            const tokens = candidates.map(c => c.option.instrument_token);
            const quotes = await this.kiteConnect.getQuote(tokens);
            for (const candidate of candidates) {
                const quote = quotes[candidate.option.instrument_token];
                const premium = quote?.last_price || 0;
                this.logger.info(`📊 Checking ${candidate.strikeType} Strike ₹${candidate.option.strike}: Premium ₹${premium.toFixed(2)}`);
                if (premium >= MIN_PREMIUM) {
                    candidate.option.last_price = premium;
                    candidate.option.strikeType = candidate.strikeType;
                    this.logger.info(`✅ Selected ${candidate.strikeType} option`, {
                        tradingsymbol: candidate.option.tradingsymbol,
                        strike: candidate.option.strike,
                        premium: premium.toFixed(2),
                        strikeType: candidate.strikeType
                    });
                    return candidate.option;
                }
                else {
                    this.logger.warn(`⚠️ ${candidate.strikeType} Strike ₹${candidate.option.strike} rejected: Premium ₹${premium.toFixed(2)} < ₹${MIN_PREMIUM}`);
                }
            }
            this.logger.error(`❌ No ${this.signalSymbol} ${optionType} option found with premium ≥ ₹${MIN_PREMIUM}`);
            this.logger.error(`❌ ATM and 1-OTM both have insufficient liquidity`);
            return null;
        }
        catch (error) {
            this.logger.error('Error selecting option instrument:', error);
            return null;
        }
    }
    calculateLimitPrice(ltp, transaction) {
        const BUFFER_PERCENT = 0.03;
        const TICK_SIZE = 0.05;
        const rawPrice = transaction === 'BUY'
            ? ltp * (1 + BUFFER_PERCENT)
            : ltp * (1 - BUFFER_PERCENT);
        const limitPrice = Math.round(rawPrice / TICK_SIZE) * TICK_SIZE;
        return Math.max(limitPrice, TICK_SIZE);
    }
    async executeOrder(transaction, instrument, quantity) {
        try {
            this.logger.info('Executing order', {
                transaction,
                instrument: instrument.tradingsymbol,
                quantity
            });
            const quoteKey = `${instrument.exchange}:${instrument.tradingsymbol}`;
            const quotes = await this.kiteConnect.getQuote([quoteKey]);
            const quoteData = quotes[quoteKey];
            const ltp = quoteData?.last_price;
            if (!ltp || ltp <= 0) {
                this.logger.error('Failed to fetch LTP for limit price calculation', {
                    instrument: instrument.tradingsymbol,
                    quoteKey,
                    quotes
                });
                return { success: false, price: 0 };
            }
            const MIN_OPTION_PREMIUM = 40;
            const inferredDirection = String(instrument.tradingsymbol || '').endsWith('CE') ? 'LONG' : 'SHORT';
            if (ltp < MIN_OPTION_PREMIUM && transaction === 'BUY') {
                this.logger.error(`❌ LIQUIDITY GUARD: Option premium ₹${ltp.toFixed(2)} is below minimum ₹${MIN_OPTION_PREMIUM}`, {
                    instrument: instrument.tradingsymbol,
                    ltp,
                    minRequired: MIN_OPTION_PREMIUM,
                    reason: 'Penny options have high slippage and low liquidity - entry rejected for safety'
                });
                this.logSignalLifecycle('ENTRY_REJECTED', inferredDirection, 'low_premium', { instrument: instrument.tradingsymbol, ltp, minRequired: MIN_OPTION_PREMIUM });
                return { success: false, price: 0 };
            }
            if (ltp < MIN_OPTION_PREMIUM && transaction === 'SELL') {
                this.logger.warn(`⚠️ LIQUIDITY WARNING: Exiting at low premium ₹${ltp.toFixed(2)} (below ₹${MIN_OPTION_PREMIUM}) - proceeding with exit`, {
                    instrument: instrument.tradingsymbol,
                    ltp
                });
            }
            const expFlags = StrategyManager_1.StrategyManager.getExperimentalFlags();
            const lotSize = instrument.lot_size || 1;
            const dynamicMinOI = (expFlags.liquidityOiMultiplier ?? 500) * lotSize;
            const minVolFallback = expFlags.liquidityMinVolFallback ?? 500;
            const oi = quoteData?.oi || 0;
            const volume = quoteData?.volume || 0;
            const liquidityOk = oi >= dynamicMinOI || volume >= minVolFallback;
            if (!liquidityOk && transaction === 'BUY') {
                this.logger.error(`❌ EXECUTION ABORTED: Insufficient liquidity ${instrument.tradingsymbol} — OI:${oi} (need ≥${dynamicMinOI}) Vol:${volume} (or ≥${minVolFallback})`, {
                    instrument: instrument.tradingsymbol,
                    oi,
                    volume,
                    dynamicMinOI,
                    minVolFallback,
                    lotSize,
                    reason: 'Both OI and Vol below thresholds - entry aborted for safety'
                });
                this.logSignalLifecycle('ENTRY_REJECTED', inferredDirection, 'low_liquidity', { instrument: instrument.tradingsymbol, oi, volume, dynamicMinOI, minVolFallback, lotSize });
                return { success: false, price: 0 };
            }
            if (!liquidityOk && transaction === 'SELL') {
                this.logger.warn(`⚠️ LIQUIDITY WARNING: Low liquidity exit - OI:${oi} Vol:${volume} - proceeding with exit anyway`, {
                    instrument: instrument.tradingsymbol
                });
            }
            this.logger.info(`✅ Liquidity check passed: OI:${oi}, Vol:${volume}`, {
                instrument: instrument.tradingsymbol
            });
            if (transaction === 'BUY') {
                const MAX_SPREAD_PERCENT = 2.0;
                const depth = quoteData?.depth;
                const bestBid = depth?.buy?.[0]?.price || 0;
                const bestAsk = depth?.sell?.[0]?.price || 0;
                if (bestBid > 0 && bestAsk > 0) {
                    const spreadPercent = ((bestAsk - bestBid) / bestBid) * 100;
                    if (spreadPercent > MAX_SPREAD_PERCENT) {
                        this.logger.error(`❌ HIGH_SPREAD_REJECTION: ${instrument.tradingsymbol} spread ${spreadPercent.toFixed(2)}% > ${MAX_SPREAD_PERCENT}% threshold | Bid:₹${bestBid.toFixed(2)} Ask:₹${bestAsk.toFixed(2)} - ENTRY ABORTED`, {
                            instrument: instrument.tradingsymbol,
                            bestBid,
                            bestAsk,
                            spreadPercent: spreadPercent.toFixed(2),
                            maxAllowed: MAX_SPREAD_PERCENT,
                            reason: 'Wide bid-ask spread indicates high impact cost - entry rejected for safety'
                        });
                        this.logSignalLifecycle('ENTRY_REJECTED', inferredDirection, 'wide_spread', { instrument: instrument.tradingsymbol, bestBid, bestAsk, spreadPercent: Number(spreadPercent.toFixed(2)), maxAllowed: MAX_SPREAD_PERCENT });
                        return { success: false, price: 0 };
                    }
                    this.logger.info(`✅ Spread check passed: ${spreadPercent.toFixed(2)}% (max ${MAX_SPREAD_PERCENT}%)`, {
                        instrument: instrument.tradingsymbol,
                        bestBid,
                        bestAsk
                    });
                }
                else {
                    this.logger.warn(`⚠️ Could not verify spread (empty depth) - proceeding with caution`, {
                        instrument: instrument.tradingsymbol,
                        depthAvailable: !!depth
                    });
                }
            }
            const limitPrice = this.calculateLimitPrice(ltp, transaction);
            this.logger.info('Calculated limit price with market protection', {
                ltp,
                transaction,
                limitPrice,
                bufferPercent: '3%'
            });
            const orderParams = {
                exchange: instrument.exchange,
                tradingsymbol: instrument.tradingsymbol,
                transaction_type: transaction,
                quantity: quantity * instrument.lot_size,
                product: 'MIS',
                order_type: 'LIMIT',
                price: limitPrice,
                validity: 'DAY',
                tag: 'BB_TRADE'
            };
            const orderResponse = await this.kiteConnect.placeOrder('regular', orderParams);
            if (orderResponse.order_id) {
                try {
                    const fillPrice = await this.waitForOrderExecution(orderResponse.order_id);
                    return {
                        success: true,
                        price: fillPrice,
                        orderId: orderResponse.order_id
                    };
                }
                catch (waitError) {
                    if (transaction === 'SELL' && waitError.message?.includes('timed out and was cancelled')) {
                        this.logger.warn(`🔥 EXIT RETRY: First exit timed out for ${instrument.tradingsymbol}. Placing aggressive order...`);
                        try {
                            const retryQuotes = await this.kiteConnect.getQuote([quoteKey]);
                            const retryLtp = retryQuotes[quoteKey]?.last_price;
                            if (retryLtp && retryLtp > 0) {
                                const TICK_SIZE = 0.05;
                                const aggressivePrice = Math.max(Math.round((retryLtp * 0.90) / TICK_SIZE) * TICK_SIZE, TICK_SIZE);
                                this.logger.warn(`🔥 EXIT RETRY: SELL at ₹${aggressivePrice.toFixed(2)} (LTP: ₹${retryLtp.toFixed(2)}, -10%)`, {
                                    instrument: instrument.tradingsymbol, retryLtp, aggressivePrice
                                });
                                const retryOrder = await this.kiteConnect.placeOrder('regular', {
                                    ...orderParams, price: aggressivePrice, tag: 'BB_EXIT_RETRY'
                                });
                                if (retryOrder.order_id) {
                                    const retryFill = await this.waitForOrderExecution(retryOrder.order_id);
                                    return { success: true, price: retryFill, orderId: retryOrder.order_id };
                                }
                            }
                        }
                        catch (retryError) {
                            this.logger.error(`❌ EXIT RETRY ALSO FAILED for ${instrument.tradingsymbol}:`, retryError);
                        }
                    }
                    throw waitError;
                }
            }
            return { success: false, price: 0 };
        }
        catch (error) {
            this.logger.error('Order execution failed:', error);
            return { success: false, price: 0 };
        }
    }
    async waitForOrderExecution(orderId) {
        const maxAttempts = 24;
        const checkInterval = 5000;
        for (let attempt = 0; attempt < maxAttempts; attempt++) {
            try {
                const orderHistory = await this.kiteConnect.getOrderHistory(orderId);
                const latestOrder = orderHistory[orderHistory.length - 1];
                if (latestOrder.status === 'COMPLETE') {
                    this.logger.info(`✅ Order ${orderId} filled at ₹${latestOrder.average_price || latestOrder.price}`);
                    return latestOrder.average_price || latestOrder.price;
                }
                if (['REJECTED', 'CANCELLED'].includes(latestOrder.status)) {
                    throw new Error(`Order ${latestOrder.status}: ${latestOrder.status_message}`);
                }
                await this.sleep(checkInterval);
            }
            catch (error) {
                this.logger.error(`Error checking order status (attempt ${attempt + 1}):`, error);
            }
        }
        this.logger.error(`❌ Order ${orderId} timed out after 2 minutes. Attempting to CANCEL to prevent orphan...`);
        try {
            await this.kiteConnect.cancelOrder('regular', orderId);
            this.logger.info(`🗑️ Cancellation request sent for order ${orderId}`);
            await this.sleep(2000);
            const finalHistory = await this.kiteConnect.getOrderHistory(orderId);
            const finalStatus = finalHistory[finalHistory.length - 1];
            if (finalStatus.status === 'COMPLETE') {
                this.logger.warn(`⚠️ Order ${orderId} filled during cancellation attempt! Price: ₹${finalStatus.average_price}`);
                return finalStatus.average_price || finalStatus.price;
            }
            if (finalStatus.status === 'CANCELLED') {
                this.logger.info(`✅ Orphan order ${orderId} cancelled successfully. No position created.`);
                throw new Error('Order execution timed out and was cancelled to prevent orphan position');
            }
            this.logger.error(`💀 CRITICAL: Order ${orderId} neither filled nor cancelled! Status: ${finalStatus.status}`);
            this.logger.error(`💀 MANUAL INTERVENTION REQUIRED - Check broker terminal immediately!`);
            throw new Error(`Order in unknown state (${finalStatus.status}) - MANUAL CHECK REQUIRED`);
        }
        catch (cancelError) {
            if (cancelError.message?.includes('cancelled') || cancelError.message?.includes('MANUAL CHECK')) {
                throw cancelError;
            }
            this.logger.error(`💀 CRITICAL: Failed to cancel orphan order ${orderId}!`, cancelError);
            this.logger.error(`💀 MANUAL INTERVENTION REQUIRED - Order may fill later causing unknown position!`);
            throw new Error(`Order cancellation failed - MANUAL INTERVENTION REQUIRED: ${cancelError.message}`);
        }
    }
    trackError(errorType, error, isCritical = false) {
        const now = new Date();
        const currentCount = this.errorCounts.get(errorType) || 0;
        this.errorCounts.set(errorType, currentCount + 1);
        this.lastErrorTime.set(errorType, now);
        this.healthStatus.consecutiveErrors += 1;
        if (isCritical) {
            this.healthStatus.criticalErrorsToday += 1;
            this.healthStatus.executionHealthy = false;
        }
        const errorContext = {
            errorType,
            count: currentCount + 1,
            isCritical,
            consecutiveErrors: this.healthStatus.consecutiveErrors,
            strategyStatus: this.getStatus(),
            hasPosition: !!this.currentPosition,
            currentStockLTP: this.currentStockLTP,
            signalSymbol: this.signalSymbol,
            timestamp: now.toISOString()
        };
        if (isCritical) {
            this.logger.error(`🚨 CRITICAL ERROR [${errorType}]: ${error?.message || error}`, errorContext);
        }
        else {
            this.logger.warn(`⚠️ ERROR [${errorType}]: ${error?.message || error}`, errorContext);
        }
        if (this.healthStatus.consecutiveErrors >= 5) {
            this.logger.error(`🔥 STRATEGY HEALTH ALERT: ${this.healthStatus.consecutiveErrors} consecutive errors detected!`, {
                errorCounts: Object.fromEntries(this.errorCounts),
                healthStatus: this.healthStatus
            });
        }
    }
    resetErrorCount() {
        this.healthStatus.consecutiveErrors = 0;
        this.healthStatus.dataStreamHealthy = true;
        this.healthStatus.executionHealthy = true;
        this.healthStatus.lastHeartbeat = new Date();
    }
    getHealthReport() {
        const now = new Date();
        const timeSinceHeartbeat = now.getTime() - this.healthStatus.lastHeartbeat.getTime();
        return {
            overall: this.healthStatus.dataStreamHealthy && this.healthStatus.executionHealthy && timeSinceHeartbeat < 60000,
            dataStream: this.healthStatus.dataStreamHealthy,
            execution: this.healthStatus.executionHealthy,
            timeSinceHeartbeat: Math.floor(timeSinceHeartbeat / 1000),
            consecutiveErrors: this.healthStatus.consecutiveErrors,
            criticalErrorsToday: this.healthStatus.criticalErrorsToday,
            errorBreakdown: Object.fromEntries(this.errorCounts),
            candleHistoryLength: this.candleHistory.length,
            hasPosition: !!this.currentPosition,
            currentStockLTP: this.currentStockLTP,
            signalSymbol: this.signalSymbol,
            lastUpdate: now.toISOString()
        };
    }
    getCurrentCapital() {
        return this.currentCapital;
    }
    getTotalPnL() {
        return this.currentCapital - this.INITIAL_CAPITAL;
    }
    validateCapitalConsistency() {
        try {
            const calculatedCapital = this.INITIAL_CAPITAL + this.tradeHistory.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
            const diff = Math.abs(this.currentCapital - calculatedCapital);
            if (diff > 1) {
                this.logger.error('❌ Capital mismatch detected!', {
                    currentCapital: this.currentCapital.toFixed(2),
                    calculatedFromHistory: calculatedCapital.toFixed(2),
                    difference: diff.toFixed(2),
                    totalTrades: this.tradeHistory.length,
                    initialCapital: this.INITIAL_CAPITAL,
                    totalPnLFromTrades: this.tradeHistory.reduce((sum, trade) => sum + (trade.pnl || 0), 0).toFixed(2)
                });
                return { valid: false, difference: diff };
            }
            this.logger.debug('✅ Capital validation passed', {
                capital: this.currentCapital.toFixed(2),
                trades: this.tradeHistory.length
            });
            return { valid: true, difference: diff };
        }
        catch (error) {
            this.logger.error('Error validating capital:', error);
            return { valid: false, difference: 0 };
        }
    }
    getTradeHistory() {
        return [...this.tradeHistory];
    }
    getRecentTrades(count = 10) {
        return this.tradeHistory.slice(-count);
    }
    getTradingStats() {
        const totalTrades = this.tradeHistory.length;
        const closedTrades = this.tradeHistory.filter(trade => trade.status === 'CLOSED');
        const winningTrades = closedTrades.filter(trade => (trade.pnl || 0) > 0);
        const losingTrades = closedTrades.filter(trade => (trade.pnl || 0) < 0);
        const totalPnL = this.getTotalPnL();
        const avgWin = winningTrades.length > 0 ?
            winningTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0) / winningTrades.length : 0;
        const avgLoss = losingTrades.length > 0 ?
            losingTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0) / losingTrades.length : 0;
        const profitFactor = Math.abs(avgLoss) > 0 ?
            Math.abs(avgWin * winningTrades.length) / Math.abs(avgLoss * losingTrades.length) : 0;
        const initialCapital = this.INITIAL_CAPITAL;
        const roi = initialCapital > 0 ? ((totalPnL / initialCapital) * 100) : 0;
        return {
            totalTrades,
            closedTrades: closedTrades.length,
            profitableTrades: winningTrades.length,
            lossTrades: losingTrades.length,
            winRate: closedTrades.length > 0 ? ((winningTrades.length / closedTrades.length) * 100).toFixed(2) : '0.00',
            totalPnL: totalPnL.toFixed(2),
            avgWin: avgWin.toFixed(2),
            avgLoss: avgLoss.toFixed(2),
            profitFactor: profitFactor.toFixed(2),
            roi: roi.toFixed(2),
            currentCapital: this.currentCapital.toFixed(2),
            capitalChange: (this.currentCapital - this.INITIAL_CAPITAL).toFixed(2),
            capitalChangePercent: ((this.currentCapital - this.INITIAL_CAPITAL) / this.INITIAL_CAPITAL * 100).toFixed(2)
        };
    }
    async fetchLatest5MinuteCandleWithRetry() {
        try {
            await this.fetchLatest5MinuteCandle();
            this.stopCandleRetryMechanism();
        }
        catch (error) {
            this.logger.error('?? 5-minute candle fetch failed, starting retry mechanism:', error);
            this.startCandleRetryMechanism();
        }
    }
    async executeLongEntryWithRetry(stockPrice, entryCandleHigh, entryCandleLow, entryCandleTimestamp, breakoutConsecutiveCount) {
        try {
            await this.retryOperation(() => this.executeLongEntry(stockPrice, entryCandleHigh, entryCandleLow, entryCandleTimestamp, breakoutConsecutiveCount), 'LONG Entry Execution', 3, this.TRADE_RETRY_DELAYS);
        }
        catch (error) {
            this.logger.error('❌ LONG entry failed after all retry attempts:', error);
            this.trackError('execution_long_entry_retry_failed', error, true);
        }
    }
    async executeShortEntryWithRetry(stockPrice, entryCandleHigh, entryCandleLow, entryCandleTimestamp, breakoutConsecutiveCount) {
        try {
            await this.retryOperation(() => this.executeShortEntry(stockPrice, entryCandleHigh, entryCandleLow, entryCandleTimestamp, breakoutConsecutiveCount), 'SHORT Entry Execution', 3, this.TRADE_RETRY_DELAYS);
        }
        catch (error) {
            this.logger.error('❌ SHORT entry failed after all retry attempts:', error);
            this.trackError('execution_short_entry_retry_failed', error, true);
        }
    }
    async retryOperation(operation, operationName, maxAttempts = this.MAX_RETRY_ATTEMPTS, delays = this.TRADE_RETRY_DELAYS) {
        let lastError;
        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                const result = await operation();
                if (attempt > 1) {
                    this.logger.info(`? ${operationName} succeeded on attempt ${attempt}`);
                }
                return result;
            }
            catch (error) {
                lastError = error;
                this.logger.warn(`?? ${operationName} attempt ${attempt}/${maxAttempts} failed:`, error);
                if (attempt < maxAttempts) {
                    const delay = attempt <= delays.length ? delays[attempt - 1] : delays[delays.length - 1];
                    this.logger.info(`?? Retrying ${operationName} in ${delay}ms...`);
                    await this.sleep(delay);
                }
            }
        }
        this.logger.error(`? ${operationName} failed after ${maxAttempts} attempts`);
        throw lastError;
    }
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    startCandleRetryMechanism() {
        if (this.candleRetryTimer) {
            clearInterval(this.candleRetryTimer);
        }
        this.candleRetryTimer = setInterval(async () => {
            try {
                await this.fetchLatest5MinuteCandle();
                this.stopCandleRetryMechanism();
                this.logger.info('? Candle fetch recovered successfully');
            }
            catch (error) {
                this.logger.warn('?? Candle retry failed, will try again in 10 seconds');
            }
        }, this.CANDLE_RETRY_INTERVAL);
        this.logger.info('?? Started candle retry mechanism (10-second intervals)');
    }
    stopCandleRetryMechanism() {
        if (this.candleRetryTimer) {
            clearInterval(this.candleRetryTimer);
            this.candleRetryTimer = undefined;
            this.logger.info('? Stopped candle retry mechanism (operation successful)');
        }
    }
}
exports.BollingerBandStrategy = BollingerBandStrategy;
//# sourceMappingURL=BollingerBandStrategy.js.map