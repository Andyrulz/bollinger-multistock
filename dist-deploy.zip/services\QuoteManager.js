"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuoteManager = void 0;
class QuoteManager {
    constructor(kiteConnect, logger) {
        this.kiteConnect = kiteConnect;
        this.logger = logger;
        this.subscribers = new Map();
        this.pollingInterval = null;
        this.isPolling = false;
        this.consecutiveErrors = 0;
        this.lastSuccessfulFetch = Date.now();
    }
    subscribe(symbol, callback) {
        if (!this.subscribers.has(symbol)) {
            this.subscribers.set(symbol, new Set());
        }
        this.subscribers.get(symbol).add(callback);
        this.logger.debug(`📊 QuoteManager: Subscribed to ${symbol} (Total symbols: ${this.subscribers.size})`);
        if (!this.isPolling) {
            this.startPolling();
        }
    }
    unsubscribe(symbol, callback) {
        const callbacks = this.subscribers.get(symbol);
        if (callbacks) {
            callbacks.delete(callback);
            if (callbacks.size === 0) {
                this.subscribers.delete(symbol);
                this.logger.debug(`📉 QuoteManager: Unsubscribed from ${symbol} (Remaining: ${this.subscribers.size})`);
            }
        }
        if (this.subscribers.size === 0 && this.isPolling) {
            this.stopPolling();
        }
    }
    startPolling() {
        if (this.isPolling)
            return;
        this.logger.info("🔄 QuoteManager: Starting polling loop");
        this.isPolling = true;
        this.consecutiveErrors = 0;
        this.pollingInterval = setInterval(async () => {
            await this.fetchAndPublish();
        }, 1000);
    }
    stopPolling() {
        if (!this.isPolling)
            return;
        this.logger.info("⏸️ QuoteManager: Stopping polling loop (0 subscribers)");
        if (this.pollingInterval) {
            clearInterval(this.pollingInterval);
            this.pollingInterval = null;
        }
        this.isPolling = false;
    }
    async fetchAndPublish() {
        const symbols = Array.from(this.subscribers.keys());
        if (symbols.length === 0)
            return;
        try {
            const quotes = await this.kiteConnect.getQuote(symbols);
            if (this.consecutiveErrors === 0 && this.subscribers.size > 0) {
                const pollCount = Math.floor((Date.now() - this.lastSuccessfulFetch) / 1000);
                if (pollCount <= 3 && symbols.length > 0) {
                    const firstSymbol = symbols[0];
                    const firstQuote = quotes[firstSymbol];
                    this.logger.info(`📊 [QC] QuoteManager fetched ${symbols.length} symbols:`, {
                        symbols,
                        responseKeys: Object.keys(quotes),
                        sampleQuote: firstQuote ? {
                            symbol: firstSymbol,
                            last_price: firstQuote.last_price,
                            ohlc: firstQuote.ohlc,
                            volume: firstQuote.volume,
                            timestamp: firstQuote.timestamp || firstQuote.last_trade_time,
                        } : 'NO_DATA'
                    });
                }
            }
            let successCount = 0;
            let missingCount = 0;
            for (const [symbol, callbacks] of this.subscribers.entries()) {
                const quote = quotes[symbol];
                if (quote) {
                    const isValid = this.validateQuoteData(symbol, quote);
                    if (isValid) {
                        successCount++;
                        callbacks.forEach((cb) => {
                            try {
                                cb(quote);
                            }
                            catch (error) {
                                this.logger.error(`Error in quote callback for ${symbol}:`, error);
                            }
                        });
                    }
                    else {
                        missingCount++;
                        this.logger.warn(`⚠️ [QC] Invalid quote data for ${symbol} - skipping callbacks`);
                    }
                }
                else {
                    missingCount++;
                    this.logger.warn(`No quote data received for ${symbol}`);
                }
            }
            const now = Date.now();
            if (now - this.lastSuccessfulFetch > 30000 || successCount > 0) {
                this.logger.debug(`📋 [QC] Quote delivery: ${successCount}/${symbols.length} successful, ${missingCount} missing/invalid`);
            }
            this.consecutiveErrors = 0;
            this.lastSuccessfulFetch = Date.now();
        }
        catch (error) {
            this.consecutiveErrors++;
            this.logger.error(`QuoteManager polling error (${this.consecutiveErrors} consecutive):`, error);
            if (this.consecutiveErrors >= 10) {
                this.logger.error("🚨 QuoteManager: 10 consecutive errors, stopping polling");
                this.stopPolling();
            }
        }
    }
    validateQuoteData(symbol, quote) {
        if (!quote || typeof quote !== 'object') {
            this.logger.error(`[QC] ${symbol}: Quote is not an object`, { quote });
            return false;
        }
        if (typeof quote.last_price !== 'number' || quote.last_price <= 0) {
            this.logger.error(`[QC] ${symbol}: Invalid last_price`, {
                last_price: quote.last_price,
                type: typeof quote.last_price
            });
            return false;
        }
        if (!quote.ohlc || typeof quote.ohlc !== 'object') {
            this.logger.warn(`[QC] ${symbol}: Missing OHLC data`, { ohlc: quote.ohlc });
        }
        if (!quote.timestamp && !quote.last_trade_time) {
            this.logger.warn(`[QC] ${symbol}: Missing timestamp data`);
        }
        return true;
    }
    getStats() {
        const now = Date.now();
        const lastFetchAge = now - this.lastSuccessfulFetch;
        const dataStale = lastFetchAge > 5000;
        if (dataStale && this.isPolling) {
            this.logger.warn(`⚠️ QuoteManager: Data feed stale (${(lastFetchAge / 1000).toFixed(1)}s since last update)`);
        }
        return {
            isPolling: this.isPolling,
            subscriberCount: this.subscribers.size,
            symbols: Array.from(this.subscribers.keys()),
            consecutiveErrors: this.consecutiveErrors,
            dataStale,
            lastFetchAge,
        };
    }
    async shutdown() {
        this.logger.info("QuoteManager: Shutting down...");
        this.stopPolling();
        this.subscribers.clear();
    }
}
exports.QuoteManager = QuoteManager;
//# sourceMappingURL=QuoteManager.js.map