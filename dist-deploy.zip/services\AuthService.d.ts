import { Logger } from '../utils/Logger';
export interface SessionData {
    user_type: string;
    email: string;
    user_name: string;
    user_shortname: string;
    broker: string;
    exchanges: string[];
    products: string[];
    order_types: string[];
    avatar_url: string;
    user_id: string;
    api_key: string;
    access_token: string;
    public_token: string;
    refresh_token: string;
    login_time: string;
}
export declare class AuthService {
    private kiteConnect;
    private logger;
    private accessToken?;
    private sessionData?;
    private sessionPersistence;
    private initializationPromise;
    private lastValidationTime;
    private lastValidationResult;
    private readonly VALIDATION_CACHE_TTL;
    constructor(kiteConnect: any, logger: Logger);
    waitForInitialization(): Promise<void>;
    private initializeSession;
    private isTransientError;
    private validateToken;
    getLoginUrl(): string;
    generateSession(requestToken: string): Promise<SessionData>;
    isAuthenticated(): boolean;
    isAuthenticatedAndValid(): Promise<boolean>;
    getAccessToken(): string | undefined;
    getSessionData(): SessionData | undefined;
    getProfile(): Promise<any>;
    invalidateSession(): Promise<void>;
    clearSessionOnExpiry(): Promise<void>;
    getSessionInfo(): Promise<{
        authenticated: boolean;
        userName?: string;
        persistedSession: {
            exists: boolean;
            expiresAt?: Date;
            createdAt?: Date;
        };
    }>;
}
//# sourceMappingURL=AuthService.d.ts.map