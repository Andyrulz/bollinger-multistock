"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BreakoutPullbackStrategy = exports.TradeState = void 0;
const Logger_1 = require("../../utils/Logger");
const BreakoutPullbackExecutor_1 = require("./BreakoutPullbackExecutor");
const StateLock_1 = require("../../utils/StateLock");
const StrategyStatePersistence_1 = require("../../services/StrategyStatePersistence");
const kiteconnect_1 = require("kiteconnect");
var TradeState;
(function (TradeState) {
    TradeState["WAITING_FOR_BREAKOUT"] = "waiting_for_breakout";
    TradeState["WAITING_FOR_ENTRY"] = "waiting_for_entry";
    TradeState["IN_TRADE"] = "in_trade";
})(TradeState || (exports.TradeState = TradeState = {}));
class BreakoutPullbackStrategy {
    getStateLockStatus() {
        const activeLocks = StateLock_1.globalStateLock.getActiveLocks();
        const queueStatus = StateLock_1.globalStateLock.getQueueStatus();
        return {
            activeLocks,
            isTradeEntryLocked: StateLock_1.globalStateLock.isLocked('trade-entry'),
            isTradeExitLocked: StateLock_1.globalStateLock.isLocked('trade-exit'),
            queueStatus
        };
    }
    constructor(kiteConnect, logger) {
        this.kiteTicker = null;
        this.isWebSocketActive = false;
        this.webSocketReconnectAttempts = 0;
        this.maxWebSocketReconnectAttempts = 10;
        this.webSocketFailureCount = 0;
        this.lastWebSocketFailureTime = null;
        this.webSocketSuccessCount = 0;
        this.totalWebSocketAttempts = 0;
        this.isWebSocketCircuitBreakerOpen = false;
        this.nextWebSocketRetryTime = null;
        this.isShuttingDown = false;
        this.websocketConnectHandler = null;
        this.websocketDisconnectHandler = null;
        this.websocketErrorHandler = null;
        this.websocketReconnectHandler = null;
        this.websocketNoreconnectHandler = null;
        this.websocketTicksHandler = null;
        this.pricePollingInterval = null;
        this.isManualStreamingActive = false;
        this.pollingFailureCount = 0;
        this.lastPollingFailureTime = null;
        this.pollingSuccessCount = 0;
        this.totalPollingAttempts = 0;
        this.isCircuitBreakerOpen = false;
        this.nextRetryTime = null;
        this.lastApiCallTime = null;
        this.minTimeBetweenCalls = 300;
        this.dailyPivots = null;
        this.activeApiCallsCount = 0;
        this.maxConcurrentCalls = 1;
        this.healthMonitoringInterval = null;
        this.errorCounts = new Map();
        this.lastErrorTime = new Map();
        this.healthStatus = {
            dataStreamHealthy: true,
            executionHealthy: true,
            lastHeartbeat: new Date(),
            consecutiveErrors: 0,
            criticalErrorsToday: 0
        };
        this.breakoutDetectionInterval = null;
        this.persistenceTimer = null;
        this.isDirty = false;
        this.PERSISTENCE_INTERVAL = 5000;
        this.currentOneMinuteCandle = null;
        this.lastProcessedFiveMinuteTime = 0;
        this.isProcessingFiveMinute = false;
        this.isExecutingEntry = false;
        this.isExecutingExit = false;
        this.LOOKBACK_PERIOD = 15;
        this.INITIAL_SEARCH_BARS = 4;
        this.TIME_LIMIT_MINUTES = 40;
        this.SL_CAP_RATIO = 0.4;
        this.kiteConnect = kiteConnect;
        this.logger = logger || new Logger_1.Logger();
        this.tradeExecutionService = new BreakoutPullbackExecutor_1.TradeExecutionService(kiteConnect, this.logger);
        this.strategyPersistence = new StrategyStatePersistence_1.StrategyStatePersistence(this.logger);
        this.strategyState = {
            isActive: false,
            priceStreamingActive: false,
            breakoutDetectionActive: false,
            tradeState: TradeState.WAITING_FOR_BREAKOUT,
            candles: [],
            currentVolumeSMA50: 0,
            lastCumulativeVolume: 0,
            markingCandleState: {
                isActive: false,
                breakoutReference: null,
                startTime: null,
                currentMarkingCandle: null,
                searchPhase: 'initial',
                barsProcessedSinceBreakout: 0,
                maxUpdatesReached: false,
                timeExpired: false,
                tradeSkipped: false
            }
        };
    }
    async startStrategy() {
        try {
            this.logger.info('Starting Nifty Breakout Retracement Strategy...');
            const restoredState = await this.strategyPersistence.loadStrategyState();
            let needsFreshInit = false;
            if (restoredState) {
                const isNewDay = this.isNewTradingDay(restoredState);
                if (isNewDay) {
                    this.logger.info('📅 NEW TRADING DAY DETECTED - Performing daily cleanup');
                    await this.dailyCleanup();
                    needsFreshInit = true;
                }
                else {
                    if (await this.validateAndRestoreState(restoredState)) {
                        this.logger.info('🔄 Strategy state restored successfully (same trading day)');
                        await this.initializeDailyPivots();
                    }
                    else {
                        needsFreshInit = true;
                    }
                }
            }
            else {
                needsFreshInit = true;
            }
            if (needsFreshInit) {
                this.logger.info('📝 Starting fresh strategy initialization...');
                await this.initializeNiftyFuturesContract();
                if (!this.strategyState.currentContract) {
                    throw new Error('Failed to initialize futures contract');
                }
                await this.loadHistoricalCandles();
                if (this.strategyState.candles.length > 0) {
                    const lastHistoricalCandle = this.strategyState.candles[this.strategyState.candles.length - 1];
                    this.lastProcessedFiveMinuteTime = lastHistoricalCandle.timestamp.getTime();
                    this.logger.info(`✅ Initialized 5-minute boundary tracking from last historical candle: ${lastHistoricalCandle.timestamp.toLocaleString()}`);
                    this.logger.info(`📊 Will only process NEW 5-minute candles after this timestamp`);
                }
                else {
                    const now = new Date();
                    const currentMinute = now.getMinutes();
                    const currentFiveMinBoundary = Math.floor(currentMinute / 5) * 5;
                    this.lastProcessedFiveMinuteTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours(), currentFiveMinBoundary, 0, 0).getTime();
                    this.logger.warn(`⚠️ No historical candles found - initialized to current boundary: ${new Date(this.lastProcessedFiveMinuteTime).toLocaleTimeString()}`);
                }
                if (this.strategyState.candles.length > 0) {
                    const lastHistoricalCandle = this.strategyState.candles[this.strategyState.candles.length - 1];
                    this.strategyState.lastProcessedCandleForBreakout = lastHistoricalCandle.timestamp;
                    this.logger.info(`✅ lastProcessedCandleForBreakout initialized to: ${lastHistoricalCandle.timestamp.toLocaleString()}`);
                }
                await this.initializeDailyPivots();
            }
            await this.validateTradeStateSync();
            await this.startManualPriceStreaming();
            await this.startBreakoutDetection();
            this.startPersistenceTimer();
            this.startHealthMonitoring();
            this.strategyState.isActive = true;
            this.markStateAsDirty();
            this.logger.info('Nifty Breakout Retracement Strategy started successfully with health monitoring');
        }
        catch (error) {
            this.trackError('strategy_start', error, true);
            throw error;
        }
    }
    async initializeNiftyFuturesContract() {
        try {
            const instruments = await this.kiteConnect.getInstruments(['NFO']);
            const niftyFutures = instruments.filter((inst) => inst.name === 'NIFTY' &&
                inst.instrument_type === 'FUT');
            if (niftyFutures.length === 0) {
                throw new Error('No NIFTY futures found');
            }
            niftyFutures.sort((a, b) => new Date(a.expiry).getTime() - new Date(b.expiry).getTime());
            const currentContract = niftyFutures[0];
            const mappedContract = {
                instrument_token: currentContract.instrument_token,
                tradingsymbol: currentContract.tradingsymbol,
                name: currentContract.name,
                expiry: new Date(currentContract.expiry),
                strike: currentContract.strike,
                tick_size: currentContract.tick_size,
                lot_size: currentContract.lot_size,
                instrument_type: currentContract.instrument_type,
                segment: currentContract.segment,
                exchange: currentContract.exchange
            };
            this.strategyState.currentContract = mappedContract;
            this.logger.info(`Found current month Nifty futures: ${mappedContract.tradingsymbol} (Token: ${mappedContract.instrument_token}, Expiry: ${mappedContract.expiry})`);
        }
        catch (error) {
            this.logger.error('Error initializing Nifty futures contract:', error);
            throw error;
        }
    }
    async loadHistoricalCandles() {
        try {
            const contract = this.strategyState.currentContract;
            if (!contract) {
                throw new Error('No contract available');
            }
            this.logger.info(`Using contract: ${contract.tradingsymbol} (Token: ${contract.instrument_token})`);
            const toDate = new Date();
            const fromDate = new Date();
            fromDate.setDate(fromDate.getDate() - 7);
            const fromDateStr = fromDate.toISOString().split('T')[0];
            const toDateStr = toDate.toISOString().split('T')[0];
            this.logger.info(`Fetching historical candles from ${fromDateStr} to ${toDateStr}...`);
            const candles = await this.kiteConnect.getHistoricalData(contract.instrument_token, '5minute', fromDateStr, toDateStr);
            this.strategyState.candles = candles.map((candle) => ({
                timestamp: new Date(candle.date),
                open: candle.open,
                high: candle.high,
                low: candle.low,
                close: candle.close,
                volume: candle.volume
            }));
            if (this.strategyState.candles.length > 0) {
                const recentVolumes = this.strategyState.candles.slice(-5).map(c => c.volume);
                const avgVolume = recentVolumes.reduce((sum, v) => sum + v, 0) / recentVolumes.length;
                this.logger.debug(`📊 5m candle volumes (last 5): ${recentVolumes.join(', ')}, Avg: ${avgVolume.toFixed(0)}`);
            }
            this.logger.info(`Loaded ${this.strategyState.candles.length} historical 5-minute candles`);
        }
        catch (error) {
            this.trackError('historical_candles_load', error, true);
            throw error;
        }
    }
    calculateDailyPivots(previousDayOHLC) {
        const { high, low, close } = previousDayOHLC;
        const pp = (high + low + close) / 3;
        return {
            pp,
            r1: (2 * pp) - low,
            s1: (2 * pp) - high,
            r2: pp + (high - low),
            s2: pp - (high - low),
            r3: high + 2 * (pp - low),
            s3: low - 2 * (high - pp)
        };
    }
    async calculateDailyPivotsFromMarketData() {
        this.logger.info('📊 Calculating daily pivot levels from NIFTY futures...');
        try {
            if (!this.strategyState.currentContract) {
                throw new Error('Futures contract not initialized - cannot calculate pivots');
            }
            const futuresToken = this.strategyState.currentContract.instrument_token;
            const toDate = new Date();
            toDate.setDate(toDate.getDate() - 1);
            const fromDate = new Date(toDate);
            fromDate.setDate(fromDate.getDate() - 10);
            this.logger.info('📅 Fetching daily pivot data', {
                contract: this.strategyState.currentContract.tradingsymbol,
                token: futuresToken,
                fromDate: fromDate.toISOString().split('T')[0],
                toDate: toDate.toISOString().split('T')[0]
            });
            const dailyData = await this.kiteConnect.getHistoricalData(futuresToken, 'day', fromDate, toDate);
            if (!dailyData || dailyData.length < 1) {
                throw new Error('No daily data available for pivot calculation');
            }
            const previousDay = dailyData[dailyData.length - 1];
            this.dailyPivots = this.calculateDailyPivots({
                high: previousDay.high,
                low: previousDay.low,
                close: previousDay.close
            });
            this.logger.info('✅ Daily pivots calculated successfully', {
                date: previousDay.date,
                contract: this.strategyState.currentContract.tradingsymbol,
                pivots: {
                    pp: this.dailyPivots.pp.toFixed(2),
                    r1: this.dailyPivots.r1.toFixed(2),
                    r2: this.dailyPivots.r2.toFixed(2),
                    s1: this.dailyPivots.s1.toFixed(2)
                }
            });
            this.markStateAsDirty();
        }
        catch (error) {
            this.logger.error('❌ Failed to calculate daily pivots:', error);
            throw error;
        }
    }
    async initializeDailyPivots() {
        try {
            await this.calculateDailyPivotsFromMarketData();
            this.logger.info('✅ Daily pivot filter enabled');
        }
        catch (error) {
            this.logger.warn('⚠️ Daily pivot calculation failed - continuing WITHOUT pivot filter', error);
            this.logger.warn('   Strategy will trade both directions without daily bias filtering');
            this.dailyPivots = null;
        }
    }
    async refreshRecentCandles() {
        try {
            const contract = this.strategyState.currentContract;
            if (!contract) {
                this.logger.warn('No contract available for candle refresh');
                return;
            }
            const existingCandles = this.strategyState.candles;
            if (existingCandles.length === 0) {
                this.logger.warn('No existing candles found - need to load historical data first');
                return;
            }
            const lastCandle = existingCandles[existingCandles.length - 1];
            if (!lastCandle) {
                this.logger.warn('Cannot determine last candle timestamp');
                return;
            }
            const fromDate = new Date(lastCandle.timestamp);
            fromDate.setHours(0, 0, 0, 0);
            const toDate = new Date();
            const fromDateStr = fromDate.toISOString().split('T')[0];
            const toDateStr = toDate.toISOString().split('T')[0];
            this.logger.debug(`🔄 Refreshing 5m candles from ${fromDateStr} (last candle day) to ${toDateStr}...`);
            const recentCandles = await this.kiteConnect.getHistoricalData(contract.instrument_token, '5minute', fromDateStr, toDateStr);
            if (!recentCandles || recentCandles.length === 0) {
                this.logger.debug('No new candles found in refresh period');
                return;
            }
            const newCandles = recentCandles.map((candle) => ({
                timestamp: new Date(candle.date),
                open: candle.open,
                high: candle.high,
                low: candle.low,
                close: candle.close,
                volume: candle.volume
            }));
            const currentCandles = this.strategyState.candles;
            let lastExistingTime = 0;
            if (currentCandles.length > 0) {
                const lastExistingCandle = currentCandles[currentCandles.length - 1];
                if (lastExistingCandle) {
                    lastExistingTime = lastExistingCandle.timestamp.getTime();
                }
            }
            const candlesToAdd = newCandles.filter((candle) => candle.timestamp.getTime() > lastExistingTime);
            if (candlesToAdd.length > 0) {
                this.strategyState.candles.push(...candlesToAdd);
                const maxCandles = 1000;
                if (this.strategyState.candles.length > maxCandles) {
                    this.strategyState.candles = this.strategyState.candles.slice(-maxCandles);
                    this.logger.debug(`🗑️ Trimmed 5m candles to latest ${maxCandles} for memory optimization`);
                }
                this.logger.info(`✅ Added ${candlesToAdd.length} new 5m candles (from ${fromDateStr}). Total: ${this.strategyState.candles.length}`);
                const latestCandle = this.strategyState.candles[this.strategyState.candles.length - 1];
                if (latestCandle) {
                    this.logger.info(`📊 Latest 5m candle: ${latestCandle.timestamp.toLocaleString()} OHLCV: ${latestCandle.open}/${latestCandle.high}/${latestCandle.low}/${latestCandle.close}/${latestCandle.volume}`);
                }
                this.isDirty = true;
            }
            else {
                this.logger.debug('📊 No new 5m candles to add (all candles up to date)');
            }
        }
        catch (error) {
            this.logger.error('❌ Error refreshing recent candles:', error);
        }
    }
    async stopStrategy() {
        try {
            this.strategyState.isActive = false;
            this.stopPersistenceTimer();
            try {
                await this.saveStateImmediate();
                this.logger.info('💾 Final strategy state saved before shutdown');
            }
            catch (error) {
                this.logger.error('❌ Failed to save final state:', error);
            }
            this.stopBreakoutDetection();
            await this.stopManualPriceStreaming();
            this.stopHealthMonitoring();
            if (this.updateTimer) {
                clearTimeout(this.updateTimer);
                this.updateTimer = undefined;
            }
            this.logger.info('Nifty Breakout Retracement Strategy stopped with health monitoring cleanup');
        }
        catch (error) {
            this.trackError('strategy_stop', error, false);
        }
    }
    async dailyCleanup() {
        this.logger.info('🧹 Starting daily cleanup for new trading day...');
        try {
            this.strategyState.candles = [];
            delete this.strategyState.lastProcessedCandleForBreakout;
            delete this.strategyState.latestPivotHigh;
            delete this.strategyState.latestPivotLow;
            delete this.strategyState.latestBreakoutSignal;
            delete this.strategyState.livePrice;
            delete this.strategyState.lastUpdateTime;
            this.strategyState.currentVolumeSMA50 = 0;
            this.strategyState.lastCumulativeVolume = 0;
            this.strategyState.tradeState = TradeState.WAITING_FOR_BREAKOUT;
            delete this.strategyState.currentTradeId;
            delete this.strategyState.tradeSetupRequest;
            this.strategyState.markingCandleState = {
                isActive: false,
                breakoutReference: null,
                startTime: null,
                currentMarkingCandle: null,
                searchPhase: 'initial',
                barsProcessedSinceBreakout: 0,
                maxUpdatesReached: false,
                timeExpired: false,
                tradeSkipped: false
            };
            this.healthStatus = {
                dataStreamHealthy: true,
                executionHealthy: true,
                lastHeartbeat: new Date(),
                consecutiveErrors: 0,
                criticalErrorsToday: 0
            };
            this.errorCounts.clear();
            this.lastErrorTime.clear();
            await this.saveStateImmediate();
            this.logger.info('✅ Daily cleanup completed - ready for new trading day');
        }
        catch (error) {
            this.logger.error('❌ Error during daily cleanup:', error);
            throw error;
        }
    }
    isNewTradingDay(restoredState) {
        if (!restoredState.lastProcessedCandleForBreakout) {
            return true;
        }
        const lastStateDate = new Date(restoredState.lastProcessedCandleForBreakout);
        const today = new Date();
        return lastStateDate.toDateString() !== today.toDateString();
    }
    async startManualPriceStreaming() {
        try {
            this.isShuttingDown = false;
            if (!this.strategyState.currentContract) {
                throw new Error('No current contract available for price streaming');
            }
            this.logger.info(`🚀 Starting WEBSOCKET price streaming for ${this.strategyState.currentContract.tradingsymbol}`);
            await this.initializeWebSocket();
            this.isWebSocketActive = true;
            this.strategyState.priceStreamingActive = true;
            this.healthMonitoringInterval = setInterval(() => {
                this.logWebSocketHealthStatus();
            }, 30000);
            this.logger.info('✅ WEBSOCKET price streaming started successfully - real-time tick data with health monitoring');
        }
        catch (error) {
            this.logger.error('❌ Failed to start WEBSOCKET price streaming:', error);
            this.strategyState.priceStreamingActive = false;
            this.isWebSocketActive = false;
            this.logger.warn('🔄 Falling back to REST API polling as backup...');
            await this.startRestApiFallback();
        }
    }
    shouldCircuitBreakerBlock() {
        if (!this.isCircuitBreakerOpen) {
            return false;
        }
        if (this.nextRetryTime && new Date() >= this.nextRetryTime) {
            this.logger.info('🔄 Circuit breaker attempting recovery - testing API availability');
            return false;
        }
        return true;
    }
    recordPollingSuccess() {
        this.pollingSuccessCount++;
        this.totalPollingAttempts++;
        if (this.pollingFailureCount > 0) {
            this.logger.info(`✅ API recovered - resetting failure count (was ${this.pollingFailureCount})`);
            this.pollingFailureCount = 0;
            this.lastPollingFailureTime = null;
        }
        if (this.isCircuitBreakerOpen) {
            this.isCircuitBreakerOpen = false;
            this.nextRetryTime = null;
            this.logger.info('🔓 Circuit breaker CLOSED - API is healthy');
        }
    }
    recordPollingFailure(error) {
        this.pollingFailureCount++;
        this.totalPollingAttempts++;
        this.lastPollingFailureTime = new Date();
        const failureThreshold = 5;
        const successRate = this.totalPollingAttempts > 0 ? (this.pollingSuccessCount / this.totalPollingAttempts) * 100 : 0;
        this.logger.warn(`⚠️ Polling failure #${this.pollingFailureCount} | Success rate: ${successRate.toFixed(1)}% | Error: ${error.message || error}`);
        if (this.pollingFailureCount >= failureThreshold && !this.isCircuitBreakerOpen) {
            this.isCircuitBreakerOpen = true;
            const backoffSeconds = Math.min(30 * Math.pow(2, Math.floor(this.pollingFailureCount / 5)), 240);
            this.nextRetryTime = new Date(Date.now() + backoffSeconds * 1000);
            this.logger.error(`🔒 CIRCUIT BREAKER OPEN - Too many failures (${this.pollingFailureCount}). Next retry at ${this.nextRetryTime.toLocaleTimeString()}`);
        }
    }
    shouldThrottleApiCall() {
        const now = new Date();
        if (this.activeApiCallsCount >= this.maxConcurrentCalls) {
            return true;
        }
        if (this.lastApiCallTime) {
            const timeSinceLastCall = now.getTime() - this.lastApiCallTime.getTime();
            if (timeSinceLastCall < this.minTimeBetweenCalls) {
                return true;
            }
        }
        return false;
    }
    async fetchAndProcessLivePrice() {
        try {
            if (!this.strategyState.currentContract || !this.isManualStreamingActive) {
                return;
            }
            if (this.shouldCircuitBreakerBlock()) {
                return;
            }
            if (this.shouldThrottleApiCall()) {
                return;
            }
            this.lastApiCallTime = new Date();
            this.activeApiCallsCount++;
            const symbol = `NFO:${this.strategyState.currentContract.tradingsymbol}`;
            const quotes = await this.kiteConnect.getQuote([symbol]);
            const quote = quotes[symbol];
            if (!quote) {
                this.logger.warn(`⚠️ No quote data received for ${symbol}`);
                return;
            }
            const rawVolume = quote.volume || 0;
            const validatedVolume = Math.max(0, rawVolume);
            const tickData = {
                instrument_token: quote.instrument_token,
                last_price: quote.last_price || 0,
                volume: validatedVolume,
                buy_quantity: quote.buy_quantity || 0,
                sell_quantity: quote.sell_quantity || 0,
                ohlc: {
                    open: quote.ohlc?.open || 0,
                    high: quote.ohlc?.high || 0,
                    low: quote.ohlc?.low || 0,
                    close: quote.ohlc?.close || 0
                },
                change: quote.net_change || 0,
                last_trade_time: new Date(quote.last_trade_time) || new Date(),
                exchange_timestamp: new Date(quote.timestamp) || new Date(),
                timestamp: new Date()
            };
            this.strategyState.livePrice = tickData;
            this.strategyState.lastUpdateTime = new Date();
            this.logger.info(`💹 MANUAL POLL: ${this.strategyState.currentContract.tradingsymbol} | LTP: ₹${tickData.last_price.toFixed(2)} | Vol: ${tickData.volume.toLocaleString()} | Change: ₹${tickData.change.toFixed(2)} | Source=REST_API`);
            this.monitorTradeLevels(tickData.last_price);
            this.processTick(tickData);
            this.updateOptionPriceCache().catch(err => this.logger.debug('Option price cache update skipped:', err));
            this.recordPollingSuccess();
        }
        catch (error) {
            this.logger.error('❌ Error in fetchAndProcessLivePrice:', error);
            this.recordPollingFailure(error);
        }
        finally {
            this.activeApiCallsCount = Math.max(0, this.activeApiCallsCount - 1);
        }
    }
    async initializeWebSocket() {
        return new Promise((resolve, reject) => {
            try {
                this.logger.info('🔌 Initializing WebSocket connection...');
                const accessToken = this.kiteConnect.access_token;
                const apiKey = process.env.ZERODHA_API_KEY;
                if (!accessToken || !apiKey) {
                    throw new Error('Missing access token or API key for WebSocket initialization');
                }
                this.kiteTicker = new kiteconnect_1.KiteTicker({
                    api_key: apiKey,
                    access_token: accessToken
                });
                this.websocketConnectHandler = () => {
                    if (!this.kiteTicker)
                        return;
                    this.logger.info('✅ WebSocket connected successfully');
                    this.isWebSocketActive = true;
                    this.webSocketReconnectAttempts = 0;
                    this.recordWebSocketSuccess();
                    this.stopRestApiFallback();
                    try {
                        this.subscribeToInstrument();
                    }
                    catch (error) {
                        this.logger.error('❌ Failed to subscribe after WebSocket connection:', error);
                        reject(error);
                        return;
                    }
                    resolve();
                };
                this.kiteTicker.on('connect', this.websocketConnectHandler);
                this.websocketDisconnectHandler = (error) => {
                    try {
                        if (!this.kiteTicker)
                            return;
                        this.logger.warn('🔌 WebSocket disconnected');
                        this.isWebSocketActive = false;
                        if (this.isShuttingDown) {
                            this.logger.info('🛑 WebSocket disconnected during shutdown - skipping fallback');
                            return;
                        }
                        this.logger.warn('🔄 WebSocket disconnected, starting REST API fallback...');
                        this.startRestApiFallback().catch(err => {
                            this.logger.error('❌ Failed to start REST API fallback after WebSocket disconnect:', err);
                        });
                    }
                    catch (handlerError) {
                        this.logger.error('❌ Error in disconnect handler:', handlerError);
                    }
                };
                this.kiteTicker.on('disconnect', this.websocketDisconnectHandler);
                this.websocketErrorHandler = (error) => {
                    try {
                        if (!this.kiteTicker)
                            return;
                        this.logger.error('❌ WebSocket error:', error);
                        this.isWebSocketActive = false;
                        if (this.isShuttingDown) {
                            this.logger.info('🛑 WebSocket error during shutdown - ignoring');
                            return;
                        }
                        this.recordWebSocketFailure(error);
                        this.logger.warn('🔄 WebSocket error, starting REST API fallback...');
                        this.startRestApiFallback().catch(err => {
                            this.logger.error('❌ Failed to start REST API fallback after WebSocket error:', err);
                        });
                        reject(error);
                    }
                    catch (handlerError) {
                        this.logger.error('❌ Error in error handler:', handlerError);
                        reject(handlerError);
                    }
                };
                this.kiteTicker.on('error', this.websocketErrorHandler);
                this.websocketReconnectHandler = (reconnect_count, reconnect_interval) => {
                    try {
                        if (!this.kiteTicker)
                            return;
                        if (this.isShuttingDown) {
                            this.logger.info('🛑 WebSocket reconnect attempt during shutdown - ignoring');
                            return;
                        }
                        this.webSocketReconnectAttempts = reconnect_count;
                        this.logger.info(`🔄 WebSocket reconnecting... Attempt: ${reconnect_count}/${this.maxWebSocketReconnectAttempts}, Interval: ${reconnect_interval}ms`);
                        if (reconnect_count >= this.maxWebSocketReconnectAttempts) {
                            this.logger.error('❌ WebSocket max reconnection attempts reached, falling back to REST API');
                            this.startRestApiFallback().catch(err => {
                                this.logger.error('❌ Failed to start REST API fallback after max reconnection attempts:', err);
                            });
                        }
                    }
                    catch (handlerError) {
                        this.logger.error('❌ Error in reconnect handler:', handlerError);
                    }
                };
                this.kiteTicker.on('reconnect', this.websocketReconnectHandler);
                this.websocketNoreconnectHandler = () => {
                    try {
                        if (!this.kiteTicker)
                            return;
                        this.isWebSocketActive = false;
                        if (this.isShuttingDown) {
                            this.logger.info('🛑 WebSocket no reconnect during shutdown - skipping fallback');
                            return;
                        }
                        this.logger.error('❌ WebSocket unable to reconnect after maximum attempts');
                        this.startRestApiFallback().catch(err => {
                            this.logger.error('Failed to start REST API fallback:', err);
                        });
                    }
                    catch (handlerError) {
                        this.logger.error('❌ Error in noreconnect handler:', handlerError);
                    }
                };
                this.kiteTicker.on('noreconnect', this.websocketNoreconnectHandler);
                this.websocketTicksHandler = (ticks) => {
                    if (!this.kiteTicker)
                        return;
                    this.processWebSocketTicks(ticks);
                };
                this.kiteTicker.on('ticks', this.websocketTicksHandler);
                this.kiteTicker.connect();
            }
            catch (error) {
                this.logger.error('❌ Failed to initialize WebSocket:', error);
                reject(error);
            }
        });
    }
    subscribeToInstrument() {
        if (!this.kiteTicker || !this.strategyState.currentContract) {
            throw new Error('WebSocket not initialized or no current contract available');
        }
        const instrumentToken = parseInt(this.strategyState.currentContract.instrument_token.toString());
        this.logger.info(`📡 Subscribing to NIFTY futures (Token: ${instrumentToken})...`);
        try {
            this.kiteTicker.subscribe([instrumentToken]);
            this.kiteTicker.setMode(this.kiteTicker.modeFull, [instrumentToken]);
            this.logger.info('✅ WebSocket subscription completed successfully');
        }
        catch (error) {
            this.logger.error('❌ WebSocket subscription failed:', error);
            throw error;
        }
    }
    processWebSocketTicks(ticks) {
        if (!this.strategyState.currentContract) {
            this.logger.warn('⚠️ Received WebSocket ticks but no current contract available');
            return;
        }
        const instrumentToken = parseInt(this.strategyState.currentContract.instrument_token.toString());
        this.logger.debug(`📡 Received ${ticks.length} WebSocket tick(s) for token ${instrumentToken}`);
        ticks.forEach((tick) => {
            if (tick.instrument_token === instrumentToken) {
                this.logger.debug(`💹 Processing tick for ${this.strategyState.currentContract?.tradingsymbol}: LTP ₹${tick.last_price}`);
                try {
                    const rawVolume = tick.volume_traded || tick.volume || tick.total_volume || tick.day_volume || tick.cumulative_volume || 0;
                    const validatedVolume = Math.max(0, rawVolume);
                    if (validatedVolume > 0 && Math.random() < 0.005) {
                        this.logger.info(`✅ WebSocket volume extracted: ${validatedVolume} from volume_traded field`);
                    }
                    else if (validatedVolume === 0) {
                        this.logger.error(`� CRITICAL: All WebSocket volume fields are ZERO! volume_traded=${tick.volume_traded}, volume=${tick.volume}`);
                    }
                    const tickData = {
                        instrument_token: tick.instrument_token,
                        last_price: tick.last_price || 0,
                        volume: validatedVolume,
                        buy_quantity: tick.buy_quantity || 0,
                        sell_quantity: tick.sell_quantity || 0,
                        ohlc: {
                            open: tick.ohlc?.open || 0,
                            high: tick.ohlc?.high || 0,
                            low: tick.ohlc?.low || 0,
                            close: tick.ohlc?.close || 0
                        },
                        change: tick.change || 0,
                        last_trade_time: new Date(tick.last_trade_time) || new Date(),
                        exchange_timestamp: new Date(tick.exchange_timestamp) || new Date(),
                        timestamp: new Date()
                    };
                    this.logger.debug(`📡 WebSocket tick: Price=₹${tickData.last_price}, Volume=${tickData.volume}, Source=WebSocket`);
                    this.strategyState.livePrice = tickData;
                    this.strategyState.lastUpdateTime = new Date();
                    this.monitorTradeLevels(tickData.last_price);
                    this.processTick(tickData);
                    this.updateOptionPriceCache().catch(err => this.logger.debug('Option price cache update skipped:', err));
                    this.recordWebSocketSuccess();
                }
                catch (error) {
                    this.logger.error('❌ Error processing WebSocket tick:', error);
                    this.recordWebSocketFailure(error);
                }
            }
        });
    }
    async updateOptionPriceCache() {
        try {
            const activePosition = this.tradeExecutionService.getActivePosition();
            if (!activePosition)
                return;
            const symbol = `NFO:${activePosition.instrument.tradingsymbol}`;
            const quotes = await this.kiteConnect.getQuote([symbol]);
            const quote = quotes[symbol];
            if (quote && quote.last_price) {
                this.tradeExecutionService.updateOptionPrice(quote.last_price);
            }
        }
        catch (error) {
            this.logger.debug('Failed to update option price cache:', error);
        }
    }
    logWebSocketHealthStatus() {
        const now = new Date();
        const lastUpdate = this.strategyState.lastUpdateTime;
        const timeSinceLastUpdate = lastUpdate ? now.getTime() - lastUpdate.getTime() : 0;
        const healthStatus = {
            websocketActive: this.isWebSocketActive,
            connected: this.kiteTicker?.connected || false,
            reconnectAttempts: this.webSocketReconnectAttempts,
            lastDataReceived: lastUpdate?.toLocaleTimeString() || 'Never',
            timeSinceLastData: `${Math.floor(timeSinceLastUpdate / 1000)}s`,
            successRate: this.totalWebSocketAttempts > 0 ?
                ((this.webSocketSuccessCount / this.totalWebSocketAttempts) * 100).toFixed(1) + '%' : 'N/A',
            circuitBreakerOpen: this.isWebSocketCircuitBreakerOpen
        };
        this.logger.info('📊 WebSocket Health Status:', healthStatus);
        if (timeSinceLastUpdate > 60000 && this.isWebSocketActive && this.isMarketHours()) {
            this.logger.warn('⚠️ No WebSocket data received for over 60 seconds during market hours');
        }
    }
    recordWebSocketSuccess() {
        this.webSocketSuccessCount++;
        this.totalWebSocketAttempts++;
        if (this.webSocketFailureCount > 0) {
            this.logger.debug(`✅ WebSocket recovered - resetting failure count (was ${this.webSocketFailureCount})`);
            this.webSocketFailureCount = 0;
            this.lastWebSocketFailureTime = null;
        }
        if (this.isWebSocketCircuitBreakerOpen) {
            this.isWebSocketCircuitBreakerOpen = false;
            this.nextWebSocketRetryTime = null;
            this.logger.info('🔓 WebSocket circuit breaker CLOSED - connection is healthy');
        }
    }
    recordWebSocketFailure(error) {
        this.webSocketFailureCount++;
        this.totalWebSocketAttempts++;
        this.lastWebSocketFailureTime = new Date();
        const failureThreshold = 5;
        const successRate = this.totalWebSocketAttempts > 0 ?
            (this.webSocketSuccessCount / this.totalWebSocketAttempts) * 100 : 0;
        this.logger.warn(`⚠️ WebSocket failure #${this.webSocketFailureCount} | Success rate: ${successRate.toFixed(1)}% | Error: ${error.message || error}`);
        if (this.webSocketFailureCount >= failureThreshold && !this.isWebSocketCircuitBreakerOpen) {
            this.isWebSocketCircuitBreakerOpen = true;
            const backoffSeconds = Math.min(30 * Math.pow(2, Math.floor(this.webSocketFailureCount / 5)), 240);
            this.nextWebSocketRetryTime = new Date(Date.now() + backoffSeconds * 1000);
            this.logger.error(`🔒 WEBSOCKET CIRCUIT BREAKER OPEN - Too many failures (${this.webSocketFailureCount}). Falling back to REST API`);
            this.startRestApiFallback();
        }
    }
    async startRestApiFallback() {
        try {
            if (this.pricePollingInterval && this.isManualStreamingActive) {
                this.logger.info('⏭️ REST API fallback already running, skipping duplicate start');
                return;
            }
            this.logger.warn('🔄 Starting REST API fallback due to WebSocket issues...');
            if (this.pricePollingInterval) {
                clearInterval(this.pricePollingInterval);
                this.pricePollingInterval = null;
            }
            this.isManualStreamingActive = true;
            this.pricePollingInterval = setInterval(async () => {
                try {
                    if (!this.isWebSocketActive) {
                        await this.fetchAndProcessLivePrice();
                    }
                    else {
                        this.logger.info('✅ WebSocket is back online, stopping REST API fallback');
                        this.stopRestApiFallback();
                    }
                }
                catch (error) {
                    this.logger.error('❌ Error in REST API fallback polling:', error);
                }
            }, 1500);
            if (!this.isWebSocketActive) {
                await this.fetchAndProcessLivePrice();
            }
            this.logger.info('✅ REST API fallback started successfully');
        }
        catch (error) {
            this.logger.error('❌ Failed to start REST API fallback:', error);
            throw error;
        }
    }
    stopRestApiFallback() {
        if (this.pricePollingInterval) {
            clearInterval(this.pricePollingInterval);
            this.pricePollingInterval = null;
            this.logger.info('🛑 REST API fallback polling stopped - WebSocket is active');
        }
        this.isManualStreamingActive = false;
    }
    async stopManualPriceStreaming() {
        try {
            this.logger.info('🛑 Stopping price streaming...');
            this.strategyState.priceStreamingActive = false;
            this.isShuttingDown = true;
            if (this.kiteTicker) {
                try {
                    this.kiteTicker.autoReconnect(false);
                    const ticker = this.kiteTicker;
                    this.kiteTicker = null;
                    ticker.disconnect();
                    this.logger.info('🔌 WebSocket disconnected cleanly');
                }
                catch (error) {
                    this.logger.warn('⚠️ Error disconnecting WebSocket:', error);
                }
            }
            this.isWebSocketActive = false;
            this.isManualStreamingActive = false;
            if (this.pricePollingInterval) {
                clearInterval(this.pricePollingInterval);
                this.pricePollingInterval = null;
                this.logger.info('🛑 REST API fallback polling stopped');
            }
            if (this.healthMonitoringInterval) {
                clearInterval(this.healthMonitoringInterval);
                this.healthMonitoringInterval = null;
            }
            this.activeApiCallsCount = 0;
            this.lastApiCallTime = null;
            this.pollingFailureCount = 0;
            this.lastPollingFailureTime = null;
            this.isCircuitBreakerOpen = false;
            this.nextRetryTime = null;
            this.webSocketFailureCount = 0;
            this.lastWebSocketFailureTime = null;
            this.isWebSocketCircuitBreakerOpen = false;
            this.nextWebSocketRetryTime = null;
            this.webSocketReconnectAttempts = 0;
            this.logger.info('✅ Price streaming stopped - all resources cleaned up (WebSocket + REST API fallback)');
        }
        catch (error) {
            this.logger.error('❌ Error stopping price streaming:', error);
        }
    }
    getPollingHealthMetrics() {
        const successRate = this.totalPollingAttempts > 0 ? (this.pollingSuccessCount / this.totalPollingAttempts) * 100 : 100;
        const isHealthy = successRate >= 80 && this.pollingFailureCount < 3 && !this.isCircuitBreakerOpen;
        const timeSinceLastSuccess = this.lastApiCallTime ? Date.now() - this.lastApiCallTime.getTime() : null;
        return {
            isHealthy,
            successRate: Math.round(successRate * 100) / 100,
            totalAttempts: this.totalPollingAttempts,
            consecutiveFailures: this.pollingFailureCount,
            circuitBreakerOpen: this.isCircuitBreakerOpen,
            activeApiCalls: this.activeApiCallsCount,
            lastFailureTime: this.lastPollingFailureTime,
            nextRetryTime: this.nextRetryTime,
            timeSinceLastSuccess
        };
    }
    logHealthStatus() {
        const health = this.getPollingHealthMetrics();
        const uptime = this.isManualStreamingActive ? 'Active' : 'Inactive';
        if (health.isHealthy) {
            this.logger.info(`💚 POLLING HEALTH: ${uptime} | Success Rate: ${health.successRate}% | Total: ${health.totalAttempts} | Active Calls: ${health.activeApiCalls}`);
        }
        else {
            const issues = [];
            if (health.successRate < 80)
                issues.push(`Low success rate: ${health.successRate}%`);
            if (health.consecutiveFailures >= 3)
                issues.push(`${health.consecutiveFailures} consecutive failures`);
            if (health.circuitBreakerOpen)
                issues.push('Circuit breaker OPEN');
            this.logger.warn(`🔴 POLLING HEALTH ISSUES: ${issues.join(', ')} | Total: ${health.totalAttempts} | Next retry: ${health.nextRetryTime?.toLocaleTimeString() || 'N/A'}`);
        }
    }
    getStrategyState() {
        return { ...this.strategyState };
    }
    getLatestPivots() {
        return {
            pivotHigh: this.strategyState.latestPivotHigh,
            pivotLow: this.strategyState.latestPivotLow
        };
    }
    getDailyPivots() {
        return this.dailyPivots ? { ...this.dailyPivots } : null;
    }
    async triggerManualPivotDetection() {
        this.logger.info('🔄 MANUAL PIVOT DETECTION triggered');
        await this.detectPivotPoints();
    }
    getLivePrice() {
        return this.strategyState.livePrice;
    }
    isPriceStreamingActive() {
        return this.strategyState.priceStreamingActive;
    }
    isStrategyActive() {
        return this.strategyState.isActive;
    }
    getCandleCount() {
        return this.strategyState.candles.length;
    }
    isMarketHours() {
        const now = new Date();
        const hours = now.getHours();
        const minutes = now.getMinutes();
        const currentTime = hours * 60 + minutes;
        const marketStart = 9 * 60 + 15;
        const marketEnd = 15 * 60 + 30;
        return currentTime >= marketStart && currentTime <= marketEnd;
    }
    isBreakoutDetectionActive() {
        return this.strategyState.breakoutDetectionActive;
    }
    getLatestBreakoutSignal() {
        return this.strategyState.latestBreakoutSignal;
    }
    getCurrentVolumeSMA50() {
        return this.strategyState.currentVolumeSMA50;
    }
    getWebSocketHealthStatus() {
        const now = new Date();
        const lastUpdate = this.strategyState.lastUpdateTime;
        const timeSinceLastUpdate = lastUpdate ? now.getTime() - lastUpdate.getTime() : 0;
        return {
            websocketActive: this.isWebSocketActive,
            connected: this.kiteTicker?.connected || false,
            reconnectAttempts: this.webSocketReconnectAttempts,
            lastDataReceived: lastUpdate?.toLocaleTimeString() || 'Never',
            timeSinceLastData: `${Math.floor(timeSinceLastUpdate / 1000)}s`,
            successRate: this.totalWebSocketAttempts > 0 ?
                ((this.webSocketSuccessCount / this.totalWebSocketAttempts) * 100).toFixed(1) + '%' : 'N/A',
            circuitBreakerOpen: this.isWebSocketCircuitBreakerOpen,
            totalAttempts: this.totalWebSocketAttempts,
            successCount: this.webSocketSuccessCount
        };
    }
    getTradeExecutionService() {
        return this.tradeExecutionService;
    }
    async selectATMOption(direction, niftyPrice) {
        return await this.tradeExecutionService.selectATMOption(direction, niftyPrice);
    }
    getSelectedInstrument() {
        return this.tradeExecutionService.getSelectedInstrument();
    }
    async getOptionPriceByToken(instrumentToken) {
        return await this.tradeExecutionService.getOptionPriceByToken(instrumentToken);
    }
    getInstrumentsStatus() {
        return this.tradeExecutionService.getInstrumentsStatus();
    }
    async startBreakoutDetection() {
        this.strategyState.breakoutDetectionActive = true;
        this.logger.info('Breakout detection started');
        await this.detectPivotPoints();
        this.scheduleNext5MinutePivotDetection();
    }
    scheduleNext5MinutePivotDetection() {
        if (!this.strategyState.breakoutDetectionActive) {
            return;
        }
        const now = new Date();
        const currentMinutes = now.getMinutes();
        const currentSeconds = now.getSeconds();
        const currentMs = now.getMilliseconds();
        let nextCandleMinute;
        if ((currentMinutes % 5 === 0 && currentSeconds >= 1) || (currentMinutes % 5 !== 0)) {
            nextCandleMinute = (Math.floor(currentMinutes / 5) + 1) * 5;
        }
        else {
            nextCandleMinute = Math.ceil(currentMinutes / 5) * 5;
        }
        const nextCandleTime = new Date(now);
        if (nextCandleMinute >= 60) {
            nextCandleTime.setHours(nextCandleTime.getHours() + 1);
            nextCandleTime.setMinutes(0);
        }
        else {
            nextCandleTime.setMinutes(nextCandleMinute);
        }
        nextCandleTime.setSeconds(1);
        nextCandleTime.setMilliseconds(0);
        const timeUntilNext = nextCandleTime.getTime() - now.getTime();
        if (timeUntilNext <= 0) {
            this.logger.warn(`⚠️ Timing calculation error - timeUntilNext: ${timeUntilNext}ms. Forcing 5min delay.`);
            const fallbackTime = new Date(now.getTime() + (5 * 60 * 1000));
            this.breakoutDetectionInterval = setTimeout(async () => {
                await this.detectPivotPoints();
                this.scheduleNext5MinutePivotDetection();
            }, 5 * 60 * 1000);
            return;
        }
        this.logger.info(`📅 Next 5m pivot detection scheduled for: ${nextCandleTime.toLocaleTimeString()} (in ${Math.round(timeUntilNext / 1000)}s)`);
        this.breakoutDetectionInterval = setTimeout(async () => {
            await this.detectPivotPoints();
            this.scheduleNext5MinutePivotDetection();
        }, timeUntilNext);
    }
    stopBreakoutDetection() {
        this.strategyState.breakoutDetectionActive = false;
        if (this.breakoutDetectionInterval) {
            clearTimeout(this.breakoutDetectionInterval);
            this.breakoutDetectionInterval = null;
        }
        this.logger.info('Breakout detection stopped');
    }
    async detectPivotPoints() {
        await this.refreshRecentCandles();
        const candles = this.strategyState.candles;
        const requiredCandles = (this.LOOKBACK_PERIOD * 2) + 1;
        this.logger.info(`🔍 PIVOT DETECTION: Checking ${candles.length} candles (need ${requiredCandles})`);
        if (candles.length < requiredCandles) {
            this.logger.warn(`⚠️ Not enough candles for pivot detection (need ${requiredCandles}, have ${candles.length})`);
            return;
        }
        let latestPivotHigh;
        let latestPivotLow;
        let foundPivots = 0;
        for (let i = this.LOOKBACK_PERIOD; i < candles.length - this.LOOKBACK_PERIOD; i++) {
            const currentCandle = candles[i];
            if (!currentCandle)
                continue;
            const isPivotHigh = this.isPivotHigh(i, candles);
            if (isPivotHigh) {
                latestPivotHigh = {
                    price: currentCandle.high,
                    timestamp: currentCandle.timestamp,
                    type: 'high'
                };
                foundPivots++;
            }
            const isPivotLow = this.isPivotLow(i, candles);
            if (isPivotLow) {
                latestPivotLow = {
                    price: currentCandle.low,
                    timestamp: currentCandle.timestamp,
                    type: 'low'
                };
                foundPivots++;
            }
        }
        if (latestPivotHigh) {
            if (!this.strategyState.latestPivotHigh ||
                latestPivotHigh.timestamp > this.strategyState.latestPivotHigh.timestamp ||
                latestPivotHigh.price > this.strategyState.latestPivotHigh.price) {
                this.strategyState.latestPivotHigh = latestPivotHigh;
                this.logger.info(`🔺 NEW PIVOT HIGH (15,15): ₹${latestPivotHigh.price.toFixed(2)} at ${latestPivotHigh.timestamp.toLocaleString()}`);
                this.markStateAsDirty();
            }
        }
        if (latestPivotLow) {
            if (!this.strategyState.latestPivotLow ||
                latestPivotLow.timestamp > this.strategyState.latestPivotLow.timestamp ||
                latestPivotLow.price < this.strategyState.latestPivotLow.price) {
                this.strategyState.latestPivotLow = latestPivotLow;
                this.logger.info(`🔻 NEW PIVOT LOW (15,15): ₹${latestPivotLow.price.toFixed(2)} at ${latestPivotLow.timestamp.toLocaleString()}`);
                this.markStateAsDirty();
            }
        }
        if (foundPivots === 0) {
            this.logger.warn(`⚠️ NO PIVOTS FOUND in ${candles.length} candles using 15,15 lookback. Market might be in strong trend.`);
            const recent = candles.slice(-10);
            this.logger.info(`📊 Recent 10 candles: High range ${Math.min(...recent.map(c => c.high)).toFixed(2)} - ${Math.max(...recent.map(c => c.high)).toFixed(2)}`);
            this.logger.info(`📊 Recent 10 candles: Low range ${Math.min(...recent.map(c => c.low)).toFixed(2)} - ${Math.max(...recent.map(c => c.low)).toFixed(2)}`);
        }
        else {
            this.logger.info(`✅ Pivot analysis complete (15,15) - found ${foundPivots} pivot(s)`);
            this.logCurrentPivots();
        }
    }
    isPivotHigh(index, candles) {
        const currentCandle = candles[index];
        if (!currentCandle)
            return false;
        const currentHigh = currentCandle.high;
        for (let j = index - this.LOOKBACK_PERIOD; j < index; j++) {
            const candle = candles[j];
            if (!candle || candle.high >= currentHigh) {
                return false;
            }
        }
        for (let j = index + 1; j <= index + this.LOOKBACK_PERIOD; j++) {
            const candle = candles[j];
            if (!candle || candle.high >= currentHigh) {
                return false;
            }
        }
        return true;
    }
    isPivotLow(index, candles) {
        const currentCandle = candles[index];
        if (!currentCandle)
            return false;
        const currentLow = currentCandle.low;
        for (let j = index - this.LOOKBACK_PERIOD; j < index; j++) {
            const candle = candles[j];
            if (!candle || candle.low <= currentLow) {
                return false;
            }
        }
        for (let j = index + 1; j <= index + this.LOOKBACK_PERIOD; j++) {
            const candle = candles[j];
            if (!candle || candle.low <= currentLow) {
                return false;
            }
        }
        return true;
    }
    logCurrentPivots() {
        const { latestPivotHigh, latestPivotLow } = this.strategyState;
        this.logger.info('=== CURRENT PIVOT POINTS (15,15) ===');
        if (latestPivotHigh) {
            this.logger.info(`📈 Latest Pivot HIGH: ₹${latestPivotHigh.price.toFixed(2)} at ${latestPivotHigh.timestamp.toLocaleString()}`);
        }
        else {
            this.logger.info('📈 No pivot high found yet');
        }
        if (latestPivotLow) {
            this.logger.info(`� Latest Pivot LOW: ₹${latestPivotLow.price.toFixed(2)} at ${latestPivotLow.timestamp.toLocaleString()}`);
        }
        else {
            this.logger.info('📉 No pivot low found yet');
        }
        this.logger.info('============================');
    }
    processTick(tick) {
        const now = new Date(tick.last_trade_time || tick.exchange_timestamp || tick.timestamp || new Date());
        const currentMinute = now.getMinutes();
        const currentSecond = now.getSeconds();
        const cumulativeVolume = tick.volume || 0;
        this.strategyState.lastCumulativeVolume = cumulativeVolume;
        if (currentMinute % 5 === 0 && currentSecond >= 5 && !this.isProcessingFiveMinute) {
            const lastProcessed = this.lastProcessedFiveMinuteTime;
            const currentFiveMinBoundary = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours(), currentMinute, 0, 0).getTime();
            if (!lastProcessed || currentFiveMinBoundary > lastProcessed) {
                this.isProcessingFiveMinute = true;
                this.processFiveMinuteCandle()
                    .then(() => {
                    this.lastProcessedFiveMinuteTime = currentFiveMinBoundary;
                    this.strategyState.lastFiveMinuteBoundary = new Date(currentFiveMinBoundary);
                    this.markStateAsDirty();
                    this.logger.info(`✅ Successfully processed 5-minute boundary: ${new Date(currentFiveMinBoundary).toLocaleTimeString()}`);
                })
                    .catch((error) => {
                    this.logger.error(`❌ Failed to process 5-minute candle at ${new Date(currentFiveMinBoundary).toLocaleTimeString()}:`, error);
                })
                    .finally(() => {
                    this.isProcessingFiveMinute = false;
                });
            }
        }
    }
    async processFiveMinuteCandle() {
        try {
            this.logger.info('📊 Processing 5-minute candle cycle...');
            await this.refreshRecentCandles();
            const lastProcessedForBreakout = this.strategyState.lastProcessedCandleForBreakout;
            const newCandlesForAnalysis = this.strategyState.candles.filter(candle => {
                if (!lastProcessedForBreakout)
                    return true;
                return candle.timestamp.getTime() > lastProcessedForBreakout.getTime();
            });
            if (newCandlesForAnalysis.length === 0) {
                this.logger.debug('📊 No new 5m candles to analyze for breakout (all already processed)');
                return;
            }
            this.logger.info(`📈 Analyzing ${newCandlesForAnalysis.length} NEW candle(s) for breakout (not replaying historical)`);
            for (let i = 0; i < newCandlesForAnalysis.length; i++) {
                const candle = newCandlesForAnalysis[i];
                if (!candle)
                    continue;
                const isLatestCandle = (i === newCandlesForAnalysis.length - 1);
                this.logger.info(`📊 Processing 5m candle: ${candle.timestamp.toLocaleTimeString()} - O:${candle.open} H:${candle.high} L:${candle.low} C:${candle.close} V:${candle.volume}`);
                this.updateVolumeSMA50();
                if (isLatestCandle) {
                    this.checkForBreakout(candle);
                }
                else {
                    this.logger.debug(`📊 Processing historical candle for volume/marking only: ${candle.timestamp.toLocaleString()}`);
                }
                this.processMarkingCandle(candle);
                this.strategyState.lastProcessedCandleForBreakout = candle.timestamp;
                this.markStateAsDirty();
            }
        }
        catch (error) {
            this.logger.error('❌ Error processing 5-minute candle:', error);
            throw error;
        }
    }
    startPersistenceTimer() {
        if (this.persistenceTimer) {
            clearInterval(this.persistenceTimer);
        }
        this.persistenceTimer = setInterval(async () => {
            if (this.isDirty) {
                await this.saveStateIfDirty();
            }
        }, this.PERSISTENCE_INTERVAL);
        this.logger.debug('⏰ Strategy state persistence timer started');
    }
    stopPersistenceTimer() {
        if (this.persistenceTimer) {
            clearInterval(this.persistenceTimer);
            this.persistenceTimer = null;
            this.logger.debug('⏹️ Strategy state persistence timer stopped');
        }
    }
    markStateAsDirty() {
        this.isDirty = true;
    }
    async saveStateIfDirty() {
        if (!this.isDirty)
            return;
        try {
            await this.saveStateAtomic();
            this.isDirty = false;
        }
        catch (error) {
            this.logger.error('❌ Failed to save strategy state:', error);
        }
    }
    async saveStateAtomic() {
        return await StateLock_1.globalStateLock.executeAtomic('strategy-persistence', async () => {
            const persistableState = this.strategyPersistence.convertStrategyStateToPersistedFormat(this.strategyState);
            await this.strategyPersistence.saveStrategyState(persistableState);
        });
    }
    async saveStateImmediate() {
        try {
            await this.saveStateAtomic();
            this.isDirty = false;
            this.logger.debug('💾 Strategy state saved immediately');
        }
        catch (error) {
            this.logger.error('❌ Failed to save strategy state immediately:', error);
            throw error;
        }
    }
    async validateAndRestoreState(restoredState) {
        try {
            if (!restoredState.currentContract) {
                this.logger.warn('⚠️ No contract found in restored state');
                return false;
            }
            if (restoredState.currentContract.expiry < new Date()) {
                this.logger.warn('⚠️ Restored contract has expired, starting fresh');
                return false;
            }
            this.strategyState.isActive = restoredState.isActive;
            this.strategyState.currentContract = restoredState.currentContract;
            this.strategyState.priceStreamingActive = false;
            this.strategyState.breakoutDetectionActive = false;
            this.strategyState.tradeState = restoredState.tradeState;
            if (restoredState.currentTradeId) {
                this.strategyState.currentTradeId = restoredState.currentTradeId;
            }
            if (restoredState.tradeSetupRequest) {
                this.strategyState.tradeSetupRequest = restoredState.tradeSetupRequest;
            }
            this.strategyState.candles = restoredState.candles;
            this.strategyState.latestPivotHigh = restoredState.latestPivotHigh;
            this.strategyState.latestPivotLow = restoredState.latestPivotLow;
            this.strategyState.latestBreakoutSignal = restoredState.latestBreakoutSignal;
            this.strategyState.markingCandleState = restoredState.markingCandleState;
            this.strategyState.currentVolumeSMA50 = restoredState.currentVolumeSMA50;
            this.strategyState.lastCumulativeVolume = restoredState.lastCumulativeVolume;
            if (restoredState.lastProcessedCandleForBreakout) {
                const processedDate = restoredState.lastProcessedCandleForBreakout instanceof Date
                    ? restoredState.lastProcessedCandleForBreakout
                    : new Date(restoredState.lastProcessedCandleForBreakout);
                this.strategyState.lastProcessedCandleForBreakout = processedDate;
                this.logger.info(`✅ Historical candles marked as processed up to: ${processedDate.toISOString()}`);
            }
            else if (this.strategyState.candles.length > 0) {
                const lastCandle = this.strategyState.candles[this.strategyState.candles.length - 1];
                if (lastCandle) {
                    this.strategyState.lastProcessedCandleForBreakout = lastCandle.timestamp;
                    this.logger.info(`✅ Historical candles marked as processed up to last candle: ${lastCandle.timestamp.toLocaleString()}`);
                }
            }
            if (restoredState.lastFiveMinuteBoundary) {
                const boundaryDate = new Date(restoredState.lastFiveMinuteBoundary);
                this.lastProcessedFiveMinuteTime = boundaryDate.getTime();
                this.strategyState.lastFiveMinuteBoundary = boundaryDate;
            }
            this.logger.info(`📊 Restored strategy state: ${restoredState.candles.length} 5m candles (no replay), Volume SMA50: ${restoredState.currentVolumeSMA50.toFixed(2)}`);
            return true;
        }
        catch (error) {
            this.logger.error('❌ Failed to restore strategy state:', error);
            return false;
        }
    }
    async validateTradeStateSync() {
        this.logger.info(`🔍 Starting trade state validation sync check...`);
        try {
            if (this.strategyState.currentTradeId) {
                this.logger.info(`🔍 Validating trade state sync - Trade ID: ${this.strategyState.currentTradeId}`);
                const activePosition = this.tradeExecutionService.getActivePosition();
                if (!activePosition || activePosition.tradeId !== this.strategyState.currentTradeId) {
                    this.logger.warn(`🧹 CLEANING ORPHANED STRATEGY STATE`);
                    this.logger.warn(`   Strategy Trade ID: ${this.strategyState.currentTradeId}`);
                    this.logger.warn(`   Execution Service: ${activePosition ? `Different ID: ${activePosition.tradeId}` : 'No active position'}`);
                    this.logger.warn(`   Cause: Trade was likely closed externally (manual closure, system restart, etc.)`);
                    const orphanedTradeId = this.strategyState.currentTradeId;
                    delete this.strategyState.currentTradeId;
                    delete this.strategyState.tradeSetupRequest;
                    if (this.strategyState.latestBreakoutSignal) {
                        this.logger.info(`🧹 Clearing stale breakout signal: ${this.strategyState.latestBreakoutSignal.type} @ ₹${this.strategyState.latestBreakoutSignal.price}`);
                        this.strategyState.latestBreakoutSignal = undefined;
                    }
                    this.transitionToState(TradeState.WAITING_FOR_BREAKOUT, `Cleaned orphaned trade state: ${orphanedTradeId}`);
                    this.logger.info(`✅ Strategy state cleaned - Ready for fresh breakout detection`);
                }
                else {
                    this.logger.info(`✅ Trade state validation passed - Active position confirmed`);
                }
            }
            else {
                const activePosition = this.tradeExecutionService.getActivePosition();
                if (activePosition) {
                    this.logger.warn(`🚨 CRITICAL: TradeExecutionService has active position but strategy state is missing!`);
                    this.logger.warn(`   Active Position ID: ${activePosition.tradeId}`);
                    this.logger.warn(`   Direction: ${activePosition.direction}`);
                    this.logger.warn(`   Entry: ₹${activePosition.entryPrice} | SL: ₹${activePosition.stopLoss} | Target: ₹${activePosition.target}`);
                    this.logger.warn(`   Cause: Strategy state corruption or restart without proper state restoration`);
                    this.strategyState.currentTradeId = activePosition.tradeId;
                    const targetDistance = Math.abs(activePosition.target - activePosition.entryPrice);
                    const trailingTriggerDistance = targetDistance * 0.60;
                    const trailingTriggerLevel = activePosition.direction === 'LONG'
                        ? activePosition.entryPrice + trailingTriggerDistance
                        : activePosition.entryPrice - trailingTriggerDistance;
                    this.strategyState.tradeSetupRequest = {
                        strategyId: 'breakout-pullback',
                        direction: activePosition.direction,
                        entryLevel: activePosition.entryPrice,
                        stopLossLevel: activePosition.stopLoss,
                        targetLevel: activePosition.target,
                        underlyingPrice: activePosition.instrument.underlyingPrice || 0,
                        timestamp: activePosition.entryTime,
                        originalStopLossLevel: activePosition.originalStopLoss || activePosition.stopLoss,
                        trailingTriggerLevel: trailingTriggerLevel
                    };
                    this.transitionToState(TradeState.IN_TRADE, `Restored active trade: ${activePosition.tradeId}`);
                    this.logger.info(`✅ STRATEGY STATE RESTORED - Now monitoring SL/Target levels`);
                    this.logger.info(`   🎯 Monitoring Target: ₹${activePosition.target} (${activePosition.direction})`);
                    this.logger.info(`   🛑 Monitoring Stop Loss: ₹${activePosition.stopLoss} (${activePosition.direction})`);
                }
                else {
                    if (this.strategyState.latestBreakoutSignal) {
                        this.logger.info(`🧹 Found stale breakout signal without active trade - clearing to prevent phantom detection`);
                        this.logger.info(`   Signal: ${this.strategyState.latestBreakoutSignal.type} @ ₹${this.strategyState.latestBreakoutSignal.price} from ${new Date(this.strategyState.latestBreakoutSignal.timestamp).toLocaleString()}`);
                        this.strategyState.latestBreakoutSignal = undefined;
                        this.markStateAsDirty();
                        this.logger.info(`✅ Stale breakout signal cleared - Ready for fresh detection`);
                    }
                    if (this.strategyState.markingCandleState.isActive) {
                        this.logger.info(`🧹 Found stale marking candle state without active trade - clearing to prevent phantom detection`);
                        this.logger.info(`   Marking candle was active with breakout: ${this.strategyState.markingCandleState.breakoutReference?.type}`);
                        this.strategyState.markingCandleState.isActive = false;
                        this.strategyState.markingCandleState.breakoutReference = null;
                        this.strategyState.markingCandleState.currentMarkingCandle = null;
                        this.strategyState.markingCandleState.startTime = null;
                        this.strategyState.markingCandleState.searchPhase = 'initial';
                        this.strategyState.markingCandleState.barsProcessedSinceBreakout = 0;
                        this.markStateAsDirty();
                        this.logger.info(`✅ Stale marking candle state cleared`);
                    }
                    if (!this.strategyState.latestBreakoutSignal && !this.strategyState.markingCandleState.isActive) {
                        this.logger.info(`✅ Trade state validation passed - No active trade ID found, state is clean`);
                    }
                }
            }
        }
        catch (error) {
            this.logger.error('❌ Error during trade state validation:', error);
            delete this.strategyState.currentTradeId;
            delete this.strategyState.tradeSetupRequest;
            this.transitionToState(TradeState.WAITING_FOR_BREAKOUT, 'Error recovery - state cleared');
        }
    }
    validateHistoricalVolumeData(historicalCandles) {
        if (historicalCandles.length < 2)
            return;
        let cumulativeVolumeDetected = 0;
        let normalVolumeCount = 0;
        for (let i = 1; i < Math.min(10, historicalCandles.length); i++) {
            const prevCandle = historicalCandles[i - 1];
            const currCandle = historicalCandles[i];
            if (!prevCandle || !currCandle)
                continue;
            const prevVolume = prevCandle.volume;
            const currVolume = currCandle.volume;
            if (currVolume > prevVolume && currVolume > prevVolume * 2) {
                cumulativeVolumeDetected++;
            }
            else if (currVolume > 0 && currVolume < prevVolume * 10) {
                normalVolumeCount++;
            }
        }
        if (cumulativeVolumeDetected > normalVolumeCount) {
            this.logger.warn(`⚠️ Historical volume data may be cumulative! Cumulative pattern: ${cumulativeVolumeDetected}, Normal pattern: ${normalVolumeCount}`);
        }
        else {
            this.logger.debug(`✅ Historical volume data appears to be per-candle (non-cumulative). Pattern check: ${normalVolumeCount} normal vs ${cumulativeVolumeDetected} cumulative`);
        }
        const volumes = historicalCandles.slice(0, 10).map(c => c.volume);
        const avgVolume = volumes.reduce((sum, v) => sum + v, 0) / volumes.length;
        const maxVolume = Math.max(...volumes);
        const minVolume = Math.min(...volumes);
        this.logger.debug(`📊 Historical volume analysis: Min=${minVolume}, Max=${maxVolume}, Avg=${avgVolume.toFixed(0)}`);
    }
    updateVolumeSMA50() {
        const candles = this.strategyState.candles;
        if (candles.length === 0) {
            this.strategyState.currentVolumeSMA50 = 0;
            return;
        }
        const period = Math.min(50, candles.length);
        const recentCandles = candles.slice(-period);
        const totalVolume = recentCandles.reduce((sum, candle) => sum + candle.volume, 0);
        this.strategyState.currentVolumeSMA50 = totalVolume / period;
        this.logger.debug(`📊 Volume SMA50 updated: ${this.strategyState.currentVolumeSMA50.toFixed(0)} (based on ${period} x 5m candles = ${(period * 5)} minutes, total array size: ${candles.length})`);
    }
    checkForBreakout(completedCandle) {
        try {
            this.logger.info(`🔍 BREAKOUT DETECTION ANALYSIS:`);
            this.logger.info(`   📊 Candle: O:${completedCandle.open.toFixed(2)} H:${completedCandle.high.toFixed(2)} L:${completedCandle.low.toFixed(2)} C:${completedCandle.close.toFixed(2)} V:${completedCandle.volume}`);
            this.logger.info(`   ⏰ Time: ${completedCandle.timestamp.toLocaleString()}`);
            this.logger.info(`   🎯 Market Hours: ${this.isMarketHours()}`);
            this.logger.info(`   📈 Trade State: ${this.strategyState.tradeState}`);
            this.logger.info(`   📊 5m Candles: ${this.strategyState.candles.length}`);
            this.logger.info(`   📊 Volume SMA50: ${this.strategyState.currentVolumeSMA50.toFixed(0)}`);
            this.logger.info(`   🎯 Pivot High: ${this.strategyState.latestPivotHigh?.price.toFixed(2) || 'N/A'}`);
            this.logger.info(`   🎯 Pivot Low: ${this.strategyState.latestPivotLow?.price.toFixed(2) || 'N/A'}`);
            if (this.strategyState.tradeState !== TradeState.WAITING_FOR_BREAKOUT) {
                this.logger.info(`🔒 BREAKOUT SKIPPED - Current state: ${this.strategyState.tradeState} (need: WAITING_FOR_BREAKOUT)`);
                return;
            }
            if (!this.strategyState.latestPivotHigh && !this.strategyState.latestPivotLow) {
                this.logger.info('⛔ BREAKOUT SKIPPED - No pivots available for breakout detection');
                return;
            }
            if (this.strategyState.candles.length < 50) {
                this.logger.info(`⛔ BREAKOUT SKIPPED - Insufficient 5m candles for volume SMA50 (${this.strategyState.candles.length}/50)`);
                return;
            }
            if (this.strategyState.currentVolumeSMA50 <= 0) {
                this.logger.info('⛔ BREAKOUT SKIPPED - Volume SMA50 not available or zero');
                return;
            }
            const volumeRatio = completedCandle.volume / this.strategyState.currentVolumeSMA50;
            this.logger.info(`✅ BREAKOUT CONDITIONS MET - Analyzing candle: V:${completedCandle.volume} (${volumeRatio.toFixed(2)}x SMA50)`);
            if (!this.isMarketHours()) {
                this.logger.info('🔒 BREAKOUT SKIPPED - Outside market hours (9:15 AM - 3:30 PM). Post-market data ignored.');
                return;
            }
            if (this.strategyState.latestPivotHigh) {
                const pivotHigh = this.strategyState.latestPivotHigh.price;
                if (completedCandle.close > pivotHigh || completedCandle.high > pivotHigh) {
                    this.logger.info(`🔍 POTENTIAL LONG BREAKOUT ANALYSIS:`);
                    this.logger.info(`   📊 Candle: O:${completedCandle.open.toFixed(2)} H:${completedCandle.high.toFixed(2)} L:${completedCandle.low.toFixed(2)} C:${completedCandle.close.toFixed(2)}`);
                    this.logger.info(`   🎯 Pivot High: ${pivotHigh.toFixed(2)}`);
                    this.logger.info(`   ✅ Close > Pivot: ${completedCandle.close > pivotHigh}`);
                    this.logger.info(`   ✅ Low < Pivot: ${completedCandle.low < pivotHigh} (avoids gap-ups)`);
                    this.logger.info(`   ✅ Candle Direction: ${completedCandle.close > completedCandle.open ? 'BULLISH (Green)' : 'BEARISH (Red)'}`);
                    this.logger.info(`   ✅ Volume > SMA50: ${completedCandle.volume > this.strategyState.currentVolumeSMA50} (${completedCandle.volume} vs ${this.strategyState.currentVolumeSMA50.toFixed(0)})`);
                }
                if (completedCandle.close > pivotHigh &&
                    completedCandle.low < pivotHigh &&
                    completedCandle.close > completedCandle.open &&
                    completedCandle.volume > this.strategyState.currentVolumeSMA50) {
                    if (this.dailyPivots && completedCandle.close <= this.dailyPivots.r1) {
                        this.logger.info(`🚫 LONG BREAKOUT REJECTED - Daily pivot filter: Price ₹${completedCandle.close.toFixed(2)} ≤ R1 ₹${this.dailyPivots.r1.toFixed(2)}`);
                        return;
                    }
                    if (this.dailyPivots) {
                        this.logger.info(`✅ LONG BREAKOUT APPROVED - Daily pivot filter: Price ₹${completedCandle.close.toFixed(2)} > R1 ₹${this.dailyPivots.r1.toFixed(2)}`);
                    }
                    else {
                        this.logger.info(`⚠️ LONG BREAKOUT APPROVED - Daily pivots not available, filter bypassed`);
                    }
                    const breakoutSignal = {
                        type: 'long_breakout',
                        price: completedCandle.close,
                        timestamp: completedCandle.timestamp,
                        volume: completedCandle.volume,
                        volumeMA50: this.strategyState.currentVolumeSMA50,
                        pivotPrice: pivotHigh,
                        pivotType: 'high',
                        candleOpen: completedCandle.open,
                        candleClose: completedCandle.close,
                        candleHigh: completedCandle.high,
                        candleLow: completedCandle.low,
                        volumeRatio: volumeRatio
                    };
                    this.strategyState.latestBreakoutSignal = breakoutSignal;
                    this.markStateAsDirty();
                    this.logger.info(`🚀 LONG BREAKOUT DETECTED!`);
                    this.logger.info(`   📈 Breakout Price: ₹${completedCandle.close.toFixed(2)} (Open: ₹${completedCandle.open.toFixed(2)})`);
                    this.logger.info(`   🎯 Pivot High: ₹${pivotHigh.toFixed(2)}`);
                    this.logger.info(`   📊 Volume: ${completedCandle.volume.toLocaleString()} (${volumeRatio.toFixed(2)}x SMA50: ${this.strategyState.currentVolumeSMA50.toFixed(0)})`);
                    this.logger.info(`   ⏰ Time: ${completedCandle.timestamp.toLocaleString()}`);
                    this.transitionToState(TradeState.WAITING_FOR_ENTRY, 'LONG breakout detected');
                    this.startMarkingCandleTracking(breakoutSignal);
                    return;
                }
            }
            if (this.strategyState.latestPivotLow) {
                const pivotLow = this.strategyState.latestPivotLow.price;
                if (completedCandle.close < pivotLow || completedCandle.low < pivotLow) {
                    this.logger.info(`🔍 POTENTIAL SHORT BREAKOUT ANALYSIS:`);
                    this.logger.info(`   📊 Candle: O:${completedCandle.open.toFixed(2)} H:${completedCandle.high.toFixed(2)} L:${completedCandle.low.toFixed(2)} C:${completedCandle.close.toFixed(2)}`);
                    this.logger.info(`   🎯 Pivot Low: ${pivotLow.toFixed(2)}`);
                    this.logger.info(`   ✅ Close < Pivot: ${completedCandle.close < pivotLow}`);
                    this.logger.info(`   ✅ High > Pivot: ${completedCandle.high > pivotLow} (avoids gap-downs)`);
                    this.logger.info(`   ✅ Candle Direction: ${completedCandle.close < completedCandle.open ? 'BEARISH (Red)' : 'BULLISH (Green)'}`);
                    this.logger.info(`   ✅ Volume > SMA50: ${completedCandle.volume > this.strategyState.currentVolumeSMA50} (${completedCandle.volume} vs ${this.strategyState.currentVolumeSMA50.toFixed(0)})`);
                }
                if (completedCandle.close < pivotLow &&
                    completedCandle.high > pivotLow &&
                    completedCandle.close < completedCandle.open &&
                    completedCandle.volume > this.strategyState.currentVolumeSMA50) {
                    if (this.dailyPivots && completedCandle.close >= this.dailyPivots.r1) {
                        this.logger.info(`🚫 SHORT BREAKOUT REJECTED - Daily pivot filter: Price ₹${completedCandle.close.toFixed(2)} ≥ R1 ₹${this.dailyPivots.r1.toFixed(2)}`);
                        return;
                    }
                    if (this.dailyPivots) {
                        this.logger.info(`✅ SHORT BREAKOUT APPROVED - Daily pivot filter: Price ₹${completedCandle.close.toFixed(2)} < R1 ₹${this.dailyPivots.r1.toFixed(2)}`);
                    }
                    else {
                        this.logger.info(`⚠️ SHORT BREAKOUT APPROVED - Daily pivots not available, filter bypassed`);
                    }
                    const breakoutSignal = {
                        type: 'short_breakout',
                        price: completedCandle.close,
                        timestamp: completedCandle.timestamp,
                        volume: completedCandle.volume,
                        volumeMA50: this.strategyState.currentVolumeSMA50,
                        pivotPrice: pivotLow,
                        pivotType: 'low',
                        candleOpen: completedCandle.open,
                        candleClose: completedCandle.close,
                        candleHigh: completedCandle.high,
                        candleLow: completedCandle.low,
                        volumeRatio: volumeRatio
                    };
                    this.strategyState.latestBreakoutSignal = breakoutSignal;
                    this.markStateAsDirty();
                    this.logger.info(`🚀 SHORT BREAKOUT DETECTED!`);
                    this.logger.info(`   📉 Breakout Price: ₹${completedCandle.close.toFixed(2)} (Open: ₹${completedCandle.open.toFixed(2)})`);
                    this.logger.info(`   🎯 Pivot Low: ₹${pivotLow.toFixed(2)}`);
                    this.logger.info(`   📊 Volume: ${completedCandle.volume.toLocaleString()} (${volumeRatio.toFixed(2)}x SMA50: ${this.strategyState.currentVolumeSMA50.toFixed(0)})`);
                    this.logger.info(`   ⏰ Time: ${completedCandle.timestamp.toLocaleString()}`);
                    this.transitionToState(TradeState.WAITING_FOR_ENTRY, 'SHORT breakout detected');
                    this.startMarkingCandleTracking(breakoutSignal);
                }
            }
        }
        catch (error) {
            this.logger.error('❌ Error in breakout detection:', error);
        }
    }
    transitionToState(newState, reason) {
        const previousState = this.strategyState.tradeState;
        this.strategyState.tradeState = newState;
        this.logger.info(`🔄 Trade State Transition: ${previousState} → ${newState}${reason ? ` (${reason})` : ''}`);
        this.markStateAsDirty();
        if (newState === TradeState.WAITING_FOR_ENTRY || newState === TradeState.IN_TRADE) {
            this.saveStateImmediate().catch(error => {
                this.logger.error('❌ Failed to save state after critical transition:', error);
            });
        }
        this.performStateRecovery(newState, previousState);
        switch (newState) {
            case TradeState.WAITING_FOR_BREAKOUT:
                this.resetTradeSetup();
                this.enableBreakoutDetection();
                break;
            case TradeState.WAITING_FOR_ENTRY:
                this.disableBreakoutDetection();
                break;
            case TradeState.IN_TRADE:
                this.disableBreakoutDetection();
                this.disableMarkingCandleSystem();
                break;
        }
    }
    performStateRecovery(newState, previousState) {
        try {
            const activePosition = this.tradeExecutionService.getActivePosition();
            const hasStrategyTradeId = !!this.strategyState.currentTradeId;
            const hasServicePosition = !!activePosition;
            if (newState === TradeState.WAITING_FOR_BREAKOUT) {
                if (hasServicePosition) {
                    this.logger.warn(`🔧 State Recovery: Found orphaned position ${activePosition.tradeId} - attempting cleanup`);
                    this.logger.error(`🚨 MANUAL INTERVENTION REQUIRED: Orphaned position detected`);
                }
            }
            if (newState === TradeState.IN_TRADE) {
                if (!hasServicePosition && hasStrategyTradeId) {
                    this.logger.warn(`🔧 State Recovery: Strategy has trade ID but no service position - clearing strategy state`);
                    delete this.strategyState.currentTradeId;
                }
            }
            if (hasStrategyTradeId && hasServicePosition && activePosition.tradeId !== this.strategyState.currentTradeId) {
                this.logger.warn(`🔧 State Recovery: ID mismatch - Strategy: ${this.strategyState.currentTradeId}, Service: ${activePosition.tradeId}`);
                this.strategyState.currentTradeId = activePosition.tradeId;
            }
        }
        catch (error) {
            this.logger.error('❌ Error in state recovery:', error);
        }
    }
    resetTradeSetup() {
        delete this.strategyState.currentTradeId;
        delete this.strategyState.tradeSetupRequest;
        this.strategyState.markingCandleState.isActive = false;
        this.strategyState.markingCandleState.breakoutReference = null;
        this.strategyState.markingCandleState.startTime = null;
        this.strategyState.markingCandleState.currentMarkingCandle = null;
        this.strategyState.markingCandleState.searchPhase = 'initial';
        this.strategyState.markingCandleState.barsProcessedSinceBreakout = 0;
        this.strategyState.markingCandleState.maxUpdatesReached = false;
        this.strategyState.markingCandleState.timeExpired = false;
        this.strategyState.markingCandleState.tradeSkipped = false;
    }
    disableBreakoutDetection() {
        this.strategyState.breakoutDetectionActive = false;
        if (this.strategyState.latestBreakoutSignal) {
            this.logger.info(`🧹 Clearing stale breakout signal: ${this.strategyState.latestBreakoutSignal.type} @ ₹${this.strategyState.latestBreakoutSignal.price}`);
            this.strategyState.latestBreakoutSignal = undefined;
        }
    }
    enableBreakoutDetection() {
        this.strategyState.breakoutDetectionActive = true;
    }
    disableMarkingCandleSystem() {
        this.strategyState.markingCandleState.isActive = false;
        this.strategyState.markingCandleState.searchPhase = 'initial';
        this.strategyState.markingCandleState.barsProcessedSinceBreakout = 0;
        this.strategyState.markingCandleState.tradeSkipped = false;
        this.strategyState.markingCandleState.maxUpdatesReached = false;
        this.strategyState.markingCandleState.currentMarkingCandle = null;
        this.strategyState.markingCandleState.breakoutReference = null;
        this.strategyState.markingCandleState.startTime = null;
        this.logger.info(`🧹 Marking candle system disabled and state reset`);
    }
    calculateCappedStopLoss(entryPrice, naturalSL, direction) {
        if (!this.strategyState.livePrice) {
            this.logger.warn('⚠️ No live price available for SL cap calculation, using natural SL');
            return naturalSL;
        }
        const futurePrice = this.strategyState.livePrice.last_price;
        const targetPoints = Math.round(futurePrice / 1000);
        const maxSLDistance = targetPoints * this.SL_CAP_RATIO;
        const naturalSLDistance = Math.abs(entryPrice - naturalSL);
        if (naturalSLDistance > maxSLDistance) {
            const cappedSL = direction === 'LONG'
                ? entryPrice - maxSLDistance
                : entryPrice + maxSLDistance;
            this.logger.info(`⚠️ Wide marking candle detected! Natural SL: ${naturalSLDistance.toFixed(2)} pts, ` +
                `Capping at ${maxSLDistance.toFixed(2)} pts (${(this.SL_CAP_RATIO * 100)}% of ${targetPoints} pt target) ` +
                `for minimum 1:2.5 R:R`);
            this.logger.info(`   🔒 Natural SL: ₹${naturalSL.toFixed(2)} → Capped SL: ₹${cappedSL.toFixed(2)}`);
            return cappedSL;
        }
        else {
            this.logger.debug(`✅ SL within limits: ${naturalSLDistance.toFixed(2)} pts ≤ ${maxSLDistance.toFixed(2)} pts max, ` +
                `using natural SL`);
            return naturalSL;
        }
    }
    calculateTargetLevel(entryLevel, direction) {
        if (!this.strategyState.livePrice) {
            throw new Error('No live price available for target calculation');
        }
        const futurePrice = this.strategyState.livePrice.last_price;
        const targetPoints = Math.round(futurePrice / 1000);
        const targetLevel = direction === 'LONG'
            ? entryLevel + targetPoints
            : entryLevel - targetPoints;
        this.logger.info(`📊 Target Calculation: Entry ${entryLevel}, FUT ${futurePrice} → Target ${targetLevel} (${targetPoints} pts)`);
        return targetLevel;
    }
    createTradeSetupRequest(direction, entryLevel, stopLossLevel) {
        const targetLevel = this.calculateTargetLevel(entryLevel, direction);
        const targetDistance = Math.abs(targetLevel - entryLevel);
        const trailingTriggerDistance = targetDistance * 0.60;
        let trailingTriggerLevel;
        if (direction === 'LONG') {
            trailingTriggerLevel = entryLevel + trailingTriggerDistance;
        }
        else {
            trailingTriggerLevel = entryLevel - trailingTriggerDistance;
        }
        const tradeRequest = {
            strategyId: 'nifty-breakout-retracement',
            direction,
            entryLevel,
            stopLossLevel,
            targetLevel,
            underlyingPrice: this.strategyState.livePrice?.last_price || 0,
            timestamp: new Date(),
            originalStopLossLevel: stopLossLevel,
            trailingTriggerLevel: trailingTriggerLevel
        };
        this.logger.info(`🎯 Trade Setup Created: ${direction} | Entry: ₹${entryLevel} | SL: ₹${stopLossLevel} | Target: ₹${targetLevel}`);
        this.logger.info(`   📊 Target Distance: ${targetDistance.toFixed(2)} points | 60% Trailing Trigger: ₹${trailingTriggerLevel.toFixed(2)}`);
        return tradeRequest;
    }
    createAndStoreTradeSetup(markingCandle) {
        if (!this.strategyState.markingCandleState.breakoutReference) {
            this.logger.error('❌ Cannot create trade setup - no breakout reference');
            return;
        }
        const breakoutType = this.strategyState.markingCandleState.breakoutReference.type;
        const direction = breakoutType === 'long_breakout' ? 'LONG' : 'SHORT';
        const tradeRequest = this.createTradeSetupRequest(direction, markingCandle.entryPrice, markingCandle.stopLoss);
        this.strategyState.tradeSetupRequest = tradeRequest;
        this.logger.info(`💾 Trade Setup Stored in Strategy State`);
    }
    monitorTradeLevels(currentPrice) {
        switch (this.strategyState.tradeState) {
            case TradeState.WAITING_FOR_ENTRY:
                this.checkEntryTrigger(currentPrice);
                break;
            case TradeState.IN_TRADE:
                this.checkExitTriggers(currentPrice);
                break;
            case TradeState.WAITING_FOR_BREAKOUT:
                break;
        }
    }
    checkEntryTrigger(currentPrice) {
        if (!this.strategyState.tradeSetupRequest) {
            return;
        }
        const setup = this.strategyState.tradeSetupRequest;
        const entryLevel = setup.entryLevel;
        const direction = setup.direction;
        let entryTriggered = false;
        if (direction === 'LONG' && currentPrice >= entryLevel) {
            entryTriggered = true;
            this.logger.info(`🚀 LONG ENTRY TRIGGERED! Price ${currentPrice} >= Entry ${entryLevel}`);
        }
        else if (direction === 'SHORT' && currentPrice <= entryLevel) {
            entryTriggered = true;
            this.logger.info(`🚀 SHORT ENTRY TRIGGERED! Price ${currentPrice} <= Entry ${entryLevel}`);
        }
        if (entryTriggered) {
            if (this.isExecutingEntry) {
                this.logger.debug('🔒 Entry execution already in progress, skipping duplicate trigger');
                return;
            }
            this.isExecutingEntry = true;
            this.executeTradeEntry()
                .catch(error => {
                this.logger.error('Entry execution error handled in async context:', error);
            })
                .finally(() => {
                this.isExecutingEntry = false;
            });
        }
    }
    checkExitTriggers(currentPrice) {
        if (!this.strategyState.tradeSetupRequest) {
            return;
        }
        const setup = this.strategyState.tradeSetupRequest;
        const direction = setup.direction;
        const activePosition = this.tradeExecutionService.getActivePosition();
        if (!activePosition) {
            return;
        }
        if (!activePosition.isTrailingActive) {
            const trailingTrigger = setup.trailingTriggerLevel;
            let trailingTriggered = false;
            if (direction === 'LONG' && currentPrice >= trailingTrigger) {
                trailingTriggered = true;
                this.logger.info(`✅ LONG 60% Trailing Triggered! Price ₹${currentPrice} >= Trigger ₹${trailingTrigger.toFixed(2)}`);
            }
            else if (direction === 'SHORT' && currentPrice <= trailingTrigger) {
                trailingTriggered = true;
                this.logger.info(`✅ SHORT 60% Trailing Triggered! Price ₹${currentPrice} <= Trigger ₹${trailingTrigger.toFixed(2)}`);
            }
            if (trailingTriggered) {
                const entryPrice = activePosition.entryPrice;
                this.tradeExecutionService.updateStopLossToCost(entryPrice);
                setup.stopLossLevel = entryPrice;
                this.logger.info(`🛡️ STOP LOSS MOVED TO COST: ₹${entryPrice.toFixed(2)}`);
                this.logger.info(`   Original SL: ₹${setup.originalStopLossLevel.toFixed(2)} → New SL: ₹${entryPrice.toFixed(2)}`);
                this.logger.info(`   Trade now protected - minimum result: BREAKEVEN`);
                this.markStateAsDirty();
            }
        }
        const stopLoss = setup.stopLossLevel;
        const target = setup.targetLevel;
        let exitTriggered = false;
        let exitReason = '';
        if (direction === 'LONG' && currentPrice <= stopLoss) {
            exitTriggered = true;
            exitReason = 'STOP_LOSS';
            this.logger.info(`🛑 LONG SL HIT! Price ₹${currentPrice} <= SL ₹${stopLoss}`);
        }
        else if (direction === 'SHORT' && currentPrice >= stopLoss) {
            exitTriggered = true;
            exitReason = 'STOP_LOSS';
            this.logger.info(`🛑 SHORT SL HIT! Price ₹${currentPrice} >= SL ₹${stopLoss}`);
        }
        if (!exitTriggered) {
            if (direction === 'LONG' && currentPrice >= target) {
                exitTriggered = true;
                exitReason = 'TARGET';
                this.logger.info(`🎯 LONG TARGET HIT! Price ₹${currentPrice} >= Target ₹${target}`);
            }
            else if (direction === 'SHORT' && currentPrice <= target) {
                exitTriggered = true;
                exitReason = 'TARGET';
                this.logger.info(`🎯 SHORT TARGET HIT! Price ₹${currentPrice} <= Target ₹${target}`);
            }
        }
        if (exitTriggered) {
            if (this.isExecutingExit) {
                this.logger.debug('🔒 Exit execution already in progress, skipping duplicate trigger');
                return;
            }
            this.isExecutingExit = true;
            this.executeTradeExit(exitReason)
                .catch(error => {
                this.logger.error('Exit execution error handled in async context:', error);
            })
                .finally(() => {
                this.isExecutingExit = false;
            });
        }
    }
    async executeTradeEntry() {
        return await StateLock_1.globalStateLock.executeAtomic('trade-entry', async () => {
            try {
                this.logger.info(`📞 Calling TradeExecutionService to PLACE MARKET ORDER`);
                if (!this.strategyState.tradeSetupRequest) {
                    throw new Error('No trade setup request available for entry execution');
                }
                const activePosition = this.tradeExecutionService.getActivePosition();
                if (activePosition) {
                    throw new Error(`Cannot place order: Active position exists ${activePosition.tradeId}`);
                }
                const tradeId = await this.tradeExecutionService.placeMarketOrder(this.strategyState.tradeSetupRequest);
                this.strategyState.currentTradeId = tradeId;
                const newActivePosition = this.tradeExecutionService.getActivePosition();
                if (!newActivePosition || newActivePosition.tradeId !== tradeId) {
                    this.logger.warn(`⚠️ State sync warning: Strategy ID ${tradeId} != Service position ${newActivePosition?.tradeId}`);
                }
                this.transitionToState(TradeState.IN_TRADE, 'Entry level crossed - Order placed');
                this.logger.info(`✅ Trade entry executed - Trade ID: ${tradeId} - Now monitoring SL/Target levels`);
            }
            catch (error) {
                this.logger.error('❌ Error executing trade entry:', error);
                const activePosition = this.tradeExecutionService.getActivePosition();
                if (activePosition) {
                    this.logger.warn(`⚠️ Entry error but position exists: ${activePosition.tradeId}`);
                    if (this.strategyState.tradeState === TradeState.IN_TRADE) {
                        this.logger.info(`✅ Already IN_TRADE - preserving state (race condition handled)`);
                        return;
                    }
                    else {
                        this.logger.warn(`🔧 State recovery: Setting currentTradeId and transitioning to IN_TRADE`);
                        this.strategyState.currentTradeId = activePosition.tradeId;
                        this.transitionToState(TradeState.IN_TRADE, 'State recovered from orphaned position');
                        return;
                    }
                }
                this.logger.info(`📉 No position found - genuine entry failure, resetting to WAITING_FOR_BREAKOUT`);
                this.transitionToState(TradeState.WAITING_FOR_BREAKOUT, 'Entry execution failed');
            }
        });
    }
    async executeTradeExit(reason) {
        return await StateLock_1.globalStateLock.executeAtomic('trade-exit', async () => {
            try {
                this.logger.info(`📞 Calling TradeExecutionService to CLOSE POSITION - Reason: ${reason}`);
                if (!this.strategyState.currentTradeId) {
                    throw new Error('No active trade ID available for exit execution');
                }
                const activePosition = this.tradeExecutionService.getActivePosition();
                if (!activePosition) {
                    this.logger.warn(`⚠️ No active position found in service for trade ID: ${this.strategyState.currentTradeId}`);
                    delete this.strategyState.currentTradeId;
                    this.transitionToState(TradeState.WAITING_FOR_BREAKOUT, `Trade ID cleared: ${reason}`);
                    return;
                }
                if (activePosition.tradeId !== this.strategyState.currentTradeId) {
                    this.logger.warn(`⚠️ State sync mismatch: Strategy ID ${this.strategyState.currentTradeId} != Service ID ${activePosition.tradeId}`);
                }
                const exitReason = reason.includes('TARGET') ? 'TARGET' :
                    reason.includes('STOP_LOSS') ? 'STOP_LOSS' : 'MANUAL';
                await this.tradeExecutionService.closePosition(this.strategyState.currentTradeId, exitReason);
                delete this.strategyState.currentTradeId;
                const remainingPosition = this.tradeExecutionService.getActivePosition();
                if (remainingPosition) {
                    this.logger.warn(`⚠️ Position still active after close: ${remainingPosition.tradeId}`);
                }
                this.transitionToState(TradeState.WAITING_FOR_BREAKOUT, `Trade closed: ${reason}`);
                this.logger.info(`✅ Trade exit executed - Returning to breakout monitoring`);
            }
            catch (error) {
                this.logger.error('❌ Error executing trade exit:', error);
                const remainingPosition = this.tradeExecutionService.getActivePosition();
                if (remainingPosition) {
                    this.logger.warn(`⚠️ Exit error but position still exists: ${remainingPosition.tradeId}`);
                    this.logger.warn(`🔧 Keeping state as IN_TRADE to continue monitoring SL/Target`);
                    return;
                }
                else {
                    this.logger.info(`✅ No position found after exit error - safe to reset state`);
                    delete this.strategyState.currentTradeId;
                    this.transitionToState(TradeState.WAITING_FOR_BREAKOUT, `Trade exit error: ${reason}`);
                }
            }
        });
    }
    async handleManualExit() {
        return await StateLock_1.globalStateLock.executeAtomic('manual-exit', async () => {
            try {
                this.logger.info(`🔄 Processing manual exit - Current state: ${this.strategyState.tradeState}`);
                const remainingPosition = this.tradeExecutionService.getActivePosition();
                if (remainingPosition) {
                    this.logger.warn(`⚠️ Found orphaned position in TradeExecutionService: ${remainingPosition.tradeId}`);
                    this.logger.info(`🧹 Clearing orphaned position and fetching exit price from broker...`);
                    try {
                        await this.tradeExecutionService.clearOrphanedPositionWithExitPrice();
                        this.logger.info(`✅ Orphaned position cleared with exit price and P&L recorded`);
                    }
                    catch (error) {
                        this.logger.error('❌ Error fetching exit price, falling back to basic clear:', error);
                        this.tradeExecutionService.clearOrphanedPosition();
                        this.logger.info(`✅ Orphaned position cleared (without exit price)`);
                    }
                }
                if (this.strategyState.tradeState !== TradeState.IN_TRADE) {
                    this.logger.warn(`⚠️ Manual exit called but not in trade state: ${this.strategyState.tradeState}`);
                    delete this.strategyState.currentTradeId;
                    delete this.strategyState.tradeSetupRequest;
                    this.disableMarkingCandleSystem();
                    this.transitionToState(TradeState.WAITING_FOR_BREAKOUT, 'Manual exit - State cleanup');
                    this.logger.info(`✅ Strategy state reset to WAITING_FOR_BREAKOUT`);
                    return;
                }
                if (!this.strategyState.currentTradeId) {
                    this.logger.warn(`⚠️ Manual exit called but no current trade ID`);
                    this.transitionToState(TradeState.WAITING_FOR_BREAKOUT, 'Manual exit - No trade ID');
                    return;
                }
                this.logger.info(`🚨 Manual exit executed for trade ID: ${this.strategyState.currentTradeId}`);
                const exitedTradeId = this.strategyState.currentTradeId;
                delete this.strategyState.currentTradeId;
                delete this.strategyState.tradeSetupRequest;
                this.disableMarkingCandleSystem();
                this.transitionToState(TradeState.WAITING_FOR_BREAKOUT, `Manual exit - Trade ID: ${exitedTradeId}`);
                this.logger.info(`✅ Manual exit processed - Strategy resumed breakout monitoring`);
            }
            catch (error) {
                this.logger.error('❌ Error processing manual exit:', error);
                try {
                    await this.tradeExecutionService.clearOrphanedPositionWithExitPrice();
                }
                catch (clearError) {
                    this.logger.error('❌ Error clearing orphaned position during error recovery:', clearError);
                    try {
                        this.tradeExecutionService.clearOrphanedPosition();
                    }
                    catch (basicClearError) {
                        this.logger.error('❌ Error with basic clear:', basicClearError);
                    }
                }
                delete this.strategyState.currentTradeId;
                delete this.strategyState.tradeSetupRequest;
                this.disableMarkingCandleSystem();
                this.transitionToState(TradeState.WAITING_FOR_BREAKOUT, `Manual exit error recovery`);
            }
        });
    }
    startMarkingCandleTracking(breakoutSignal) {
        this.logger.info(`🔍 Starting marking candle tracking for ${breakoutSignal.type}`);
        this.logger.info(`📊 Breakout Candle OHLC: O:${breakoutSignal.candleOpen} H:${breakoutSignal.candleHigh} L:${breakoutSignal.candleLow} C:${breakoutSignal.candleClose}`);
        this.strategyState.markingCandleState = {
            isActive: true,
            breakoutReference: breakoutSignal,
            startTime: breakoutSignal.timestamp,
            currentMarkingCandle: null,
            searchPhase: 'initial',
            barsProcessedSinceBreakout: 0,
            maxUpdatesReached: false,
            timeExpired: false,
            tradeSkipped: false
        };
        this.logger.info(`✅ Marking candle tracking ACTIVATED - isActive: ${this.strategyState.markingCandleState.isActive}`);
        const direction = breakoutSignal.type === 'long_breakout' ? 'LONG' : 'SHORT';
        const underlyingPrice = breakoutSignal.price;
        this.tradeExecutionService.onBreakoutDetected(direction, underlyingPrice, breakoutSignal.timestamp);
    }
    processMarkingCandle(completedCandle) {
        if (!this.strategyState.markingCandleState.isActive) {
            this.logger.debug(`🔒 Marking candle tracking not active, skipping processing`);
            return;
        }
        if (this.strategyState.tradeState !== TradeState.WAITING_FOR_ENTRY) {
            this.logger.warn(`🚫 Marking candle processing skipped - Wrong state: ${this.strategyState.tradeState} (need: WAITING_FOR_ENTRY)`);
            this.logger.warn(`   isActive=${this.strategyState.markingCandleState.isActive} but state is ${this.strategyState.tradeState}`);
            this.logger.warn(`   This indicates orphaned marking candle state - disabling tracking`);
            this.strategyState.markingCandleState.isActive = false;
            return;
        }
        this.logger.debug(`🕯️ Processing marking candle: O:${completedCandle.open} H:${completedCandle.high} L:${completedCandle.low} C:${completedCandle.close}`);
        const markingState = this.strategyState.markingCandleState;
        if (markingState.startTime) {
            const minutesElapsed = (completedCandle.timestamp.getTime() - markingState.startTime.getTime()) / (1000 * 60);
            this.logger.debug(`⏰ Time elapsed since breakout: ${minutesElapsed.toFixed(1)} minutes (limit: ${this.TIME_LIMIT_MINUTES} minutes)`);
            if (minutesElapsed > this.TIME_LIMIT_MINUTES) {
                this.logger.info(`⏰ ${this.TIME_LIMIT_MINUTES}-minute time limit exceeded for marking candle tracking`);
                this.skipMarkingCandleTrade('time_limit_exceeded');
                return;
            }
        }
        markingState.barsProcessedSinceBreakout++;
        this.logger.debug(`📊 Bars processed since breakout: ${markingState.barsProcessedSinceBreakout} (phase: ${markingState.searchPhase})`);
        if (markingState.searchPhase === 'initial') {
            if (markingState.barsProcessedSinceBreakout <= this.INITIAL_SEARCH_BARS) {
                this.logger.debug(`🔍 Looking for initial marking candle (bar ${markingState.barsProcessedSinceBreakout}/${this.INITIAL_SEARCH_BARS})`);
                const markingCandle = this.checkForInitialMarkingCandle(completedCandle);
                if (markingCandle) {
                    markingState.currentMarkingCandle = markingCandle;
                    markingState.searchPhase = 'updates';
                    this.logger.info(`✅ INITIAL MARKING CANDLE FOUND!`);
                    this.logMarkingCandleDetails(markingCandle);
                    this.createAndStoreTradeSetup(markingCandle);
                }
                else {
                    this.logger.debug(`❌ No marking candle found in bar ${markingState.barsProcessedSinceBreakout}`);
                }
            }
            else {
                this.logger.info(`❌ No marking candle found within 10 bars after breakout`);
                this.skipMarkingCandleTrade('no_marking_candle');
                return;
            }
        }
        else if (markingState.searchPhase === 'updates') {
            if (!markingState.maxUpdatesReached) {
                const updatedMarkingCandle = this.checkForMarkingCandleUpdate(completedCandle);
                if (updatedMarkingCandle) {
                    markingState.currentMarkingCandle = updatedMarkingCandle;
                    this.logger.info(`🔄 MARKING CANDLE UPDATED! (Count: ${updatedMarkingCandle.updateCount})`);
                    this.logMarkingCandleDetails(updatedMarkingCandle);
                    this.createAndStoreTradeSetup(updatedMarkingCandle);
                    if (updatedMarkingCandle.updateCount >= 1) {
                        markingState.maxUpdatesReached = true;
                        this.logger.info(`🚫 Maximum 1 update reached`);
                    }
                }
            }
            else {
                this.logger.debug(`🚫 Maximum updates reached, no more marking candle updates allowed`);
            }
        }
    }
    checkForInitialMarkingCandle(candle) {
        const breakoutRef = this.strategyState.markingCandleState.breakoutReference;
        if (!breakoutRef)
            return null;
        const isLongBreakout = breakoutRef.type === 'long_breakout';
        const breakoutCandle = {
            open: breakoutRef.candleOpen,
            close: breakoutRef.candleClose,
            high: breakoutRef.candleHigh,
            low: breakoutRef.candleLow
        };
        this.logger.debug(`🔍 Checking marking candle: Candle OHLC: O:${candle.open} H:${candle.high} L:${candle.low} C:${candle.close}`);
        this.logger.debug(`📊 Breakout Candle Range: H:${breakoutCandle.high} L:${breakoutCandle.low}`);
        const candleIsRed = candle.close < candle.open;
        const candleIsGreen = candle.close > candle.open;
        if (isLongBreakout && !candleIsRed) {
            this.logger.debug(`❌ Long breakout needs RED marking candle, but candle is ${candleIsRed ? 'RED' : 'GREEN'}`);
            return null;
        }
        if (!isLongBreakout && !candleIsGreen) {
            this.logger.debug(`❌ Short breakout needs GREEN marking candle, but candle is ${candleIsGreen ? 'GREEN' : 'RED'}`);
            return null;
        }
        if (candle.close < breakoutCandle.low || candle.close > breakoutCandle.high) {
            this.logger.debug(`❌ Candle close ${candle.close} outside breakout range [${breakoutCandle.low}, ${breakoutCandle.high}]`);
            return null;
        }
        this.logger.info(`✅ VALID MARKING CANDLE FOUND! Close: ${candle.close} within range [${breakoutCandle.low}, ${breakoutCandle.high}]`);
        const entryPrice = isLongBreakout ? candle.high : candle.low;
        const naturalSL = isLongBreakout ? candle.low : candle.high;
        const direction = isLongBreakout ? 'LONG' : 'SHORT';
        const cappedSL = this.calculateCappedStopLoss(entryPrice, naturalSL, direction);
        const markingCandle = {
            candle: candle,
            entryPrice: entryPrice,
            stopLoss: cappedSL,
            updateCount: 0,
            detectedAt: new Date()
        };
        return markingCandle;
    }
    checkForMarkingCandleUpdate(candle) {
        const currentMarking = this.strategyState.markingCandleState.currentMarkingCandle;
        const breakoutRef = this.strategyState.markingCandleState.breakoutReference;
        if (!currentMarking || !breakoutRef)
            return null;
        const isLongBreakout = breakoutRef.type === 'long_breakout';
        const currentSL = currentMarking.stopLoss;
        let newSL;
        let slExtended;
        if (isLongBreakout) {
            newSL = candle.low;
            slExtended = (currentSL - newSL) >= 1;
        }
        else {
            newSL = candle.high;
            slExtended = (newSL - currentSL) >= 1;
        }
        if (!slExtended) {
            return null;
        }
        const entryPrice = isLongBreakout ? candle.high : candle.low;
        const direction = isLongBreakout ? 'LONG' : 'SHORT';
        const cappedSL = this.calculateCappedStopLoss(entryPrice, newSL, direction);
        const updatedMarkingCandle = {
            candle: candle,
            entryPrice: entryPrice,
            stopLoss: cappedSL,
            updateCount: currentMarking.updateCount + 1,
            detectedAt: new Date()
        };
        return updatedMarkingCandle;
    }
    skipMarkingCandleTrade(reason) {
        this.logger.info(`🚫 Skipping marking candle trade - Reason: ${reason}`);
        this.logger.info(`🚫 MARKING CANDLE TRACKING DEACTIVATED - isActive: false`);
        this.strategyState.markingCandleState.tradeSkipped = true;
        this.strategyState.markingCandleState.isActive = false;
        this.strategyState.markingCandleState.searchPhase = 'expired';
        this.transitionToState(TradeState.WAITING_FOR_BREAKOUT, reason);
        this.logger.info(`📍 Pivot remains valid for future breakouts`);
    }
    logMarkingCandleDetails(markingCandle) {
        const breakoutType = this.strategyState.markingCandleState.breakoutReference?.type;
        this.logger.info(`   🕯️  Marking Candle: O:₹${markingCandle.candle.open.toFixed(2)} H:₹${markingCandle.candle.high.toFixed(2)} L:₹${markingCandle.candle.low.toFixed(2)} C:₹${markingCandle.candle.close.toFixed(2)}`);
        this.logger.info(`   🎯 Entry Price: ₹${markingCandle.entryPrice.toFixed(2)} | Stop Loss: ₹${markingCandle.stopLoss.toFixed(2)}`);
        this.logger.info(`   🔢 Update Count: ${markingCandle.updateCount} | Trade Type: ${breakoutType}`);
        this.logger.info(`   ⏰ Time: ${markingCandle.candle.timestamp.toLocaleString()}`);
    }
    getMarkingCandleState() {
        return this.strategyState.markingCandleState;
    }
    getTradeStateInfo() {
        const result = {
            tradeState: this.strategyState.tradeState
        };
        if (this.strategyState.tradeSetupRequest) {
            result.tradeSetupRequest = this.strategyState.tradeSetupRequest;
        }
        if (this.strategyState.currentTradeId) {
            result.currentTradeId = this.strategyState.currentTradeId;
        }
        return result;
    }
    getMarkingCandleDebugInfo() {
        const state = this.strategyState.markingCandleState;
        return {
            isActive: state.isActive,
            searchPhase: state.searchPhase,
            barsProcessedSinceBreakout: state.barsProcessedSinceBreakout,
            currentMarkingCandle: state.currentMarkingCandle ? {
                updateCount: state.currentMarkingCandle.updateCount,
                entryPrice: state.currentMarkingCandle.entryPrice,
                stopLoss: state.currentMarkingCandle.stopLoss,
                candleOHLC: {
                    open: state.currentMarkingCandle.candle.open,
                    high: state.currentMarkingCandle.candle.high,
                    low: state.currentMarkingCandle.candle.low,
                    close: state.currentMarkingCandle.candle.close
                },
                detectedAt: state.currentMarkingCandle.detectedAt
            } : null,
            breakoutReference: state.breakoutReference ? {
                type: state.breakoutReference.type,
                price: state.breakoutReference.price,
                timestamp: state.breakoutReference.timestamp
            } : null,
            timingInfo: {
                startTime: state.startTime,
                timeElapsed: state.startTime ? Math.floor((Date.now() - new Date(state.startTime).getTime()) / (1000 * 60)) : 0,
                timeLimit: 18,
                maxUpdatesReached: state.maxUpdatesReached,
                timeExpired: state.timeExpired,
                tradeSkipped: state.tradeSkipped
            }
        };
    }
    async testManualPriceFetch() {
        try {
            this.logger.info('🧪 Testing manual price fetch...');
            if (!this.strategyState.currentContract) {
                this.logger.error('❌ No contract available for testing');
                return;
            }
            await this.fetchAndProcessLivePrice();
            this.logger.info('✅ Manual price fetch test completed');
        }
        catch (error) {
            this.logger.error('❌ Error in manual price fetch test:', error);
        }
    }
    simulateDirectTestTick() {
        this.logger.info('🧪 Simulating test tick...');
    }
    getCurrentCapital() {
        return this.tradeExecutionService.getCurrentCapital();
    }
    getActivePosition() {
        return this.tradeExecutionService.getActivePosition();
    }
    getDetailedPosition() {
        return this.tradeExecutionService.getDetailedPosition();
    }
    getTradeHistory() {
        return this.tradeExecutionService.getTradeHistory();
    }
    getTradingConfig() {
        return this.tradeExecutionService.getTradingConfig();
    }
    getExecutionStatus() {
        return this.tradeExecutionService.getExecutionStatus();
    }
    updateTradingConfig(updates) {
        this.tradeExecutionService.updateTradingConfig(updates);
    }
    async initializeInstruments() {
        await this.tradeExecutionService.loadInstruments();
    }
    trackError(errorType, error, isCritical = false) {
        const now = new Date();
        const currentCount = this.errorCounts.get(errorType) || 0;
        this.errorCounts.set(errorType, currentCount + 1);
        this.lastErrorTime.set(errorType, now);
        this.healthStatus.consecutiveErrors += 1;
        if (isCritical) {
            this.healthStatus.criticalErrorsToday += 1;
            this.healthStatus.executionHealthy = false;
        }
        const errorContext = {
            errorType,
            count: currentCount + 1,
            isCritical,
            consecutiveErrors: this.healthStatus.consecutiveErrors,
            tradeState: this.strategyState.tradeState,
            hasPosition: !!this.strategyState.currentTradeId,
            marketDataAge: this.strategyState.lastUpdateTime ? new Date().getTime() - new Date(this.strategyState.lastUpdateTime).getTime() : 'unknown',
            timestamp: now.toISOString()
        };
        if (isCritical) {
            this.logger.error(`🚨 CRITICAL ERROR [${errorType}]: ${error?.message || error}`, errorContext);
        }
        else {
            this.logger.warn(`⚠️ ERROR [${errorType}]: ${error?.message || error}`, errorContext);
        }
        if (this.healthStatus.consecutiveErrors >= 5) {
            this.logger.error(`🔥 BREAKOUT STRATEGY HEALTH ALERT: ${this.healthStatus.consecutiveErrors} consecutive errors detected!`, {
                errorCounts: Object.fromEntries(this.errorCounts),
                healthStatus: this.healthStatus
            });
        }
    }
    resetErrorCount() {
        this.healthStatus.consecutiveErrors = 0;
        this.healthStatus.dataStreamHealthy = true;
        this.healthStatus.executionHealthy = true;
        this.healthStatus.lastHeartbeat = new Date();
    }
    getHealthReport() {
        const now = new Date();
        const timeSinceHeartbeat = now.getTime() - this.healthStatus.lastHeartbeat.getTime();
        return {
            overall: this.healthStatus.dataStreamHealthy && this.healthStatus.executionHealthy && timeSinceHeartbeat < 60000,
            dataStream: this.healthStatus.dataStreamHealthy,
            execution: this.healthStatus.executionHealthy,
            timeSinceHeartbeat: Math.floor(timeSinceHeartbeat / 1000),
            consecutiveErrors: this.healthStatus.consecutiveErrors,
            criticalErrorsToday: this.healthStatus.criticalErrorsToday,
            errorBreakdown: Object.fromEntries(this.errorCounts),
            tradeState: this.strategyState.tradeState,
            hasPosition: !!this.strategyState.currentTradeId,
            pivotHighPrice: this.strategyState.latestPivotHigh?.price || 'none',
            pivotLowPrice: this.strategyState.latestPivotLow?.price || 'none',
            candleCount: this.strategyState.candles.length,
            lastUpdate: now.toISOString()
        };
    }
    startHealthMonitoring() {
        if (this.healthMonitoringInterval)
            return;
        this.healthMonitoringInterval = setInterval(() => {
            this.healthStatus.lastHeartbeat = new Date();
            const healthReport = this.getHealthReport();
            if (!healthReport.overall) {
                this.logger.warn('💊 BREAKOUT STRATEGY HEALTH REPORT (UNHEALTHY):', healthReport);
            }
            else {
                this.logger.info('💚 Breakout strategy health: OK', {
                    consecutiveErrors: healthReport.consecutiveErrors,
                    timeSinceHeartbeat: healthReport.timeSinceHeartbeat,
                    tradeState: healthReport.tradeState,
                    candleCount: healthReport.candleCount
                });
            }
            const now = new Date();
            if (now.getHours() === 9 && now.getMinutes() === 15) {
                this.healthStatus.criticalErrorsToday = 0;
                this.errorCounts.clear();
                this.logger.info('🔄 Daily error counts reset for breakout strategy');
            }
        }, 5 * 60 * 1000);
    }
    stopHealthMonitoring() {
        if (this.healthMonitoringInterval) {
            clearInterval(this.healthMonitoringInterval);
            this.healthMonitoringInterval = null;
        }
    }
}
exports.BreakoutPullbackStrategy = BreakoutPullbackStrategy;
//# sourceMappingURL=BreakoutPullbackStrategy.js.map