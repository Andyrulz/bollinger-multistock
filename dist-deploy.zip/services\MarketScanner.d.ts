import { Logger } from "../utils/Logger";
import { InstrumentCache } from "../utils/InstrumentCache";
import { OIHistoryService } from "./OIHistoryService";
export interface TacticalBonus {
    freshBreakout: number;
    rvolSurge: number;
    proximity: number;
    rsiAccel: number;
    squeeze: number;
    gammaWall: number;
    runwayTier?: 'VACUUM' | 'CLEAN' | 'PASSABLE' | 'CONGESTED' | 'NO_WALL';
    runwayRatio?: number;
    total: number;
}
export interface ScoredStock {
    symbol: string;
    score: number;
    baseScore: number;
    bias: "LONG" | "SHORT";
    sector: string;
    sectorToken: number;
    breakdown: {
        trend: number;
        momentum: number;
        volume: number;
        sector: number;
        smartMoney: number;
    };
    tacticalBonus: TacticalBonus;
    smartMoneySignal?: 'ACCUMULATION' | 'DISTRIBUTION' | 'SHORT_COVERING' | 'LONG_UNWINDING' | 'NONE' | 'CONFLICT' | 'EXPIRY_WEEK';
    spotPrice: number;
    upperCircuitLimit: number;
    lowerCircuitLimit: number;
    todayChangePercent: number;
    atmOption: {
        tradingsymbol: string;
        strike: number;
        premium: number;
        expiry: Date;
    } | null;
    historicalData: Candle[];
    valid: boolean;
    rejectionReason?: string;
}
export interface ScannerResult {
    scanTime: Date;
    scannedCount: number;
    qualifiedCount: number;
    selected: ScoredStock[];
    allScored: ScoredStock[];
    greenSectors: string[];
    redSectors: string[];
    flatSectors: string[];
    failedStocks: string[];
}
interface Candle {
    date: Date;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
}
export declare class MarketScanner {
    private kiteConnect;
    private logger;
    private instrumentCache;
    private config;
    private universe;
    private cachedHistoricalData;
    private isDataCached;
    private lastScannerRun;
    private SCANNER_COOLDOWN_MS;
    private oiHistoryService;
    constructor(kiteConnect: any, logger: Logger, instrumentCache: InstrumentCache, config: {
        minScore: number;
        topCount: number;
        minPremium: number;
        sectorChangeThreshold: {
            green: number;
            red: number;
        };
    });
    setOIHistoryService(service: OIHistoryService): void;
    scanUniverse(): Promise<ScannerResult>;
    cacheHistoricalData(): Promise<{
        success: boolean;
        count: number;
    }>;
    isReady(): boolean;
    clearCache(): void;
    private analyzeSectors;
    private filterBySector;
    private scoreStocks;
    private applySafetyFilters;
    private selectTopStocks;
    private findATMOption;
    private getCurrentMonthLastTuesday;
    private getActualNearestExpiry;
    private isStockTradingBlocked;
    private findClosestStrike;
    private derive15MinCandles;
    private derive60MinCandles;
    private calculateEMA;
    private calculateRSI;
    private calculateTacticalBonus;
    private calculateADX;
    private calculateVWAP;
    private calculateRVOL;
    private calculateSupertrend;
    private calculateBollingerBands;
    private emptyResult;
}
export {};
//# sourceMappingURL=MarketScanner.d.ts.map