"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StrategyManager = exports.DEFAULT_EXPERIMENTAL_FLAGS = void 0;
const StrategyRegistry_1 = require("./StrategyRegistry");
const InstrumentCache_1 = require("../utils/InstrumentCache");
const MarketScanner_1 = require("../services/MarketScanner");
const OIHistoryService_1 = require("../services/OIHistoryService");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.DEFAULT_EXPERIMENTAL_FLAGS = {
    enableShortEntries: true,
    enablePremiumHardStop: true,
    enableRsiConfirmationExit: true,
    enableSameSlotPostLossLockout: false,
    lunchBlockEndMinutesIst: 750,
    enableBreakoutNoFollowThroughExit: true,
    enableExtendedGapTrap: true,
    enableStaleBreakoutFilter: true,
    enableWideRangeDayFilter: true,
    enableExtremeNiftyRangeFilter: true,
    enableVixLotReduction: true,
    minHoldingTimeMinutes: 0,
    scannerKillSwitch: { enabled: false, maxConsecutiveLossesPerDay: 4 },
    enablePullbackEntry: false,
    pullbackSlots: [],
    pullbackArmTimeoutCandles: 4,
    pullbackConfirmTimeoutCandles: 2,
    pullbackAbandonOnExtensionPct: 0.015,
    pullbackLongRsiThreshold: 60,
    pullbackShortRsiThreshold: 40,
    pullbackLongConfirmRsiThreshold: 60,
    pullbackShortConfirmRsiThreshold: 40,
    useStructuralStockStop: true,
    structuralStopBufferPct: 0.0005,
    liquidityOiMultiplier: 500,
    liquidityMinVolFallback: 500,
    enableFvgEntry: false,
    fvgSlots: [],
    fvgMinGapPct: 0.0015,
    fvgMaxScanCandles: 8,
    fvgMaxLifeCandles: 48,
    fvgInvalidateOnFloorClose: true,
    enableFvgLookback: false,
    fvgLookbackCandles: 5,
    enableFvgUpgrade: false,
    fvgRequireTrendAtEntry: false,
    fvgInvalidateOnTrendFlip: false,
    enableIncrementalScannerCandles: false,
    enableSessionVwap: false,
};
class StrategyManager {
    constructor(kiteConnect, authService, logger, quoteManager, config) {
        this.isInitialized = false;
        this.preMarketCheckInterval = null;
        this.needsPreMarketFetch = false;
        this.isDataCached = false;
        this.hasScannerRunToday = false;
        this.lastScannerDate = '';
        this.symbolCooldownMap = new Map();
        this.SYMBOL_COOLDOWN_MS = 30 * 60 * 1000;
        this.symbolsTradedToday = new Map();
        this.lastTradeDateReset = '';
        this.experimentalFlags = exports.DEFAULT_EXPERIMENTAL_FLAGS;
        this.slotsLockedToday = new Set();
        this.dailyLossStreak = 0;
        this.dailyLossStreakDate = '';
        this.slotStates = [
            { slotNumber: 0, symbol: null, strategyId: null, deployedAt: null, lastScanScore: null, lastScanBias: null, locked: false, lastRetentionDecision: null, lastRetentionReason: null },
            { slotNumber: 1, symbol: null, strategyId: null, deployedAt: null, lastScanScore: null, lastScanBias: null, locked: false, lastRetentionDecision: null, lastRetentionReason: null },
            { slotNumber: 2, symbol: null, strategyId: null, deployedAt: null, lastScanScore: null, lastScanBias: null, locked: false, lastRetentionDecision: null, lastRetentionReason: null },
        ];
        this.smartRetentionConfig = {
            enabled: true,
            scanTimes: [
                '09:23', '09:28', '09:33', '09:38', '09:43', '09:48', '09:53', '09:58',
                '10:03', '10:08', '10:13', '10:18', '10:23', '10:28', '10:33', '10:38', '10:43', '10:48', '10:53', '10:58',
                '11:03', '11:08', '11:13', '11:18', '11:23', '11:28', '11:33', '11:38', '11:43', '11:48', '11:53', '11:58',
                '12:03', '12:08', '12:13', '12:18', '12:23', '12:28', '12:33', '12:38', '12:43', '12:48', '12:53', '12:58',
                '13:03', '13:08', '13:13', '13:18', '13:23', '13:28', '13:33', '13:38', '13:43', '13:48', '13:53', '13:58',
                '14:03', '14:08', '14:13', '14:18', '14:23', '14:28', '14:33', '14:38', '14:43', '14:48', '14:53', '14:58'
            ],
            keepThreshold: 6.0,
            minDeployScore: 7.0,
            lockOnActivePosition: true,
            swapOnBiasFlip: true,
            lastScanCutoff: '14:58',
            minDeploymentAgeMinutes: 10,
        };
        this.nextScanTimer = null;
        this.isScanInProgress = false;
        this.oiHistoryService = null;
        this.eodOISaverTimer = null;
        this.lastScannerResults = null;
        this.kiteConnect = kiteConnect;
        this.authService = authService;
        this.logger = logger;
        this.quoteManager = quoteManager;
        this.config = config;
        StrategyManager.instance = this;
        this.instrumentCache = new InstrumentCache_1.InstrumentCache(this.kiteConnect, this.logger);
        this.marketScanner = new MarketScanner_1.MarketScanner(this.kiteConnect, this.logger, this.instrumentCache, {
            minScore: 7.0,
            topCount: 3,
            minPremium: 40,
            sectorChangeThreshold: { green: 0.25, red: -0.25 },
        });
    }
    async initialize() {
        if (this.isInitialized) {
            this.logger.warn('⚠️ StrategyManager already initialized');
            return;
        }
        try {
            this.logger.info('🚀 Initializing Strategy Manager...');
            StrategyRegistry_1.StrategyRegistry.initialize(this.logger);
            await this.registerStrategies();
            await this.restoreSlotStatesFromDisk();
            await this.restoreLockedSlotStrategies();
            await this.loadStrategyConfigs();
            this.startHealthMonitoring();
            this.schedulePreMarketCheck();
            this.scheduleHourlyScanner();
            if (this.experimentalFlags.enableIncrementalScannerCandles) {
                this.marketScanner.startCandlePolling(45000, () => this.isMarketOpenNow());
                this.logger.info('🕯️ IMP-001 incremental scanner candles ENABLED (seed-once + quote append)');
            }
            this.marketScanner.setSessionVwap(this.experimentalFlags.enableSessionVwap);
            await this.initializeOIHistoryService();
            this.populateSymbolsTradedTodayFromDisk();
            this.isInitialized = true;
            this.logger.info('✅ Strategy Manager initialized successfully');
        }
        catch (error) {
            this.logger.error('❌ Failed to initialize Strategy Manager:', error);
            throw error;
        }
    }
    async restoreSlotStatesFromDisk() {
        this.logger.info('🔄 Restoring slot states from disk...');
        const dataDir = path_1.default.join(__dirname, '..', 'data');
        let restoredCount = 0;
        let activePositionsFound = 0;
        for (let slotIndex = 0; slotIndex < 3; slotIndex++) {
            const slotNumber = slotIndex + 1;
            const slotDataFile = path_1.default.join(dataDir, `bollinger-slot${slotNumber}.json`);
            try {
                if (!fs_1.default.existsSync(slotDataFile)) {
                    this.logger.info(`   Slot ${slotNumber}: No data file found`);
                    continue;
                }
                const rawData = fs_1.default.readFileSync(slotDataFile, 'utf8');
                const slotData = JSON.parse(rawData);
                if (slotData.activePosition && slotData.activePosition !== null) {
                    const position = slotData.activePosition;
                    const tradingsymbol = position.instrument?.tradingsymbol || '';
                    const instrumentName = position.instrument?.name || '';
                    const extractedSymbol = tradingsymbol.match(/^([A-Z][A-Z&-]*)/)?.[1];
                    const symbol = instrumentName || extractedSymbol || position.underlying || 'UNKNOWN';
                    const direction = position.type === 'LONG' ? 'LONG' : 'SHORT';
                    this.logger.info(`   🔒 Slot ${slotNumber}: ACTIVE POSITION FOUND - ${symbol}`);
                    this.logger.info(`      Position: ${direction} | Entry: ₹${position.entryPrice} | Option: ${tradingsymbol}`);
                    const sanitizedSymbol = symbol.toLowerCase().replace(/&/g, '_and_');
                    this.slotStates[slotIndex] = {
                        slotNumber: slotIndex,
                        symbol: symbol,
                        strategyId: `bollinger-slot${slotNumber}-${sanitizedSymbol}`,
                        deployedAt: position.entryTime ? new Date(position.entryTime) : new Date(),
                        lastScanScore: null,
                        lastScanBias: direction,
                        locked: true,
                        lastRetentionDecision: 'LOCK',
                        lastRetentionReason: 'Active position restored from persisted data',
                    };
                    activePositionsFound++;
                    restoredCount++;
                    this.logger.info(`      ✅ Slot ${slotNumber} LOCKED - Scanner will NOT overwrite this position`);
                }
                else if (slotData.symbol) {
                    this.logger.info(`   📦 Slot ${slotNumber}: Previously deployed to ${slotData.symbol} (no active position)`);
                    restoredCount++;
                }
                else {
                    this.logger.info(`   📭 Slot ${slotNumber}: Empty (no active position)`);
                }
            }
            catch (error) {
                this.logger.warn(`   ⚠️ Slot ${slotNumber}: Failed to read data file - ${error}`);
            }
        }
        if (activePositionsFound > 0) {
            this.logger.info(`\n🔐 POSITION PROTECTION ENABLED:`);
            this.logger.info(`   ${activePositionsFound} active position(s) found and LOCKED`);
            this.logger.info(`   Scanner will skip these slots to prevent orphaning positions`);
        }
        else {
            this.logger.info(`   No active positions found in slot data files`);
        }
        this.logger.info(`✅ Slot state restoration complete (${restoredCount} slots processed)`);
    }
    async restoreLockedSlotStrategies() {
        const lockedSlots = this.slotStates.filter(s => s.locked && s.symbol);
        if (lockedSlots.length === 0) {
            this.logger.info('📭 No locked slots to restore');
            return;
        }
        this.logger.info(`\n🔧 RESTORING ${lockedSlots.length} LOCKED SLOT STRATEGIES...`);
        for (const slotState of lockedSlots) {
            const slotIndex = slotState.slotNumber;
            const slotNumber = slotIndex + 1;
            this.logger.info(`   📍 Slot ${slotNumber}: Restoring ${slotState.symbol}...`);
            const existingStrategy = StrategyRegistry_1.StrategyRegistry.getInstance(slotState.strategyId);
            if (existingStrategy && existingStrategy.isRunning()) {
                this.logger.info(`   ✅ Strategy ${slotState.strategyId} already running`);
                continue;
            }
            if (existingStrategy && !existingStrategy.isRunning()) {
                this.logger.warn(`   ⚠️ Strategy ${slotState.strategyId} exists but STOPPED - removing zombie and restoring...`);
                StrategyRegistry_1.StrategyRegistry.removeInstance(slotState.strategyId);
            }
            const restored = await this.restoreStrategyFromSlotData(slotIndex, slotState);
            if (restored) {
                this.logger.info(`   ✅ Slot ${slotNumber}: ${slotState.symbol} strategy restored and monitoring position`);
            }
            else {
                this.logger.error(`   ❌ CRITICAL: Slot ${slotNumber}: Failed to restore ${slotState.symbol} strategy!`);
                this.logger.error(`   ⚠️ Position may be ORPHANED - manual intervention required!`);
            }
        }
        this.logger.info(`✅ Locked slot restoration complete\n`);
    }
    async restoreStrategyFromSlotData(slotIndex, slotState) {
        const slotNumber = slotIndex + 1;
        const dataDir = path_1.default.join(__dirname, '..', 'data');
        const slotDataFile = path_1.default.join(dataDir, `bollinger-slot${slotNumber}.json`);
        try {
            if (!fs_1.default.existsSync(slotDataFile)) {
                this.logger.error(`   ❌ Slot data file not found: ${slotDataFile}`);
                return false;
            }
            const rawData = fs_1.default.readFileSync(slotDataFile, 'utf8');
            const slotData = JSON.parse(rawData);
            if (!slotData.activePosition) {
                this.logger.error(`   ❌ No active position in slot data - cannot restore`);
                return false;
            }
            const position = slotData.activePosition;
            const symbol = slotState.symbol || position.underlying || 'UNKNOWN';
            this.logger.info(`   🔧 Restoring strategy for ${symbol} from slot data...`);
            const sanitizedSymbol = symbol.toLowerCase().replace(/&/g, '_and_');
            const config = {
                id: slotState.strategyId || `bollinger-slot${slotNumber}-${sanitizedSymbol}`,
                name: `Bollinger Band - ${symbol} (RESTORED)`,
                enabled: true,
                description: `Restored from active position on restart`,
                timeframe: '5min',
                instruments: [symbol],
                riskPerTrade: 0.8,
                maxPositions: 1,
                config: {
                    period: 20,
                    stdDev: 2.0,
                    restoreFromPosition: true,
                    restoredPositionData: position,
                    capitalAllocation: slotData.capital || 65000,
                    strategyIndex: slotIndex,
                },
            };
            const strategy = await StrategyRegistry_1.StrategyRegistry.createInstance('bollinger-band', this.kiteConnect, this.logger, this.quoteManager, this.instrumentCache, config);
            if (strategy.isInitialized) {
                await strategy.start();
                this.logger.info(`   ✅ Strategy ${config.id} restored and started`);
            }
            else {
                this.logger.info(`   ⏸️ Strategy ${config.id} registered - will initialize and start after authentication`);
            }
            return true;
        }
        catch (error) {
            this.logger.error(`   ❌ Failed to restore strategy from slot data:`, error);
            return false;
        }
    }
    async registerStrategies() {
        this.logger.info('📋 Registering strategy classes...');
        try {
            const { BollingerBandStrategy } = await Promise.resolve().then(() => __importStar(require('../strategies/bollinger-band/BollingerBandStrategy')));
            StrategyRegistry_1.StrategyRegistry.registerStrategy('bollinger-band', BollingerBandStrategy);
            this.logger.info(`✅ Registered ${StrategyRegistry_1.StrategyRegistry.getRegisteredStrategies().length} strategy classes`);
        }
        catch (error) {
            this.logger.error('❌ Failed to register strategies:', error);
            throw error;
        }
    }
    async loadStrategyConfigs() {
        this.logger.info(`📄 Loading strategy configurations from: ${this.config.configPath}`);
        try {
            if (!fs_1.default.existsSync(this.config.configPath)) {
                this.logger.warn('⚠️ Strategy config file not found, creating default configuration');
                await this.createDefaultConfig();
            }
            const configData = fs_1.default.readFileSync(this.config.configPath, 'utf8');
            const configs = JSON.parse(configData);
            const expFromJson = configs?.global?.experimental || {};
            this.experimentalFlags = {
                ...exports.DEFAULT_EXPERIMENTAL_FLAGS,
                ...expFromJson,
                scannerKillSwitch: {
                    ...exports.DEFAULT_EXPERIMENTAL_FLAGS.scannerKillSwitch,
                    ...(expFromJson.scannerKillSwitch || {}),
                },
            };
            this.logger.info('🧪 Experimental flags loaded', {
                shortEntries: this.experimentalFlags.enableShortEntries,
                premiumHardStop: this.experimentalFlags.enablePremiumHardStop,
                rsiConfirmationExit: this.experimentalFlags.enableRsiConfirmationExit,
                slotLockoutAfterLoss: this.experimentalFlags.enableSameSlotPostLossLockout,
                lunchBlockEndMinutesIst: this.experimentalFlags.lunchBlockEndMinutesIst,
                minHoldingTimeMinutes: this.experimentalFlags.minHoldingTimeMinutes,
                killSwitch: this.experimentalFlags.scannerKillSwitch,
            });
            for (const strategyConfig of configs.strategies) {
                if (strategyConfig.enabled) {
                    await this.createStrategyInstance(strategyConfig);
                }
                else {
                    this.logger.info(`⏸️ Strategy disabled: ${strategyConfig.name}`);
                }
            }
            this.logger.info(`✅ Loaded ${StrategyRegistry_1.StrategyRegistry.getActiveInstances().length} strategy configurations`);
        }
        catch (error) {
            this.logger.error('❌ Failed to load strategy configurations:', error);
            throw error;
        }
    }
    async createStrategyInstance(config) {
        try {
            const strategyClass = config.id.replace(/-\d+$/, '');
            await StrategyRegistry_1.StrategyRegistry.createInstance(strategyClass, this.kiteConnect, this.logger, this.quoteManager, this.instrumentCache, config);
            if (this.config.autoStart) {
                const instance = StrategyRegistry_1.StrategyRegistry.getInstance(config.id);
                if (instance && instance.isEnabled()) {
                    this.logger.info(`⏳ Strategy ready for manual start: ${config.name}`);
                }
            }
        }
        catch (error) {
            this.logger.error(`❌ Failed to create strategy instance ${config.id}:`, error);
        }
    }
    async startStrategy(strategyId) {
        const instance = StrategyRegistry_1.StrategyRegistry.getInstance(strategyId);
        if (!instance) {
            this.logger.error(`❌ Strategy not found: ${strategyId}`);
            return false;
        }
        try {
            await instance.start();
            this.logger.info(`🚀 Started strategy: ${instance.getName()}`);
            return true;
        }
        catch (error) {
            this.logger.error(`❌ Failed to start strategy ${strategyId}:`, error);
            return false;
        }
    }
    async stopStrategy(strategyId) {
        const instance = StrategyRegistry_1.StrategyRegistry.getInstance(strategyId);
        if (!instance) {
            this.logger.error(`❌ Strategy not found: ${strategyId}`);
            return false;
        }
        try {
            await instance.stop();
            this.logger.info(`⏹️ Stopped strategy: ${instance.getName()}`);
            return true;
        }
        catch (error) {
            this.logger.error(`❌ Failed to stop strategy ${strategyId}:`, error);
            return false;
        }
    }
    async startAllStrategies() {
        const instances = StrategyRegistry_1.StrategyRegistry.getAllInstances();
        for (const [id, instance] of instances) {
            if (instance.isEnabled() && !instance.isRunning()) {
                await this.startStrategy(id);
            }
        }
    }
    async stopAllStrategies() {
        const instances = StrategyRegistry_1.StrategyRegistry.getAllInstances();
        for (const [id, instance] of instances) {
            if (instance.isRunning()) {
                await this.stopStrategy(id);
            }
        }
    }
    getStrategyStatus(strategyId) {
        const instance = StrategyRegistry_1.StrategyRegistry.getInstance(strategyId);
        return instance ? instance.getStatus() : null;
    }
    getAllStrategyStatuses() {
        const statuses = new Map();
        const instances = StrategyRegistry_1.StrategyRegistry.getAllInstances();
        for (const [id, instance] of instances) {
            statuses.set(id, instance.getStatus());
        }
        return statuses;
    }
    getGlobalMetrics() {
        const instances = StrategyRegistry_1.StrategyRegistry.getAllInstances();
        let totalProfitLoss = 0;
        let totalTrades = 0;
        let activeStrategies = 0;
        let hasErrors = false;
        let hasWarnings = false;
        for (const [, instance] of instances) {
            const metrics = instance.getMetrics();
            totalProfitLoss += metrics.profitLoss;
            totalTrades += metrics.totalTrades;
            if (metrics.isActive) {
                activeStrategies++;
            }
            if (metrics.healthStatus === 'error') {
                hasErrors = true;
            }
            else if (metrics.healthStatus === 'warning') {
                hasWarnings = true;
            }
        }
        const systemHealth = hasErrors ? 'error' : hasWarnings ? 'warning' : 'healthy';
        return {
            totalStrategies: instances.size,
            activeStrategies,
            totalProfitLoss,
            totalTrades,
            systemHealth
        };
    }
    async createDefaultConfig() {
        const defaultConfig = {
            strategies: [
                {
                    id: "bollinger-band-01",
                    name: "5m option Buy: bollinger band entry and trail",
                    enabled: true,
                    description: "Bollinger Band strategy with trailing stop",
                    timeframe: "5min",
                    instruments: ["NIFTY", "BANKNIFTY"],
                    riskPerTrade: 0.8,
                    maxPositions: 2,
                    config: {
                        period: 20,
                        stdDev: 2.0,
                        trailType: "percentage",
                        trailValue: 1.5,
                        riskReward: {
                            stopLoss: 2.0,
                            target: 4.0
                        },
                        positionSizing: {
                            riskAmount: 10000,
                            riskPercentage: 2.0
                        }
                    }
                }
            ],
            global: {
                autoStart: true,
                healthCheckInterval: 30000,
                logging: {
                    level: "info",
                    separateFiles: true
                },
                riskManagement: {
                    maxDailyLoss: 50000,
                    maxDrawdown: 100000,
                    emergencyStop: true
                }
            }
        };
        const configDir = path_1.default.dirname(this.config.configPath);
        if (!fs_1.default.existsSync(configDir)) {
            fs_1.default.mkdirSync(configDir, { recursive: true });
        }
        fs_1.default.writeFileSync(this.config.configPath, JSON.stringify(defaultConfig, null, 2));
        this.logger.info('✅ Created default strategy configuration file');
    }
    startHealthMonitoring() {
        if (this.healthCheckTimer) {
            clearInterval(this.healthCheckTimer);
        }
        this.healthCheckTimer = setInterval(async () => {
            try {
                await this.performHealthCheck();
            }
            catch (error) {
                this.logger.error('❌ Health check failed:', error);
            }
        }, this.config.healthCheckInterval);
        this.logger.info(`💓 Started health monitoring (interval: ${this.config.healthCheckInterval}ms)`);
    }
    async performHealthCheck() {
        const instances = StrategyRegistry_1.StrategyRegistry.getAllInstances();
        for (const [id, instance] of instances) {
            try {
                const metrics = instance.getMetrics();
                const timeSinceUpdate = Date.now() - metrics.lastUpdateTime.getTime();
                let threshold = 60000;
                const strategyName = instance.getName().toLowerCase();
                if (strategyName.includes('bollinger') || strategyName.includes('5m')) {
                    threshold = 360000;
                }
                if (timeSinceUpdate > threshold && instance.isRunning()) {
                    this.logger.warn(`⚠️ Strategy ${instance.getName()} may be unresponsive (${Math.round(timeSinceUpdate / 1000)}s since last update, threshold: ${threshold / 1000}s)`);
                }
            }
            catch (error) {
                this.logger.error(`❌ Health check failed for strategy ${id}:`, error);
            }
        }
    }
    isSymbolInCooldown(symbol) {
        this.checkDailyReset();
        const tradedTodayAt = this.symbolsTradedToday.get(symbol);
        if (tradedTodayAt) {
            this.logger.info(`🚫 Symbol ${symbol} blocked — already traded today at ${tradedTodayAt.toLocaleTimeString()} (same-day re-entry block)`);
            return true;
        }
        const lastExitTime = this.symbolCooldownMap.get(symbol);
        if (!lastExitTime)
            return false;
        const timeSinceExit = Date.now() - lastExitTime.getTime();
        const isInCooldown = timeSinceExit < this.SYMBOL_COOLDOWN_MS;
        if (isInCooldown) {
            const remainingMs = this.SYMBOL_COOLDOWN_MS - timeSinceExit;
            const remainingMin = Math.ceil(remainingMs / 60000);
            this.logger.info(`⏳ Symbol ${symbol} in cooldown: ${remainingMin}m remaining`);
        }
        return isInCooldown;
    }
    recordSymbolExit(symbol) {
        const exitTime = new Date();
        this.symbolCooldownMap.set(symbol, exitTime);
        this.symbolsTradedToday.set(symbol, exitTime);
        this.logger.info(`🔒 Symbol cooldown started: ${symbol} (30 min cooldown + same-day re-entry block until EOD)`);
    }
    getSymbolCooldownRemaining(symbol) {
        const lastExitTime = this.symbolCooldownMap.get(symbol);
        if (!lastExitTime)
            return 0;
        const timeSinceExit = Date.now() - lastExitTime.getTime();
        const remainingMs = this.SYMBOL_COOLDOWN_MS - timeSinceExit;
        return remainingMs > 0 ? Math.ceil(remainingMs / 60000) : 0;
    }
    static recordSymbolExitStatic(symbol) {
        if (StrategyManager.instance) {
            StrategyManager.instance.recordSymbolExit(symbol);
        }
        else {
            console.warn(`⚠️ StrategyManager not initialized - cannot record cooldown for ${symbol}`);
        }
    }
    static isSymbolInCooldownStatic(symbol) {
        if (StrategyManager.instance) {
            return StrategyManager.instance.isSymbolInCooldown(symbol);
        }
        return false;
    }
    static getExperimentalFlags() {
        if (StrategyManager.instance) {
            return StrategyManager.instance.experimentalFlags;
        }
        return exports.DEFAULT_EXPERIMENTAL_FLAGS;
    }
    checkDailyReset() {
        const todayStr = new Date().toISOString().slice(0, 10);
        if (this.lastTradeDateReset !== todayStr) {
            if (this.symbolsTradedToday.size > 0 || this.slotsLockedToday.size > 0) {
                this.logger.info(`🔄 New trading day — clearing same-day state from ${this.lastTradeDateReset}`, {
                    symbolsCleared: this.symbolsTradedToday.size,
                    slotsCleared: this.slotsLockedToday.size,
                });
            }
            this.symbolsTradedToday.clear();
            this.slotsLockedToday.clear();
            this.lastTradeDateReset = todayStr;
        }
        if (this.dailyLossStreakDate !== todayStr) {
            this.dailyLossStreak = 0;
            this.dailyLossStreakDate = todayStr;
        }
    }
    recordSlotLoss(slotIndex) {
        if (!this.experimentalFlags.enableSameSlotPostLossLockout)
            return;
        this.checkDailyReset();
        this.slotsLockedToday.add(slotIndex);
        this.logger.info(`🔒 Slot ${slotIndex + 1} locked for rest of day (had losing trade)`);
    }
    isSlotLockedToday(slotIndex) {
        if (!this.experimentalFlags.enableSameSlotPostLossLockout)
            return false;
        this.checkDailyReset();
        return this.slotsLockedToday.has(slotIndex);
    }
    static recordSlotLossStatic(slotIndex) {
        if (StrategyManager.instance) {
            StrategyManager.instance.recordSlotLoss(slotIndex);
        }
    }
    static isSlotLockedTodayStatic(slotIndex) {
        if (StrategyManager.instance) {
            return StrategyManager.instance.isSlotLockedToday(slotIndex);
        }
        return false;
    }
    recordTradeOutcome(pnl) {
        this.checkDailyReset();
        if (pnl > 0) {
            if (this.dailyLossStreak > 0) {
                this.logger.info(`✅ Daily loss streak broken (was ${this.dailyLossStreak}, reset to 0)`);
            }
            this.dailyLossStreak = 0;
        }
        else {
            this.dailyLossStreak++;
            const limit = this.experimentalFlags.scannerKillSwitch.maxConsecutiveLossesPerDay;
            if (this.experimentalFlags.scannerKillSwitch.enabled && this.dailyLossStreak >= limit) {
                this.logger.warn(`🛑 KILL SWITCH ACTIVATED: ${this.dailyLossStreak} consecutive losses today — blocking new entries for rest of day`);
            }
            else {
                this.logger.info(`📉 Daily loss streak: ${this.dailyLossStreak} (limit ${limit})`);
            }
        }
    }
    isKillSwitchActive() {
        if (!this.experimentalFlags.scannerKillSwitch.enabled)
            return false;
        this.checkDailyReset();
        return this.dailyLossStreak >= this.experimentalFlags.scannerKillSwitch.maxConsecutiveLossesPerDay;
    }
    static isKillSwitchActiveStatic() {
        if (StrategyManager.instance) {
            return StrategyManager.instance.isKillSwitchActive();
        }
        return false;
    }
    static recordTradeOutcomeStatic(pnl) {
        if (StrategyManager.instance) {
            StrategyManager.instance.recordTradeOutcome(pnl);
        }
    }
    clearSymbolCooldowns() {
        const count = this.symbolCooldownMap.size;
        this.symbolCooldownMap.clear();
        if (count > 0) {
            this.logger.info(`🧹 Cleared ${count} symbol cooldowns`);
        }
    }
    populateSymbolsTradedTodayFromDisk() {
        const todayStr = new Date().toISOString().slice(0, 10);
        this.lastTradeDateReset = todayStr;
        this.dailyLossStreakDate = todayStr;
        const dataDir = path_1.default.join(__dirname, '..', 'data');
        let symbolsFound = 0;
        const todayTradesAcrossSlots = [];
        for (let slotNumber = 1; slotNumber <= 3; slotNumber++) {
            const slotDataFile = path_1.default.join(dataDir, `bollinger-slot${slotNumber}.json`);
            const slotIndex = slotNumber - 1;
            try {
                if (!fs_1.default.existsSync(slotDataFile))
                    continue;
                const rawData = fs_1.default.readFileSync(slotDataFile, 'utf8');
                const slotData = JSON.parse(rawData);
                const tradeHistory = slotData.tradeHistory || [];
                for (const trade of tradeHistory) {
                    if (!trade.exitTime || !trade.instrument?.name)
                        continue;
                    const exitDate = new Date(trade.exitTime).toISOString().slice(0, 10);
                    if (exitDate !== todayStr)
                        continue;
                    const symbol = trade.instrument.name;
                    if (!this.symbolsTradedToday.has(symbol)) {
                        this.symbolsTradedToday.set(symbol, new Date(trade.exitTime));
                        symbolsFound++;
                    }
                    if (this.experimentalFlags.enableSameSlotPostLossLockout && typeof trade.pnl === 'number' && trade.pnl < 0) {
                        this.slotsLockedToday.add(slotIndex);
                    }
                    todayTradesAcrossSlots.push({
                        slot: slotIndex,
                        exitTime: new Date(trade.exitTime),
                        pnl: typeof trade.pnl === 'number' ? trade.pnl : 0,
                    });
                }
            }
            catch (error) {
                this.logger.warn(`⚠️ Failed to read slot ${slotNumber} for same-day tracking:`, error);
            }
        }
        todayTradesAcrossSlots.sort((a, b) => a.exitTime.getTime() - b.exitTime.getTime());
        let streak = 0;
        for (const t of todayTradesAcrossSlots) {
            if (t.pnl > 0)
                streak = 0;
            else
                streak++;
        }
        this.dailyLossStreak = streak;
        if (symbolsFound > 0) {
            const symbols = [...this.symbolsTradedToday.keys()].join(', ');
            this.logger.info(`🔄 Restored ${symbolsFound} same-day re-entry blocks from disk: ${symbols}`);
        }
        else {
            this.logger.info('🔄 No same-day trades found on disk (clean start or new day)');
        }
        if (this.slotsLockedToday.size > 0) {
            this.logger.info(`🔄 Restored slot lockouts: slots=${[...this.slotsLockedToday].map(i => i + 1).join(',')}`);
        }
        if (this.dailyLossStreak > 0) {
            this.logger.info(`🔄 Restored daily loss streak: ${this.dailyLossStreak} (kill-switch limit ${this.experimentalFlags.scannerKillSwitch.maxConsecutiveLossesPerDay})`);
        }
    }
    async shutdown() {
        this.logger.info('🔄 Shutting down Strategy Manager...');
        if (this.healthCheckTimer) {
            clearInterval(this.healthCheckTimer);
        }
        if (this.nextScanTimer) {
            clearTimeout(this.nextScanTimer);
            this.nextScanTimer = null;
        }
        await this.stopAllStrategies();
        this.logger.info('✅ Strategy Manager shutdown complete');
    }
    schedulePreMarketCheck() {
        this.logger.info('📅 Scheduling post-market cleanup timer');
        this.preMarketCheckInterval = setInterval(async () => {
            const now = new Date();
            const currentTime = now.getHours() * 60 + now.getMinutes();
            if (currentTime === 935) {
                this.logger.info('🧹 Post-market cleanup: Resetting state for next day');
                this.isDataCached = false;
                this.needsPreMarketFetch = false;
                this.hasScannerRunToday = false;
                this.lastScannerResults = null;
                this.marketScanner.clearCache();
                for (const slot of this.slotStates) {
                    slot.symbol = null;
                    slot.strategyId = null;
                    slot.deployedAt = null;
                    slot.lastScanScore = null;
                    slot.lastScanBias = null;
                    slot.locked = false;
                    slot.lastRetentionDecision = null;
                    slot.lastRetentionReason = null;
                }
                this.logger.info('🧹 Slot states reset for next trading day');
                this.clearSymbolCooldowns();
                if (global.gc) {
                    global.gc();
                }
            }
        }, 60000);
    }
    isMarketOpenNow() {
        const now = new Date();
        const istMin = now.getUTCHours() * 60 + now.getUTCMinutes() + 330;
        const istMinutes = istMin % (24 * 60);
        const dayShift = istMin >= 24 * 60 ? 1 : 0;
        const day = (now.getUTCDay() + dayShift) % 7;
        const isWeekday = day >= 1 && day <= 5;
        return isWeekday && istMinutes >= (9 * 60 + 15) && istMinutes <= (15 * 60 + 30);
    }
    async fetchPreMarketData() {
        try {
            this.logger.info('📊 Fetching pre-market historical data...');
            const result = await this.marketScanner.cacheHistoricalData();
            if (result.success) {
                this.isDataCached = true;
                this.logger.info(`✅ Pre-market data cached: ${result.count} stocks ready`);
            }
            else {
                this.isDataCached = false;
            }
        }
        catch (error) {
            this.logger.error('Failed to fetch pre-market data:', error);
            this.isDataCached = false;
        }
    }
    scheduleHourlyScanner() {
        this.logger.info('📅 Scheduling 5-min Smart Retention scanner');
        this.logger.info(`📅 Scan times: ${this.smartRetentionConfig.scanTimes.slice(0, 5).join(', ')}... (${this.smartRetentionConfig.scanTimes.length} total)`);
        this.scheduleNextScan();
        this.logger.info('✅ 5-min scanner scheduled');
    }
    getNextScanTime() {
        const now = new Date();
        const scanTimes = this.smartRetentionConfig.scanTimes;
        if (!scanTimes || scanTimes.length === 0) {
            return null;
        }
        for (const scanTime of scanTimes) {
            const parts = scanTime.split(':');
            if (parts.length < 2)
                continue;
            const hour = parseInt(parts[0], 10);
            const minute = parseInt(parts[1], 10);
            const scanDate = new Date();
            scanDate.setHours(hour, minute, 5, 0);
            if (scanDate > now) {
                return scanDate;
            }
        }
        const firstScan = scanTimes[0];
        const firstScanParts = firstScan.split(':');
        const hour = parseInt(firstScanParts[0], 10);
        const minute = parseInt(firstScanParts[1], 10);
        const tomorrowScan = new Date();
        tomorrowScan.setDate(tomorrowScan.getDate() + 1);
        tomorrowScan.setHours(hour, minute, 5, 0);
        return tomorrowScan;
    }
    scheduleNextScan() {
        if (this.nextScanTimer) {
            clearTimeout(this.nextScanTimer);
            this.nextScanTimer = null;
        }
        const nextScanTime = this.getNextScanTime();
        if (!nextScanTime) {
            this.logger.warn('⚠️ Could not calculate next scan time');
            return;
        }
        const now = new Date();
        const delay = nextScanTime.getTime() - now.getTime();
        const timeStr = nextScanTime.toLocaleTimeString('en-IN', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
        });
        const delayMinutes = Math.floor(delay / 60000);
        const delaySeconds = Math.floor((delay % 60000) / 1000);
        this.logger.info(`⏰ Next scan scheduled for ${timeStr} (in ${delayMinutes}m ${delaySeconds}s)`);
        this.nextScanTimer = setTimeout(() => {
            this.scheduledScanCallback();
        }, delay);
    }
    async scheduledScanCallback() {
        const now = new Date();
        const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
        if (currentTime > this.smartRetentionConfig.lastScanCutoff) {
            this.logger.info(`⏭️ Skipping scan at ${currentTime} - past cutoff (${this.smartRetentionConfig.lastScanCutoff})`);
            this.scheduleNextScan();
            return;
        }
        if (!await this.authService.isAuthenticatedAndValid()) {
            this.logger.warn(`⏭️ Skipping scan at ${currentTime} - not authenticated`);
            this.scheduleNextScan();
            return;
        }
        this.logger.info(`🕐 ${currentTime}:05: Triggering scheduled Smart Retention scan...`);
        await this.runHourlyScan();
        this.scheduleNextScan();
    }
    async initializeOIHistoryService() {
        this.logger.info('📊 Initializing OI History Service for Smart Money detection...');
        try {
            this.oiHistoryService = new OIHistoryService_1.OIHistoryService(this.kiteConnect, this.logger, this.instrumentCache);
            const loaded = await this.oiHistoryService.loadYesterdayOI();
            if (loaded) {
                this.logger.info('✅ OI History: Ready for Smart Money scoring');
            }
            else {
                this.logger.info('📭 OI History: No prior data - Smart Money scoring disabled until EOD save');
            }
            this.marketScanner.setOIHistoryService(this.oiHistoryService);
            this.scheduleEODOISaver();
        }
        catch (error) {
            this.logger.error('❌ Failed to initialize OI History Service:', error);
            this.oiHistoryService = null;
        }
    }
    scheduleEODOISaver() {
        this.logger.info('📅 Scheduling EOD OI Saver at 3:40 PM (weekdays only)');
        const scheduleNextEODSave = () => {
            const now = new Date();
            const targetHour = 15;
            const targetMinute = 40;
            const target = new Date(now);
            target.setHours(targetHour, targetMinute, 0, 0);
            if (now > target) {
                target.setDate(target.getDate() + 1);
            }
            const dayOfWeek = target.getDay();
            if (dayOfWeek === 6) {
                target.setDate(target.getDate() + 2);
                this.logger.info('📅 EOD OI Save: Skipping Saturday, scheduled for Monday');
            }
            else if (dayOfWeek === 0) {
                target.setDate(target.getDate() + 1);
                this.logger.info('📅 EOD OI Save: Skipping Sunday, scheduled for Monday');
            }
            const delay = target.getTime() - now.getTime();
            const delayMinutes = Math.floor(delay / 60000);
            const delayHours = Math.floor(delayMinutes / 60);
            const remainingMinutes = delayMinutes % 60;
            const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            const targetDayName = dayNames[target.getDay()];
            this.logger.info(`⏰ EOD OI Save scheduled for ${targetDayName} ${target.toLocaleTimeString()} (in ${delayHours}h ${remainingMinutes}m)`);
            this.eodOISaverTimer = setTimeout(async () => {
                const runDay = new Date().getDay();
                if (runDay >= 1 && runDay <= 5) {
                    await this.runEODOISave();
                }
                else {
                    this.logger.info('📅 EOD OI Save: Skipped (weekend)');
                }
                scheduleNextEODSave();
            }, delay);
        };
        scheduleNextEODSave();
    }
    async runEODOISave() {
        const now = new Date();
        this.logger.info(`💾 Running EOD OI Save at ${now.toLocaleTimeString()}...`);
        if (!this.oiHistoryService) {
            this.logger.error('❌ OI History Service not initialized');
            return;
        }
        if (!await this.authService.isAuthenticatedAndValid()) {
            this.logger.warn('⏭️ Skipping EOD OI Save - not authenticated');
            return;
        }
        const result = await this.oiHistoryService.saveEndOfDayOI();
        if (result.success) {
            this.logger.info(`✅ EOD OI Save complete: ${result.count} stocks saved at ${now.toLocaleTimeString()}`);
        }
        else {
            this.logger.error(`❌ EOD OI Save failed: ${result.errors.join(', ')}`);
        }
    }
    getOIHistoryService() {
        return this.oiHistoryService;
    }
    async triggerEODOISave() {
        if (!this.oiHistoryService) {
            return { success: false, count: 0, errors: ['OI History Service not initialized'] };
        }
        return this.oiHistoryService.saveEndOfDayOI();
    }
    async runHourlyScan() {
        if (this.isScanInProgress) {
            this.logger.warn('⏭️ Scan already in progress, skipping this request');
            return;
        }
        this.isScanInProgress = true;
        try {
            const scanStartTime = Date.now();
            this.logger.info('🔍 Smart Retention: Starting hourly scan...');
            const activePositionCount = this.slotStates.filter(s => {
                if (!s.strategyId)
                    return false;
                const strategy = StrategyRegistry_1.StrategyRegistry.getInstance(s.strategyId);
                if (!strategy)
                    return false;
                const status = strategy.getStatus();
                return !!status?.positionInfo;
            }).length;
            if (activePositionCount >= 3) {
                this.logger.info('⏭️ All 3 slots have active positions - skipping scan (nothing to rebalance)');
                return;
            }
            if (this.experimentalFlags.enableIncrementalScannerCandles) {
                const seeded = await this.marketScanner.seedCandlesIfNeeded();
                if (!seeded) {
                    this.logger.warn('⚠️ Incremental seed failed → falling back to full historical re-fetch this scan');
                    const fb = await this.marketScanner.cacheHistoricalData();
                    if (!fb.success) {
                        this.logger.error('❌ Fallback re-fetch also failed');
                        return;
                    }
                }
                else {
                    this.marketScanner.finalizeClosedFormingCandles();
                    const fresh = await this.marketScanner.ensureFreshUniverse();
                    this.logger.info(`📊 Step 1 (incremental): store maintained — ${fresh.stale} stale, ${fresh.reseeded} reseeded${fresh.fullReseed ? ' (FULL reseed)' : ''}`);
                }
                this.isDataCached = true;
                this.marketScanner.saveCandleStore();
            }
            else {
                this.logger.info('📊 Step 1: Re-fetching historical data for all stocks...');
                const cacheResult = await this.marketScanner.cacheHistoricalData();
                if (!cacheResult.success) {
                    this.logger.error('❌ Smart Retention: Failed to cache historical data');
                    return;
                }
                this.isDataCached = true;
                this.logger.info('⏳ Cooling down 3s before universe scan...');
                await new Promise(resolve => setTimeout(resolve, 3000));
            }
            this.logger.info('📊 Step 2: Running universe scan...');
            const scannerResult = await this.marketScanner.scanUniverse();
            this.lastScannerResults = scannerResult;
            this.logger.info(`📊 Scan complete: ${scannerResult.scannedCount} scanned, ${scannerResult.allScored.length} scored, ${scannerResult.selected.length} selected`);
            this.logger.info('📊 Step 3: Rebalancing with Smart Retention...');
            await this.rebalanceStrategies(scannerResult);
            const duration = ((Date.now() - scanStartTime) / 1000).toFixed(1);
            this.logger.info(`✅ Smart Retention scan complete in ${duration}s`);
        }
        catch (error) {
            this.logger.error('❌ Smart Retention scan failed:', error);
        }
        finally {
            this.isScanInProgress = false;
        }
    }
    async rebalanceStrategies(scannerResult) {
        const allScored = scannerResult.allScored;
        const selectedCandidates = scannerResult.selected;
        const deployedSymbols = new Set();
        for (const slotState of this.slotStates) {
            if (slotState.locked && slotState.symbol) {
                deployedSymbols.add(slotState.symbol);
                this.logger.info(`   🔒 Pre-reserving ${slotState.symbol} (locked in Slot ${slotState.slotNumber + 1})`);
            }
        }
        this.logger.info('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        this.logger.info('🔄 SMART RETENTION REBALANCE');
        this.logger.info('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        for (let slotIndex = 0; slotIndex < 3; slotIndex++) {
            const slotState = this.slotStates[slotIndex];
            if (!slotState)
                continue;
            this.logger.info(`\n📦 Slot ${slotIndex + 1}: ${slotState.symbol || '(empty)'}`);
            if (!slotState.symbol || !slotState.strategyId) {
                await this.handleEmptySlot(slotIndex, selectedCandidates, deployedSymbols);
                continue;
            }
            if (slotState.locked) {
                this.logger.info(`   🔒 Slot ${slotIndex + 1} is LOCKED with active position - protecting ${slotState.symbol}`);
                let strategy = StrategyRegistry_1.StrategyRegistry.getInstance(slotState.strategyId);
                if (!strategy || !strategy.isRunning()) {
                    if (strategy && !strategy.isRunning()) {
                        this.logger.warn(`   ⚠️ Strategy ${slotState.strategyId} exists but STOPPED - removing zombie...`);
                        StrategyRegistry_1.StrategyRegistry.removeInstance(slotState.strategyId);
                    }
                    else {
                        this.logger.info(`   ⚠️ Strategy ${slotState.strategyId} not in registry - attempting to restore...`);
                    }
                    const restored = await this.restoreStrategyFromSlotData(slotIndex, slotState);
                    if (restored) {
                        this.logger.info(`   ✅ Strategy restored successfully - position protected`);
                    }
                    else {
                        this.logger.error(`   ❌ CRITICAL: Failed to restore strategy - position may be orphaned!`);
                    }
                }
                else {
                    const lockedStatus = strategy?.getStatus();
                    if (!lockedStatus?.positionInfo) {
                        this.logger.info(`   🔓 Position exited since lock was set - unlocking Slot ${slotIndex + 1} (${slotState.symbol})`);
                        slotState.locked = false;
                    }
                    else {
                        this.logger.info(`   ✅ Strategy ${slotState.strategyId} already running with active position - no action needed`);
                    }
                }
                if (slotState.locked) {
                    deployedSymbols.add(slotState.symbol);
                    this.logRetentionDecision(slotIndex, slotState.symbol, 'LOCK', 'active_position', 'Protected from restart');
                    continue;
                }
            }
            const strategy = StrategyRegistry_1.StrategyRegistry.getInstance(slotState.strategyId);
            if (!strategy) {
                this.logger.warn(`   ⚠️ Strategy ${slotState.strategyId} not found in registry - treating as empty`);
                slotState.symbol = null;
                slotState.strategyId = null;
                await this.handleEmptySlot(slotIndex, selectedCandidates, deployedSymbols);
                continue;
            }
            deployedSymbols.add(slotState.symbol);
            const status = strategy.getStatus();
            const hasActivePosition = !!status?.positionInfo;
            const hasArmedSignal = typeof strategy.hasArmedSignal === 'function'
                ? strategy.hasArmedSignal()
                : false;
            const hasFvgWatch = typeof strategy.hasFvgWatch === 'function'
                ? strategy.hasFvgWatch()
                : false;
            if ((hasActivePosition || hasArmedSignal || hasFvgWatch) && this.smartRetentionConfig.lockOnActivePosition) {
                const lockReason = hasActivePosition
                    ? 'active_position'
                    : hasArmedSignal ? 'armed_signal' : 'fvg_watch';
                this.logRetentionDecision(slotIndex, slotState.symbol, 'LOCK', lockReason, null);
                slotState.locked = true;
                continue;
            }
            slotState.locked = false;
            const slotAgeMin = slotState.deployedAt
                ? (Date.now() - new Date(slotState.deployedAt).getTime()) / 60000
                : Infinity;
            const tooYoungToSoftSwap = slotAgeMin < this.smartRetentionConfig.minDeploymentAgeMinutes;
            const stockInScan = allScored.find(s => s.symbol === slotState.symbol);
            if (!stockInScan) {
                this.logRetentionDecision(slotIndex, slotState.symbol, 'SWAP', 'not_in_scan', null);
                await this.swapStrategy(slotIndex, selectedCandidates, deployedSymbols);
                continue;
            }
            const allowedBiases = this.allowedBiasesForSlot(slotIndex);
            if (!allowedBiases.includes(stockInScan.bias)) {
                this.logRetentionDecision(slotIndex, slotState.symbol, 'SWAP', 'bias_not_allowed', `${stockInScan.bias} not allowed (slot accepts ${allowedBiases.join('/')})`);
                await this.swapStrategy(slotIndex, selectedCandidates, deployedSymbols);
                continue;
            }
            if (this.smartRetentionConfig.swapOnBiasFlip &&
                slotState.lastScanBias &&
                stockInScan.bias !== slotState.lastScanBias) {
                this.logRetentionDecision(slotIndex, slotState.symbol, 'SWAP', 'bias_flip', `${slotState.lastScanBias} → ${stockInScan.bias}`);
                await this.swapStrategy(slotIndex, selectedCandidates, deployedSymbols);
                continue;
            }
            const isStrategyStale = this.experimentalFlags.enableStaleBreakoutFilter
                && typeof strategy.isStale === 'function' && slotState.lastScanBias
                ? strategy.isStale(slotState.lastScanBias)
                : false;
            if (isStrategyStale && !hasActivePosition) {
                if (tooYoungToSoftSwap) {
                    this.logRetentionDecision(slotIndex, slotState.symbol, 'KEEP', 'too_young', `Stale but slot only ${slotAgeMin.toFixed(1)}m old (< ${this.smartRetentionConfig.minDeploymentAgeMinutes}m)`);
                    continue;
                }
                this.logRetentionDecision(slotIndex, slotState.symbol, 'SWAP', 'stale_breakout', `Breakout expired (3+ candles outside band)`);
                await this.swapStrategy(slotIndex, selectedCandidates, deployedSymbols);
                continue;
            }
            slotState.lastScanScore = stockInScan.score;
            slotState.lastScanBias = stockInScan.bias;
            if (stockInScan.score < this.smartRetentionConfig.keepThreshold) {
                if (tooYoungToSoftSwap) {
                    this.logRetentionDecision(slotIndex, slotState.symbol, 'KEEP', 'too_young', `Score ${stockInScan.score.toFixed(1)} dropped but slot only ${slotAgeMin.toFixed(1)}m old`);
                    continue;
                }
                this.logRetentionDecision(slotIndex, slotState.symbol, 'SWAP', 'momentum_died', `Score ${stockInScan.score.toFixed(1)} < ${this.smartRetentionConfig.keepThreshold}`);
                await this.swapStrategy(slotIndex, selectedCandidates, deployedSymbols);
                continue;
            }
            if (!hasActivePosition && this.isSymbolInCooldown(slotState.symbol)) {
                const remaining = this.getSymbolCooldownRemaining(slotState.symbol);
                this.logRetentionDecision(slotIndex, slotState.symbol, 'SWAP', 'in_cooldown', `No position, ${remaining}m cooldown remaining — freeing slot`);
                await this.swapStrategy(slotIndex, selectedCandidates, deployedSymbols);
                continue;
            }
            this.logRetentionDecision(slotIndex, slotState.symbol, 'KEEP', 'still_top_tier', `Score ${stockInScan.score.toFixed(1)} ≥ ${this.smartRetentionConfig.keepThreshold}`);
        }
        const OUTPERFORM_SCORE_DELTA = 4.0;
        const idleSlots = [];
        for (let i = 0; i < this.slotStates.length; i++) {
            const ss = this.slotStates[i];
            if (!ss || !ss.symbol || ss.locked)
                continue;
            const strategy = StrategyRegistry_1.StrategyRegistry.getInstance(ss.strategyId);
            if (!strategy)
                continue;
            const sts = strategy.getStatus();
            if (sts?.positionInfo)
                continue;
            if (ss.lastScanScore == null)
                continue;
            idleSlots.push({ slotIndex: i, score: ss.lastScanScore, symbol: ss.symbol });
        }
        if (idleSlots.length > 0) {
            idleSlots.sort((a, b) => a.score - b.score);
            const weakest = idleSlots[0];
            const weakestAllowedBiases = this.allowedBiasesForSlot(weakest.slotIndex);
            const bestCandidate = selectedCandidates.find(c => !deployedSymbols.has(c.symbol) && !this.isSymbolInCooldown(c.symbol)
                && weakestAllowedBiases.includes(c.bias));
            if (bestCandidate && (bestCandidate.score - weakest.score) >= OUTPERFORM_SCORE_DELTA) {
                const weakestSlotState = this.slotStates[weakest.slotIndex];
                const weakestAgeMin = weakestSlotState?.deployedAt
                    ? (Date.now() - new Date(weakestSlotState.deployedAt).getTime()) / 60000
                    : Infinity;
                if (weakestAgeMin < this.smartRetentionConfig.minDeploymentAgeMinutes) {
                    this.logRetentionDecision(weakest.slotIndex, weakest.symbol, 'KEEP', 'too_young', `Outperformed by ${bestCandidate.symbol} but only ${weakestAgeMin.toFixed(1)}m old`);
                }
                else {
                    this.logRetentionDecision(weakest.slotIndex, weakest.symbol, 'SWAP', 'outperformed', `${bestCandidate.symbol} ${bestCandidate.score.toFixed(1)} vs ${weakest.symbol} ${weakest.score.toFixed(1)} (delta ${(bestCandidate.score - weakest.score).toFixed(1)} ≥ ${OUTPERFORM_SCORE_DELTA})`);
                    await this.swapStrategy(weakest.slotIndex, selectedCandidates, deployedSymbols);
                }
            }
        }
        this.logger.info('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        this.logSlotSummary();
    }
    allowedBiasesForSlot(slotIndex) {
        const f = this.experimentalFlags;
        if (f.enableFvgEntry && Array.isArray(f.fvgSlots) && f.fvgSlots.includes(slotIndex)) {
            return ['LONG'];
        }
        if (!f.enableShortEntries) {
            return ['LONG'];
        }
        return ['LONG', 'SHORT'];
    }
    async handleEmptySlot(slotIndex, candidates, deployedSymbols) {
        const alreadyDeployedInSlots = new Set(this.slotStates
            .filter(s => s.symbol !== null)
            .map(s => s.symbol));
        const allowedBiases = this.allowedBiasesForSlot(slotIndex);
        const availableCandidate = candidates.find(c => !deployedSymbols.has(c.symbol) &&
            !alreadyDeployedInSlots.has(c.symbol) &&
            !this.isSymbolInCooldown(c.symbol) &&
            allowedBiases.includes(c.bias));
        if (!availableCandidate) {
            const biasNote = allowedBiases.length < 2 ? ` (slot accepts ${allowedBiases.join('/')} only)` : '';
            this.logger.info(`   📭 No available candidates for Slot ${slotIndex + 1}${biasNote}`);
            return;
        }
        deployedSymbols.add(availableCandidate.symbol);
        this.logRetentionDecision(slotIndex, availableCandidate.symbol, 'DEPLOY', 'empty_slot', `Score ${availableCandidate.score.toFixed(1)}`);
        await this.deployToSlot(slotIndex, availableCandidate);
    }
    async swapStrategy(slotIndex, candidates, deployedSymbols) {
        const slotState = this.slotStates[slotIndex];
        if (!slotState)
            return;
        if (slotState.strategyId) {
            this.logger.info(`   ⏹️ Stopping ${slotState.symbol}...`);
            await this.stopAndRemoveStrategy(slotState.strategyId);
            deployedSymbols.delete(slotState.symbol);
        }
        await this.sleep(500);
        slotState.symbol = null;
        slotState.strategyId = null;
        slotState.deployedAt = null;
        slotState.lastScanScore = null;
        slotState.lastScanBias = null;
        await this.handleEmptySlot(slotIndex, candidates, deployedSymbols);
    }
    async deployToSlot(slotIndex, stock) {
        const slotState = this.slotStates[slotIndex];
        if (!slotState)
            return;
        for (let i = 0; i < this.slotStates.length; i++) {
            if (i !== slotIndex && this.slotStates[i]?.symbol === stock.symbol) {
                this.logger.error(`   🚫 DUPLICATE BLOCKED: ${stock.symbol} already in Slot ${i + 1}, cannot deploy to Slot ${slotIndex + 1}`);
                return;
            }
        }
        try {
            const slotNumber = slotIndex + 1;
            const sanitizedSymbol = stock.symbol.toLowerCase().replace(/&/g, '_and_');
            const strategyId = `bollinger-slot${slotNumber}-${sanitizedSymbol}`;
            const config = {
                id: strategyId,
                name: `Bollinger Band - ${stock.symbol}`,
                enabled: true,
                description: `Scanner: ${stock.score.toFixed(2)} | Bias: ${stock.bias}`,
                timeframe: '5min',
                instruments: [stock.symbol],
                riskPerTrade: 0.8,
                maxPositions: 1,
                config: {
                    period: 20,
                    stdDev: 2.0,
                    scannerData: {
                        score: stock.score,
                        bias: stock.bias,
                        sector: stock.sector,
                        atmOption: stock.atmOption,
                        historicalData: stock.historicalData,
                    },
                    capitalAllocation: 65000,
                    strategyIndex: slotIndex,
                },
            };
            const strategy = await StrategyRegistry_1.StrategyRegistry.createInstance('bollinger-band', this.kiteConnect, this.logger, this.quoteManager, this.instrumentCache, config);
            await strategy.start();
            slotState.symbol = stock.symbol;
            slotState.strategyId = strategyId;
            slotState.deployedAt = new Date();
            slotState.lastScanScore = stock.score;
            slotState.lastScanBias = stock.bias;
            slotState.locked = false;
            this.logger.info(`   ✅ ${stock.symbol} deployed to Slot ${slotIndex + 1}`);
        }
        catch (error) {
            this.logger.error(`   ❌ Failed to deploy ${stock.symbol}:`, error);
        }
    }
    async stopAndRemoveStrategy(strategyId) {
        try {
            const instance = StrategyRegistry_1.StrategyRegistry.getInstance(strategyId);
            if (instance) {
                await instance.stop();
                StrategyRegistry_1.StrategyRegistry.removeInstance(strategyId);
                this.logger.info(`   🗑️ Removed strategy: ${strategyId}`);
            }
        }
        catch (error) {
            this.logger.error(`   ❌ Error stopping strategy ${strategyId}:`, error);
        }
    }
    logRetentionDecision(slotIndex, symbol, decision, reason, details) {
        const icons = {
            'LOCK': '🔒',
            'KEEP': '🛡️',
            'SWAP': '♻️',
            'DEPLOY': '🚀',
        };
        const reasonText = {
            'empty_slot': 'Empty slot',
            'active_position': 'Active position (protected)',
            'armed_signal': 'Armed pullback signal (protected)',
            'fvg_watch': 'FVG retrace watch (protected)',
            'still_top_tier': 'Still performing well',
            'momentum_died': 'Momentum dropped',
            'bias_flip': 'Bias reversed',
            'not_in_scan': 'Dropped from scan (sector flat/filtered)',
            'stale_breakout': 'Breakout too old (3+ candles outside band)',
            'in_cooldown': 'Symbol in cooldown (slot freed)',
            'outperformed': 'Outperformed by better candidate',
            'too_young': 'Slot too young to swap (deployment age guard)',
            'bias_not_allowed': 'Bias not allowed in this slot',
        };
        const slotState = this.slotStates[slotIndex];
        if (slotState) {
            slotState.lastRetentionDecision = decision;
            slotState.lastRetentionReason = details ? `${reasonText[reason]} (${details})` : reasonText[reason];
        }
        const message = `   ${icons[decision]} ${decision}: ${symbol} - ${reasonText[reason]}${details ? ` (${details})` : ''}`;
        this.logger.info(message);
    }
    logSlotSummary() {
        this.logger.info('📊 SLOT SUMMARY:');
        for (const slot of this.slotStates) {
            const status = slot.symbol
                ? `${slot.symbol} (Score: ${slot.lastScanScore?.toFixed(1) || '?'}, ${slot.lastScanBias || '?'})${slot.locked ? ' 🔒' : ''}`
                : '(empty)';
            this.logger.info(`   Slot ${slot.slotNumber + 1}: ${status}`);
        }
    }
    async deployMultipleStrategies(stocks) {
        for (let i = 0; i < stocks.length && i < 3; i++) {
            const stock = stocks[i];
            if (!stock)
                continue;
            await this.deployToSlot(i, stock);
        }
    }
    sleep(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
    async runManualScanner(force = false) {
        this.logger.info(`🔍 Manual scanner triggered${force ? ' (FORCED)' : ''}`);
        if (!await this.authService.isAuthenticatedAndValid()) {
            throw new Error('Not authenticated - please login first');
        }
        await this.runHourlyScan();
        return {
            ...this.lastScannerResults,
            slotStates: this.slotStates,
            message: 'Smart Retention scan complete'
        };
    }
    async getLastScannerResults() {
        return this.lastScannerResults || null;
    }
    getCandleEngineStatus() {
        return {
            mode: this.experimentalFlags.enableIncrementalScannerCandles ? 'incremental' : 'legacy_full_refetch',
            marketOpen: this.isMarketOpenNow(),
            ...this.marketScanner.getCandleEngineStatus(),
        };
    }
    getSlotStates() {
        return this.slotStates;
    }
    getSlotStatesWithPositions() {
        return this.slotStates.map(slot => {
            let hasActivePosition = false;
            let positionInfo = null;
            if (slot.strategyId) {
                const strategy = StrategyRegistry_1.StrategyRegistry.getInstance(slot.strategyId);
                if (strategy) {
                    try {
                        const status = strategy.getStatus();
                        if (status?.positionInfo) {
                            hasActivePosition = true;
                            positionInfo = {
                                type: status.positionInfo.type,
                                tradingSymbol: status.positionInfo.tradingSymbol || status.positionInfo.instrument?.tradingsymbol || 'Unknown',
                                entryPrice: status.positionInfo.entryPrice || 0,
                                currentPrice: status.positionInfo.currentPrice || 0,
                                quantity: status.positionInfo.quantity || 0,
                                unrealizedPnL: status.positionInfo.unrealizedPnL || 0,
                                trailingSL: status.positionInfo.trailingSL || null,
                                profitPercent: status.positionInfo.profitPercent || 0,
                            };
                            slot.locked = true;
                        }
                        else {
                        }
                    }
                    catch (error) {
                        this.logger.debug(`Error getting status for ${slot.strategyId}: ${error}`);
                    }
                }
            }
            return {
                ...slot,
                hasActivePosition,
                positionInfo,
            };
        });
    }
}
exports.StrategyManager = StrategyManager;
StrategyManager.instance = null;
//# sourceMappingURL=StrategyManager.js.map