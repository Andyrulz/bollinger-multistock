import { Logger } from "../utils/Logger";
type QuoteCallback = (quote: any) => void;
export declare class QuoteManager {
    private kiteConnect;
    private logger;
    private subscribers;
    private pollingInterval;
    private isPolling;
    private consecutiveErrors;
    private lastSuccessfulFetch;
    constructor(kiteConnect: any, logger: Logger);
    subscribe(symbol: string, callback: QuoteCallback): void;
    unsubscribe(symbol: string, callback: QuoteCallback): void;
    private startPolling;
    private stopPolling;
    private fetchAndPublish;
    private validateQuoteData;
    getStats(): {
        isPolling: boolean;
        subscriberCount: number;
        symbols: string[];
        consecutiveErrors: number;
        dataStale: boolean;
        lastFetchAge: number;
    };
    shutdown(): Promise<void>;
}
export {};
//# sourceMappingURL=QuoteManager.d.ts.map