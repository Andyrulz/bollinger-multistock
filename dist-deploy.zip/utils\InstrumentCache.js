"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.InstrumentCache = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
class InstrumentCache {
    constructor(kiteConnect, logger) {
        this.kiteConnect = kiteConnect;
        this.logger = logger;
        if (!fs.existsSync(InstrumentCache.CACHE_DIR)) {
            fs.mkdirSync(InstrumentCache.CACHE_DIR, { recursive: true });
        }
    }
    async getNFOInstruments() {
        const today = new Date().toISOString().split('T')[0];
        const filePath = path.join(InstrumentCache.CACHE_DIR, `instruments-nfo-${today}.json`);
        if (fs.existsSync(filePath)) {
            try {
                this.logger.info('📂 Loading NFO instruments from today\'s cache...');
                const rawData = fs.readFileSync(filePath, 'utf-8');
                const data = JSON.parse(rawData);
                const instruments = data.map((i) => ({ ...i, expiry: new Date(i.expiry) }));
                this.logger.info(`✅ Loaded ${instruments.length} instruments from cache`);
                return instruments;
            }
            catch (error) {
                this.logger.warn(`⚠️ Corrupt cache file, refetching: ${error}`);
            }
        }
        this.logger.info('⬇️ Fetching NFO instruments from Zerodha API...');
        const startTime = Date.now();
        const instruments = await this.kiteConnect.getInstruments('NFO');
        const duration = ((Date.now() - startTime) / 1000).toFixed(1);
        this.logger.info(`✅ Fetched ${instruments.length} instruments in ${duration}s`);
        this.logger.info(`💾 Caching instruments to ${filePath}...`);
        fs.writeFileSync(filePath, JSON.stringify(instruments));
        const todayStr = today;
        if (todayStr) {
            this.cleanupOldFiles(todayStr);
        }
        return instruments;
    }
    cleanupOldFiles(todayStr) {
        fs.readdir(InstrumentCache.CACHE_DIR, (err, files) => {
            if (err)
                return;
            files.forEach(file => {
                if (file.startsWith('instruments-nfo-') && !file.includes(todayStr)) {
                    const filePath = path.join(InstrumentCache.CACHE_DIR, file);
                    fs.unlink(filePath, (unlinkErr) => {
                        if (!unlinkErr) {
                            this.logger.debug(`🗑️ Cleaned up old cache: ${file}`);
                        }
                    });
                }
            });
        });
    }
}
exports.InstrumentCache = InstrumentCache;
InstrumentCache.CACHE_DIR = path.join(__dirname, '../../data/cache');
//# sourceMappingURL=InstrumentCache.js.map