"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.OIHistoryService = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const universe_1 = require("../config/universe");
class OIHistoryService {
    constructor(kiteConnect, logger, instrumentCache) {
        this.MIN_OI_THRESHOLD = 100000;
        this.OI_CHANGE_THRESHOLD = 5;
        this.PRICE_CHANGE_MAX = 1.5;
        this.yesterdayOI = null;
        this.futuresTokenCache = new Map();
        this.kiteConnect = kiteConnect;
        this.logger = logger;
        this.instrumentCache = instrumentCache;
        const dataDir = path.dirname(OIHistoryService.OI_HISTORY_FILE);
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }
    }
    async loadYesterdayOI() {
        try {
            if (!fs.existsSync(OIHistoryService.OI_HISTORY_FILE)) {
                this.logger.info('📭 OI History: No historical data found (first run)');
                return false;
            }
            const rawData = fs.readFileSync(OIHistoryService.OI_HISTORY_FILE, 'utf8');
            const data = JSON.parse(rawData);
            const savedAt = new Date(data.savedAt);
            const hoursOld = (Date.now() - savedAt.getTime()) / (1000 * 60 * 60);
            if (hoursOld > 48) {
                this.logger.warn(`⚠️ OI History: Data is ${hoursOld.toFixed(1)} hours old - too stale, skipping Smart Money scoring`);
                this.yesterdayOI = null;
                return false;
            }
            this.yesterdayOI = data;
            const stockCount = Object.keys(data.data).length;
            this.logger.info(`✅ OI History: Loaded ${stockCount} stocks from ${savedAt.toLocaleString()}`);
            this.logger.info(`   Expiry: ${data.expiryDate}`);
            return true;
        }
        catch (error) {
            this.logger.error('❌ OI History: Failed to load historical data:', error);
            this.yesterdayOI = null;
            return false;
        }
    }
    async saveEndOfDayOI() {
        this.logger.info('💾 OI History: Starting End-of-Day OI save...');
        const startTime = Date.now();
        const errors = [];
        try {
            await this.buildFuturesTokenCache();
            const oiData = {};
            const batchSize = 50;
            const symbols = Array.from(this.futuresTokenCache.keys());
            for (let i = 0; i < symbols.length; i += batchSize) {
                const batch = symbols.slice(i, i + batchSize);
                const quoteKeys = batch.map(symbol => {
                    const futuresInfo = this.futuresTokenCache.get(symbol);
                    return `NFO:${futuresInfo?.symbol}`;
                }).filter(k => k !== 'NFO:undefined');
                if (quoteKeys.length === 0)
                    continue;
                try {
                    const quotes = await this.kiteConnect.getQuote(quoteKeys);
                    for (const symbol of batch) {
                        const futuresInfo = this.futuresTokenCache.get(symbol);
                        if (!futuresInfo)
                            continue;
                        const quoteKey = `NFO:${futuresInfo.symbol}`;
                        const quote = quotes[quoteKey];
                        if (quote && quote.oi !== undefined) {
                            oiData[symbol] = {
                                futuresOI: quote.oi,
                                futuresSymbol: futuresInfo.symbol,
                                savedAt: new Date().toISOString()
                            };
                        }
                        else {
                            errors.push(`${symbol}: No OI data in quote`);
                        }
                    }
                }
                catch (batchError) {
                    this.logger.error(`Batch quote fetch failed:`, batchError);
                    errors.push(`Batch ${i / batchSize + 1}: Quote fetch failed`);
                }
                if (i + batchSize < symbols.length) {
                    await new Promise(resolve => setTimeout(resolve, 200));
                }
            }
            const firstFutures = this.futuresTokenCache.values().next().value;
            const expiryDate = firstFutures?.expiry?.toISOString().split('T')[0] || 'unknown';
            const historyData = {
                savedAt: new Date().toISOString(),
                expiryDate: expiryDate,
                data: oiData
            };
            fs.writeFileSync(OIHistoryService.OI_HISTORY_FILE, JSON.stringify(historyData, null, 2));
            const duration = ((Date.now() - startTime) / 1000).toFixed(1);
            const successCount = Object.keys(oiData).length;
            this.logger.info(`✅ OI History: Saved ${successCount}/${universe_1.UNIVERSE.length} stocks in ${duration}s`);
            if (errors.length > 0) {
                this.logger.warn(`⚠️ OI History: ${errors.length} errors during save`);
            }
            return { success: true, count: successCount, errors };
        }
        catch (error) {
            this.logger.error('❌ OI History: Failed to save EOD data:', error);
            return { success: false, count: 0, errors: [String(error)] };
        }
    }
    async buildFuturesTokenCache() {
        if (this.futuresTokenCache.size > 0) {
            this.logger.debug('📋 Using cached futures token mapping');
            return;
        }
        this.logger.info('🔍 Building futures token cache...');
        const instruments = await this.instrumentCache.getNFOInstruments();
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const currentMonthExpiry = this.getCurrentMonthExpiry();
        for (const stock of universe_1.UNIVERSE) {
            const futures = instruments.find((i) => i.name === stock.symbol &&
                i.segment === 'NFO-FUT' &&
                new Date(i.expiry) >= today &&
                this.isSameMonth(new Date(i.expiry), currentMonthExpiry));
            if (futures) {
                this.futuresTokenCache.set(stock.symbol, {
                    token: futures.instrument_token,
                    symbol: futures.tradingsymbol,
                    expiry: new Date(futures.expiry)
                });
            }
            else {
                const nearestFutures = instruments
                    .filter((i) => i.name === stock.symbol &&
                    i.segment === 'NFO-FUT' &&
                    new Date(i.expiry) >= today)
                    .sort((a, b) => new Date(a.expiry).getTime() - new Date(b.expiry).getTime())[0];
                if (nearestFutures) {
                    this.futuresTokenCache.set(stock.symbol, {
                        token: nearestFutures.instrument_token,
                        symbol: nearestFutures.tradingsymbol,
                        expiry: new Date(nearestFutures.expiry)
                    });
                }
                else {
                    this.logger.warn(`⚠️ No futures found for ${stock.symbol} (may be in F&O ban)`);
                }
            }
        }
        this.logger.info(`✅ Futures token cache: ${this.futuresTokenCache.size}/${universe_1.UNIVERSE.length} stocks mapped`);
    }
    getCurrentMonthExpiry() {
        const today = new Date();
        const year = today.getFullYear();
        const month = today.getMonth();
        const lastDay = new Date(year, month + 1, 0);
        while (lastDay.getDay() !== 4) {
            lastDay.setDate(lastDay.getDate() - 1);
        }
        if (today > lastDay) {
            const nextMonthLastDay = new Date(year, month + 2, 0);
            while (nextMonthLastDay.getDay() !== 4) {
                nextMonthLastDay.setDate(nextMonthLastDay.getDate() - 1);
            }
            return nextMonthLastDay;
        }
        return lastDay;
    }
    isSameMonth(date1, date2) {
        return date1.getFullYear() === date2.getFullYear() &&
            date1.getMonth() === date2.getMonth();
    }
    isExpiryWeek() {
        const today = new Date();
        const expiry = this.getCurrentMonthExpiry();
        const expiryTuesday = new Date(expiry);
        expiryTuesday.setDate(expiry.getDate() - 2);
        expiryTuesday.setHours(0, 0, 0, 0);
        const todayStart = new Date(today);
        todayStart.setHours(0, 0, 0, 0);
        const expiryEnd = new Date(expiry);
        expiryEnd.setHours(23, 59, 59, 999);
        const isExpiry = todayStart >= expiryTuesday && todayStart <= expiryEnd;
        if (isExpiry) {
            this.logger.info(`📅 Expiry Week Detected: ${expiryTuesday.toDateString()} to ${expiry.toDateString()}`);
        }
        return isExpiry;
    }
    async analyzeStock(symbol, currentPrice, prevClose) {
        if (!this.yesterdayOI || !this.yesterdayOI.data[symbol]) {
            return null;
        }
        if (this.isExpiryWeek()) {
            return null;
        }
        const prevEntry = this.yesterdayOI.data[symbol];
        const prevOI = prevEntry.futuresOI;
        if (prevOI < this.MIN_OI_THRESHOLD) {
            return null;
        }
        await this.buildFuturesTokenCache();
        const futuresInfo = this.futuresTokenCache.get(symbol);
        if (!futuresInfo) {
            return null;
        }
        try {
            const quoteKey = `NFO:${futuresInfo.symbol}`;
            const quotes = await this.kiteConnect.getQuote([quoteKey]);
            const quote = quotes[quoteKey];
            if (!quote || quote.oi === undefined) {
                return null;
            }
            const currentOI = quote.oi;
            const oiChangePercent = ((currentOI - prevOI) / prevOI) * 100;
            const priceChangePercent = ((currentPrice - prevClose) / prevClose) * 100;
            let smartMoneySignal = 'NONE';
            let isCoiledSpring = false;
            const absOiChange = Math.abs(oiChangePercent);
            if (absOiChange >= this.OI_CHANGE_THRESHOLD) {
                if (oiChangePercent >= this.OI_CHANGE_THRESHOLD) {
                    if (priceChangePercent >= 0 && priceChangePercent <= this.PRICE_CHANGE_MAX) {
                        smartMoneySignal = 'ACCUMULATION';
                        isCoiledSpring = true;
                    }
                    else if (priceChangePercent >= -this.PRICE_CHANGE_MAX && priceChangePercent < 0) {
                        smartMoneySignal = 'DISTRIBUTION';
                        isCoiledSpring = true;
                    }
                }
                else if (oiChangePercent <= -this.OI_CHANGE_THRESHOLD) {
                    if (priceChangePercent >= 0 && priceChangePercent <= this.PRICE_CHANGE_MAX) {
                        smartMoneySignal = 'SHORT_COVERING';
                        isCoiledSpring = true;
                    }
                    else if (priceChangePercent >= -this.PRICE_CHANGE_MAX && priceChangePercent < 0) {
                        smartMoneySignal = 'LONG_UNWINDING';
                        isCoiledSpring = true;
                    }
                }
            }
            return {
                symbol,
                prevOI,
                currentOI,
                oiChangePercent,
                priceChangePercent,
                isCoiledSpring,
                smartMoneySignal,
                futuresSymbol: futuresInfo.symbol
            };
        }
        catch (error) {
            this.logger.error(`Failed to analyze OI for ${symbol}:`, error);
            return null;
        }
    }
    calculateSmartMoneyBonus(oiAnalysis, bias) {
        if (!oiAnalysis || !oiAnalysis.isCoiledSpring) {
            return 0;
        }
        const signal = oiAnalysis.smartMoneySignal;
        if (bias === 'LONG') {
            if (signal === 'ACCUMULATION' || signal === 'SHORT_COVERING') {
                return 2.0;
            }
            if (signal === 'DISTRIBUTION' || signal === 'LONG_UNWINDING') {
                return -999;
            }
        }
        if (bias === 'SHORT') {
            if (signal === 'DISTRIBUTION' || signal === 'LONG_UNWINDING') {
                return 2.0;
            }
            if (signal === 'ACCUMULATION' || signal === 'SHORT_COVERING') {
                return -999;
            }
        }
        return 0;
    }
    async getFullAnalysis() {
        const results = [];
        if (!this.yesterdayOI) {
            this.logger.warn('No yesterday OI data available for analysis');
            return results;
        }
        await this.buildFuturesTokenCache();
        const symbols = Array.from(this.futuresTokenCache.keys());
        const quoteKeys = [];
        const symbolToQuoteKey = new Map();
        for (const symbol of symbols) {
            const futuresInfo = this.futuresTokenCache.get(symbol);
            if (futuresInfo) {
                const quoteKey = `NFO:${futuresInfo.symbol}`;
                quoteKeys.push(quoteKey);
                symbolToQuoteKey.set(symbol, quoteKey);
            }
        }
        const stockQuoteKeys = symbols.map(s => `NSE:${s}`);
        try {
            const [futuresQuotes, stockQuotes] = await Promise.all([
                this.kiteConnect.getQuote(quoteKeys.slice(0, 500)),
                this.kiteConnect.getQuote(stockQuoteKeys.slice(0, 500))
            ]);
            for (const symbol of symbols) {
                const prevEntry = this.yesterdayOI?.data[symbol];
                if (!prevEntry)
                    continue;
                const futuresInfo = this.futuresTokenCache.get(symbol);
                if (!futuresInfo)
                    continue;
                const futuresQuoteKey = `NFO:${futuresInfo.symbol}`;
                const stockQuoteKey = `NSE:${symbol}`;
                const futuresQuote = futuresQuotes[futuresQuoteKey];
                const stockQuote = stockQuotes[stockQuoteKey];
                if (!futuresQuote || !stockQuote)
                    continue;
                const prevOI = prevEntry.futuresOI;
                const currentOI = futuresQuote.oi || 0;
                const currentPrice = stockQuote.last_price;
                const prevClose = stockQuote.ohlc?.close || currentPrice;
                if (prevOI < this.MIN_OI_THRESHOLD)
                    continue;
                const oiChangePercent = ((currentOI - prevOI) / prevOI) * 100;
                const priceChangePercent = ((currentPrice - prevClose) / prevClose) * 100;
                let smartMoneySignal = 'NONE';
                let isCoiledSpring = false;
                if (oiChangePercent >= this.OI_CHANGE_THRESHOLD) {
                    if (priceChangePercent >= 0 && priceChangePercent <= this.PRICE_CHANGE_MAX) {
                        smartMoneySignal = 'ACCUMULATION';
                        isCoiledSpring = true;
                    }
                    else if (priceChangePercent >= -this.PRICE_CHANGE_MAX && priceChangePercent < 0) {
                        smartMoneySignal = 'DISTRIBUTION';
                        isCoiledSpring = true;
                    }
                }
                results.push({
                    symbol,
                    prevOI,
                    currentOI,
                    oiChangePercent,
                    priceChangePercent,
                    isCoiledSpring,
                    smartMoneySignal,
                    futuresSymbol: futuresInfo.symbol
                });
            }
            results.sort((a, b) => Math.abs(b.oiChangePercent) - Math.abs(a.oiChangePercent));
        }
        catch (error) {
            this.logger.error('Failed to get full OI analysis:', error);
        }
        return results;
    }
    getHistoryData() {
        try {
            if (!fs.existsSync(OIHistoryService.OI_HISTORY_FILE)) {
                return null;
            }
            const rawData = fs.readFileSync(OIHistoryService.OI_HISTORY_FILE, 'utf8');
            return JSON.parse(rawData);
        }
        catch (error) {
            this.logger.error('Failed to read OI history file:', error);
            return this.yesterdayOI;
        }
    }
    hasValidData() {
        return this.yesterdayOI !== null && Object.keys(this.yesterdayOI.data).length > 0;
    }
}
exports.OIHistoryService = OIHistoryService;
OIHistoryService.OI_HISTORY_FILE = path.join(__dirname, '../data/oi-history.json');
//# sourceMappingURL=OIHistoryService.js.map