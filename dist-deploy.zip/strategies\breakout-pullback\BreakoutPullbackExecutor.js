"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.TradeExecutionService = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
class TradeExecutionService {
    constructor(kiteConnect, logger) {
        this.instruments = [];
        this.niftyInstruments = [];
        this.cachedOptionPrice = null;
        this.cachedOptionTimestamp = null;
        this.kiteConnect = kiteConnect;
        this.logger = logger;
        this.dataFilePath = path.join(__dirname, '../../data/trading-data.json');
        this.persistedData = this.loadPersistedData();
        this.ensureDataDirectory();
        this.setupGracefulShutdown();
        this.logger.info('🚀 TradeExecutionService initialized');
        this.logger.info(`💰 Current Capital: ₹${this.persistedData.config.capital.toLocaleString()}`);
        if (this.persistedData.activePosition) {
            this.logger.info(`📊 Active Position Found: ${this.persistedData.activePosition.tradeId}`);
            this.logger.info(`⚠️ System restarted with active position - monitoring required`);
        }
    }
    setupGracefulShutdown() {
        this.logger.info('🔧 TradeExecutionService initialized - process handlers managed at application level');
    }
    async gracefulShutdown() {
        try {
            this.logger.info('🔄 Starting graceful shutdown sequence...');
            if (this.persistedData.activePosition) {
                this.logger.warn('⚠️ Active position detected during shutdown!');
                this.logger.info(`📊 Position: ${this.persistedData.activePosition.tradeId}`);
                this.logger.info(`📈 Instrument: ${this.persistedData.activePosition.instrument.tradingsymbol}`);
                this.logger.info(`🎲 Quantity: ${this.persistedData.activePosition.quantity}`);
                this.logger.info(`💰 Entry Price: ₹${this.persistedData.activePosition.entryPrice}`);
                if (!this.persistedData.config.paperTradingMode) {
                    await this.syncWithBrokerState();
                    this.logger.warn('🚨 IMPORTANT: Monitor position manually in Zerodha account');
                    this.logger.warn('🚨 Position will persist after system shutdown');
                }
                else {
                    this.logger.info('📝 Paper trading position - no action required');
                }
            }
            else {
                this.logger.info('✅ No active positions - safe to shutdown');
            }
            this.savePersistedData();
            this.logger.info('💾 Final state saved successfully');
            this.logger.info('✅ Graceful shutdown completed');
        }
        catch (error) {
            this.logger.error('❌ Error during graceful shutdown:', error);
            throw error;
        }
    }
    async forceCloseAllPositions(reason = 'SYSTEM_SHUTDOWN') {
        try {
            if (!this.persistedData.activePosition) {
                this.logger.info('📋 No active positions to close');
                return;
            }
            this.logger.warn(`🚨 FORCE CLOSING POSITION - Reason: ${reason}`);
            await this.closePosition(this.persistedData.activePosition.tradeId, 'MANUAL');
            this.logger.info('✅ Position force closed successfully');
        }
        catch (error) {
            this.logger.error('❌ Error force closing positions:', error);
            throw error;
        }
    }
    async clearOrphanedPositionWithExitPrice() {
        try {
            if (!this.persistedData.activePosition) {
                this.logger.info('📋 No orphaned position to clear');
                return;
            }
            const position = this.persistedData.activePosition;
            const tradeId = position.tradeId;
            const symbol = position.instrument.tradingsymbol;
            const entryOrderId = position.entryOrderId;
            const entryTime = new Date(position.entryTime);
            const entryPrice = position.entryPrice;
            this.logger.warn(`🧹 Clearing orphaned position: ${tradeId}`);
            this.logger.info(`   📊 Symbol: ${symbol}, Entry: ₹${entryPrice}, Time: ${entryTime.toLocaleString()}`);
            let exitPrice = entryPrice;
            let exitOrderId = `MANUAL_CLEAR_${Date.now()}`;
            let exitTime = new Date();
            try {
                const exitOrder = await this.fetchExitOrderFromBroker(symbol, entryTime, position.quantity);
                if (exitOrder) {
                    exitPrice = exitOrder.average_price || exitOrder.price || entryPrice;
                    exitOrderId = exitOrder.order_id;
                    exitTime = new Date(exitOrder.order_timestamp);
                    if (exitOrder.quantity !== position.quantity) {
                        this.logger.warn(`⚠️ Quantity mismatch detected!`, {
                            entryQty: position.quantity,
                            exitQty: exitOrder.quantity,
                            warning: 'Using this exit order but quantities differ'
                        });
                    }
                    this.logger.info('✅ Found actual exit order from broker', {
                        exitOrderId: exitOrderId,
                        exitPrice: exitPrice,
                        exitTime: exitTime.toLocaleString(),
                        exitQty: exitOrder.quantity
                    });
                }
                else {
                    this.logger.warn('⚠️ Could not find exit order from broker, using entry price for P&L (P&L = 0)');
                }
            }
            catch (error) {
                this.logger.error('❌ Error fetching exit order from broker:', error);
                this.logger.warn('⚠️ Will use entry price for P&L (P&L = 0)');
            }
            const pnl = this.calculatePnL(position, exitPrice);
            if (!this.persistedData.config.paperTradingMode) {
                this.updateCapitalAfterTrade(pnl);
            }
            const tradeRecord = {
                tradeId: position.tradeId,
                entryOrderId: position.entryOrderId,
                exitOrderId: exitOrderId,
                instrument: position.instrument,
                direction: position.direction,
                quantity: position.quantity,
                entryPrice: position.entryPrice,
                exitPrice: exitPrice,
                entryTime: position.entryTime,
                exitTime: exitTime,
                pnl: pnl,
                exitReason: 'MANUAL',
                status: 'CLOSED',
                isPaperTrade: this.persistedData.config.paperTradingMode
            };
            this.persistedData.tradeHistory.push(tradeRecord);
            this.logger.info('📊 Trade recorded via manual clear', {
                exitPrice: exitPrice.toFixed(2),
                pnl: `₹${pnl > 0 ? '+' : ''}${pnl.toLocaleString()}`,
                newCapital: `₹${this.persistedData.config.capital.toLocaleString()}`,
                totalTrades: this.persistedData.tradeHistory.length
            });
            delete this.persistedData.activePosition;
            if (this.persistedData.activeInstrument) {
                delete this.persistedData.activeInstrument;
            }
            this.clearOptionPriceCache();
            this.savePersistedData();
            this.logger.info(`✅ Orphaned position cleared successfully with P&L recorded`);
        }
        catch (error) {
            this.logger.error('❌ Error clearing orphaned position:', error);
            throw error;
        }
    }
    async fetchExitOrderFromBroker(symbol, entryTime, entryQuantity) {
        try {
            const orders = await this.kiteConnect.getOrders();
            let exitCandidates = orders.filter((order) => {
                const orderTime = new Date(order.order_timestamp);
                return order.tradingsymbol === symbol
                    && order.transaction_type === 'SELL'
                    && order.status === 'COMPLETE'
                    && orderTime > entryTime
                    && (!order.tag || order.tag === '');
            });
            if (exitCandidates.length === 0) {
                this.logger.warn(`⚠️ No manual SELL orders found for ${symbol} after ${entryTime.toLocaleTimeString()}`);
                return null;
            }
            if (entryQuantity) {
                const exactMatch = exitCandidates.filter((order) => order.quantity === entryQuantity);
                if (exactMatch.length > 0) {
                    exitCandidates = exactMatch;
                    this.logger.info(`✅ Found ${exactMatch.length} quantity-matching exit orders (qty=${entryQuantity})`);
                }
                else {
                    this.logger.warn(`⚠️ No exact quantity match found. Using closest by time.`);
                }
            }
            exitCandidates.sort((a, b) => new Date(a.order_timestamp).getTime() - new Date(b.order_timestamp).getTime());
            const exitOrder = exitCandidates[0];
            this.logger.info(`✅ Selected exit order (${exitCandidates.length} candidates after filters)`, {
                orderId: exitOrder.order_id,
                qty: exitOrder.quantity,
                price: exitOrder.average_price,
                time: exitOrder.order_timestamp,
                tag: exitOrder.tag || 'NONE (manual)',
                quantityMatch: entryQuantity ? (exitOrder.quantity === entryQuantity ? '✅ MATCH' : '⚠️ MISMATCH') : 'N/A'
            });
            return exitOrder;
        }
        catch (error) {
            this.logger.error('Error fetching orders from broker:', error);
            return null;
        }
    }
    clearOrphanedPosition() {
        try {
            if (!this.persistedData.activePosition) {
                this.logger.info('📋 No orphaned position to clear');
                return;
            }
            const tradeId = this.persistedData.activePosition.tradeId;
            this.logger.warn(`🧹 Clearing orphaned position: ${tradeId}`);
            delete this.persistedData.activePosition;
            if (this.persistedData.activeInstrument) {
                delete this.persistedData.activeInstrument;
            }
            this.savePersistedData();
            this.logger.info(`✅ Orphaned position cleared successfully`);
        }
        catch (error) {
            this.logger.error('❌ Error clearing orphaned position:', error);
            throw error;
        }
    }
    ensureDataDirectory() {
        const dataDir = path.dirname(this.dataFilePath);
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
            this.logger.info(`📁 Created data directory: ${dataDir}`);
        }
    }
    loadPersistedData() {
        try {
            if (fs.existsSync(this.dataFilePath)) {
                const data = JSON.parse(fs.readFileSync(this.dataFilePath, 'utf8'));
                if (data.activePosition?.entryTime) {
                    data.activePosition.entryTime = new Date(data.activePosition.entryTime);
                }
                if (data.activePosition?.instrument?.expiry) {
                    data.activePosition.instrument.expiry = new Date(data.activePosition.instrument.expiry);
                }
                data.tradeHistory = data.tradeHistory?.map((trade) => ({
                    ...trade,
                    entryTime: new Date(trade.entryTime),
                    exitTime: trade.exitTime ? new Date(trade.exitTime) : undefined,
                    instrument: {
                        ...trade.instrument,
                        expiry: new Date(trade.instrument.expiry)
                    }
                })) || [];
                data.lastUpdated = new Date(data.lastUpdated);
                this.logger.info('📖 Loaded persisted trading data');
                return data;
            }
        }
        catch (error) {
            this.logger.error('❌ Error loading persisted data:', error);
        }
        const defaultData = {
            config: {
                capital: 200000,
                riskPerTrade: 0.03,
                maxRetries: 3,
                orderTimeout: 5000,
                paperTradingMode: true,
                niftyLotSize: 65
            },
            tradeHistory: [],
            lastUpdated: new Date()
        };
        this.savePersistedData(defaultData);
        this.logger.info('💾 Created default trading data');
        return defaultData;
    }
    savePersistedData(data) {
        try {
            const dataToSave = data || this.persistedData;
            dataToSave.lastUpdated = new Date();
            fs.writeFileSync(this.dataFilePath, JSON.stringify(dataToSave, null, 2));
            this.logger.info('💾 Saved trading data to disk');
        }
        catch (error) {
            this.logger.error('❌ Error saving persisted data:', error);
        }
    }
    async loadInstruments() {
        try {
            this.logger.info('📊 Loading NIFTY option instruments...');
            const allInstruments = await this.kiteConnect.getInstruments('NFO');
            this.niftyInstruments = allInstruments
                .filter((inst) => inst.name === 'NIFTY' &&
                (inst.instrument_type === 'CE' || inst.instrument_type === 'PE') &&
                inst.lot_size > 0)
                .map((inst) => ({
                instrument_token: inst.instrument_token,
                tradingsymbol: inst.tradingsymbol,
                name: inst.name,
                exchange: inst.exchange,
                strike: inst.strike,
                expiry: new Date(inst.expiry),
                instrument_type: inst.instrument_type,
                lot_size: inst.lot_size
            }));
            this.logger.info(`✅ Loaded ${this.niftyInstruments.length} NIFTY option instruments`);
        }
        catch (error) {
            this.logger.error('❌ Error loading instruments:', error);
            throw error;
        }
    }
    getNextTuesdayExpiry() {
        const today = new Date();
        const currentDay = today.getDay();
        const tuesday = 2;
        let daysToAdd = tuesday - currentDay;
        if (daysToAdd <= 0) {
            daysToAdd += 7;
        }
        const nextTuesday = new Date(today);
        nextTuesday.setDate(today.getDate() + daysToAdd);
        nextTuesday.setHours(15, 30, 0, 0);
        return nextTuesday;
    }
    findATMStrike(options, currentPrice) {
        if (options.length === 0) {
            throw new Error('No options available to find ATM strike');
        }
        let atmStrike = options[0].strike;
        let smallestDiff = Math.abs(options[0].strike - currentPrice);
        for (const option of options) {
            const diff = Math.abs(option.strike - currentPrice);
            if (diff < smallestDiff) {
                smallestDiff = diff;
                atmStrike = option.strike;
            }
        }
        this.logger.debug(`🎯 ATM Strike calculation: Price=${currentPrice}, ATM=${atmStrike}, Diff=${smallestDiff.toFixed(2)}`);
        return atmStrike;
    }
    async selectATMOption(direction, niftyPrice) {
        if (this.niftyInstruments.length === 0) {
            await this.loadInstruments();
        }
        const nextTuesdayExpiry = this.getNextTuesdayExpiry();
        const optionType = direction === 'LONG' ? 'CE' : 'PE';
        const targetPremium = niftyPrice * 0.01;
        this.logger.info(`🎯 Selecting ${optionType} option by PREMIUM for NIFTY price: ₹${niftyPrice}`);
        this.logger.info(`� Target Premium: ₹${targetPremium.toFixed(2)} (1% of futures price)`);
        this.logger.info(`�📅 Target expiry: ${nextTuesdayExpiry.toDateString()}`);
        let relevantOptions = this.niftyInstruments.filter(opt => {
            const isSameExpiry = opt.expiry.toDateString() === nextTuesdayExpiry.toDateString();
            return isSameExpiry && opt.instrument_type === optionType;
        });
        if (relevantOptions.length === 0) {
            this.logger.warn(`⚠️ No exact expiry match for ${nextTuesdayExpiry.toDateString()}, trying ±1 day fallback...`);
            relevantOptions = this.niftyInstruments.filter(opt => {
                const daysDiff = Math.abs((opt.expiry.getTime() - nextTuesdayExpiry.getTime()) / (24 * 60 * 60 * 1000));
                return daysDiff <= 1 && opt.instrument_type === optionType;
            });
            if (relevantOptions.length > 0) {
                this.logger.info(`✅ Fallback found ${relevantOptions.length} options within ±1 day`);
            }
        }
        if (relevantOptions.length === 0) {
            throw new Error(`No ${optionType} options found for expiry ${nextTuesdayExpiry.toDateString()} or nearby dates`);
        }
        this.logger.info(`📋 Found ${relevantOptions.length} ${optionType} options, fetching live prices...`);
        const atmStrike = this.findATMStrike(relevantOptions, niftyPrice);
        const strikeRange = 25;
        const minStrike = atmStrike - (strikeRange * 50);
        const maxStrike = atmStrike + (strikeRange * 50);
        const selectedOptions = relevantOptions.filter(opt => opt.strike >= minStrike && opt.strike <= maxStrike);
        this.logger.info(`🎯 ATM Strike: ₹${atmStrike} | Range: ₹${minStrike}-₹${maxStrike} | Selected: ${selectedOptions.length} options`);
        const symbols = selectedOptions.map(opt => `NFO:${opt.tradingsymbol}`);
        const optionsWithPremiums = [];
        try {
            const quotes = await this.kiteConnect.getQuote(symbols);
            for (const option of selectedOptions) {
                const symbol = `NFO:${option.tradingsymbol}`;
                const quote = quotes[symbol];
                if (quote && quote.last_price > 0) {
                    optionsWithPremiums.push({
                        option: option,
                        premium: quote.last_price
                    });
                }
            }
            this.logger.info(`✅ Fetched prices for ${optionsWithPremiums.length}/${selectedOptions.length} options`);
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            this.logger.error(`❌ Error fetching option prices: ${errorMessage}`);
        }
        if (optionsWithPremiums.length === 0) {
            this.logger.error('❌ No option prices available, falling back to ATM selection');
            const atmOption = relevantOptions.reduce((closest, current) => {
                const closestDiff = Math.abs(closest.strike - niftyPrice);
                const currentDiff = Math.abs(current.strike - niftyPrice);
                return currentDiff < closestDiff ? current : closest;
            });
            this.logger.info(`✅ Fallback ATM Option: ${atmOption.tradingsymbol} | Strike: ₹${atmOption.strike}`);
            return atmOption;
        }
        const bestOption = optionsWithPremiums.reduce((closest, current) => {
            const closestDiff = Math.abs(closest.premium - targetPremium);
            const currentDiff = Math.abs(current.premium - targetPremium);
            return currentDiff < closestDiff ? current : closest;
        });
        const premiumDifference = Math.abs(bestOption.premium - targetPremium);
        const premiumAccuracy = ((targetPremium - premiumDifference) / targetPremium * 100);
        this.logger.info(`✅ Selected Premium-Based Option: ${bestOption.option.tradingsymbol}`);
        this.logger.info(`   📊 Strike: ₹${bestOption.option.strike} | Premium: ₹${bestOption.premium.toFixed(2)}`);
        this.logger.info(`   🎯 Target: ₹${targetPremium.toFixed(2)} | Difference: ₹${premiumDifference.toFixed(2)} | Accuracy: ${premiumAccuracy.toFixed(1)}%`);
        return bestOption.option;
    }
    calculatePositionSize(stopLossPoints, optionPrice) {
        const { capital, riskPerTrade, niftyLotSize } = this.persistedData.config;
        const maxRiskAmount = capital * riskPerTrade;
        const riskPerLot = stopLossPoints * niftyLotSize;
        const maxLotsByRisk = Math.floor(maxRiskAmount / riskPerLot);
        const costPerLot = optionPrice * niftyLotSize;
        const maxLotsByCapital = Math.floor(capital / costPerLot);
        const finalLots = Math.min(maxLotsByRisk, maxLotsByCapital);
        this.logger.info(`📊 Position Sizing Calculation:`);
        this.logger.info(`   💰 Capital: ₹${capital.toLocaleString()}`);
        this.logger.info(`   🎯 Risk per trade: ${(riskPerTrade * 100).toFixed(1)}% = ₹${maxRiskAmount.toLocaleString()}`);
        this.logger.info(`   📉 SL Points: ${stopLossPoints}`);
        this.logger.info(`   💵 Option Price: ₹${optionPrice}`);
        this.logger.info(`   📊 Risk per lot: ₹${riskPerLot.toFixed(2)}`);
        this.logger.info(`   💰 Cost per lot: ₹${costPerLot.toFixed(2)}`);
        this.logger.info(`   🎲 Max lots (risk): ${maxLotsByRisk}`);
        this.logger.info(`   💸 Max lots (capital): ${maxLotsByCapital}`);
        this.logger.info(`   ✅ Final lots: ${finalLots} (minimum of constraints)`);
        return Math.max(1, finalLots);
    }
    async placeMarketOrder(tradeSetup) {
        try {
            this.logger.info('🚀 =================== TRADE ENTRY ===================');
            this.logger.info(`📊 Trade Setup: ${tradeSetup.direction} | Entry: ₹${tradeSetup.entryLevel} | SL: ₹${tradeSetup.stopLossLevel} | Target: ₹${tradeSetup.targetLevel}`);
            if (this.persistedData.activePosition) {
                throw new Error(`Cannot place new order - active position exists: ${this.persistedData.activePosition.tradeId}`);
            }
            const minCapitalRequired = 10000;
            if (this.persistedData.config.capital < minCapitalRequired) {
                throw new Error(`Insufficient capital: ₹${this.persistedData.config.capital.toLocaleString()} < ₹${minCapitalRequired.toLocaleString()}`);
            }
            let selectedOption;
            if (this.persistedData.activeInstrument &&
                this.persistedData.activeInstrument.direction === tradeSetup.direction) {
                selectedOption = this.persistedData.activeInstrument;
                this.logger.info(`🔄 Using previously selected option from breakout: ${selectedOption.tradingsymbol}`);
                this.logger.info(`   📊 Selected at breakout with futures price: ₹${this.persistedData.activeInstrument.underlyingPrice}`);
            }
            else {
                this.logger.warn('⚠️ No option pre-selected at breakout, selecting now...');
                selectedOption = await this.selectATMOption(tradeSetup.direction, tradeSetup.underlyingPrice);
            }
            const optionPrice = await this.getOptionPrice(selectedOption);
            const stopLossPoints = Math.abs(tradeSetup.entryLevel - tradeSetup.stopLossLevel);
            const lotSize = this.calculatePositionSize(stopLossPoints, optionPrice);
            const quantity = lotSize * this.persistedData.config.niftyLotSize;
            const estimatedTradeCost = optionPrice * quantity;
            this.logger.info(`💰 Final Trade Cost: ₹${estimatedTradeCost.toLocaleString()} (${((estimatedTradeCost / this.persistedData.config.capital) * 100).toFixed(1)}% of capital)`);
            const tradeId = `TRADE_${Date.now()}`;
            if (this.persistedData.config.paperTradingMode) {
                this.logger.info('📝 PAPER TRADING MODE - Simulating order placement');
                const simulatedOrderId = `PAPER_${Date.now()}`;
                const targetDistance = Math.abs(tradeSetup.targetLevel - optionPrice);
                const trailingTriggerDistance = targetDistance * 0.60;
                const trailingTrigger = tradeSetup.direction === 'LONG'
                    ? optionPrice + trailingTriggerDistance
                    : optionPrice - trailingTriggerDistance;
                this.persistedData.activePosition = {
                    tradeId,
                    entryOrderId: simulatedOrderId,
                    instrument: selectedOption,
                    direction: tradeSetup.direction,
                    quantity,
                    entryPrice: optionPrice,
                    entryTime: new Date(),
                    stopLoss: tradeSetup.stopLossLevel,
                    target: tradeSetup.targetLevel,
                    originalStopLoss: tradeSetup.stopLossLevel,
                    isTrailingActive: false,
                    trailingTrigger: trailingTrigger
                };
                this.savePersistedData();
                this.logger.info(`✅ Paper trade placed successfully`);
                this.logger.info(`   📋 Trade ID: ${tradeId}`);
                this.logger.info(`   🎫 Order ID: ${simulatedOrderId}`);
                this.logger.info(`   📊 Instrument: ${selectedOption.tradingsymbol}`);
                this.logger.info(`   🎲 Quantity: ${quantity} (${lotSize} lots)`);
                this.logger.info(`   💰 Entry Price: ₹${optionPrice}`);
                return tradeId;
            }
            else {
                const orderParams = {
                    exchange: selectedOption.exchange,
                    tradingsymbol: selectedOption.tradingsymbol,
                    transaction_type: 'BUY',
                    quantity: quantity,
                    order_type: 'MARKET',
                    product: 'MIS',
                    validity: 'DAY',
                    tag: 'BP_TRADE'
                };
                this.logger.info('📤 Placing real market order...');
                this.logger.info(`   Order params: ${JSON.stringify(orderParams, null, 2)}`);
                const orderResponse = await this.kiteConnect.placeOrder('regular', orderParams);
                const orderId = orderResponse.order_id;
                await this.waitForOrderConfirmation(orderId);
                const actualEntryPrice = await this.getActualFillPrice(orderId);
                const actualQuantity = await this.getActualFillQuantity(orderId);
                if (actualQuantity < quantity) {
                    this.logger.warn(`⚠️ Partial fill detected: ${actualQuantity}/${quantity} filled`);
                    this.logger.info(`📊 Adjusting position size to actual filled quantity`);
                }
                else if (actualQuantity === quantity) {
                    this.logger.info(`✅ Complete fill: ${actualQuantity} units executed`);
                }
                this.logger.info(`💰 Actual entry price: ₹${actualEntryPrice} (vs quote: ₹${optionPrice})`);
                const targetDistance = Math.abs(tradeSetup.targetLevel - actualEntryPrice);
                const trailingTriggerDistance = targetDistance * 0.60;
                const trailingTrigger = tradeSetup.direction === 'LONG'
                    ? actualEntryPrice + trailingTriggerDistance
                    : actualEntryPrice - trailingTriggerDistance;
                this.persistedData.activePosition = {
                    tradeId,
                    entryOrderId: orderId,
                    instrument: selectedOption,
                    direction: tradeSetup.direction,
                    quantity: actualQuantity,
                    entryPrice: actualEntryPrice,
                    entryTime: new Date(),
                    stopLoss: tradeSetup.stopLossLevel,
                    target: tradeSetup.targetLevel,
                    originalStopLoss: tradeSetup.stopLossLevel,
                    isTrailingActive: false,
                    trailingTrigger: trailingTrigger
                };
                this.savePersistedData();
                await this.syncWithBrokerState();
                this.logger.info(`✅ Real order placed successfully`);
                this.logger.info(`   📋 Trade ID: ${tradeId}`);
                this.logger.info(`   🎫 Zerodha Order ID: ${orderId}`);
                this.logger.info(`   📊 Instrument: ${selectedOption.tradingsymbol}`);
                this.logger.info(`   🎲 Quantity: ${actualQuantity} (${Math.round(actualQuantity / this.persistedData.config.niftyLotSize)} lots)`);
                return tradeId;
            }
        }
        catch (error) {
            this.logger.error('❌ Error placing market order:', error);
            throw error;
        }
    }
    async closePosition(tradeId, exitReason = 'MANUAL') {
        try {
            this.logger.info('🔚 =================== TRADE EXIT ===================');
            this.logger.info(`📋 Closing position: ${tradeId} | Reason: ${exitReason}`);
            if (!this.persistedData.activePosition || this.persistedData.activePosition.tradeId !== tradeId) {
                throw new Error(`No active position found for trade ID: ${tradeId}`);
            }
            const position = this.persistedData.activePosition;
            if (this.persistedData.config.paperTradingMode) {
                const currentPrice = await this.getOptionPrice(position.instrument);
                const pnl = this.calculatePnL(position, currentPrice);
                this.logger.info(`📝 Paper Trade P&L: ₹${pnl > 0 ? '+' : ''}${pnl.toLocaleString()} (not affecting real capital)`);
                const tradeRecord = {
                    tradeId: position.tradeId,
                    entryOrderId: position.entryOrderId,
                    exitOrderId: `PAPER_EXIT_${Date.now()}`,
                    instrument: position.instrument,
                    direction: position.direction,
                    quantity: position.quantity,
                    entryPrice: position.entryPrice,
                    exitPrice: currentPrice,
                    entryTime: position.entryTime,
                    exitTime: new Date(),
                    pnl,
                    exitReason,
                    status: 'CLOSED',
                    isPaperTrade: true
                };
                this.persistedData.tradeHistory.push(tradeRecord);
                delete this.persistedData.activePosition;
                this.clearOptionPriceCache();
                this.savePersistedData();
                this.logger.info(`✅ Paper position closed successfully`);
                this.logger.info(`   💰 Exit Price: ₹${currentPrice}`);
                this.logger.info(`   📈 Simulated P&L: ₹${pnl > 0 ? '+' : ''}${pnl.toLocaleString()} (paper only)`);
                this.logger.info(`   💰 Real Capital Unchanged: ₹${this.persistedData.config.capital.toLocaleString()}`);
            }
            else {
                const closeOrderParams = {
                    exchange: position.instrument.exchange,
                    tradingsymbol: position.instrument.tradingsymbol,
                    transaction_type: 'SELL',
                    quantity: position.quantity,
                    order_type: 'MARKET',
                    product: 'MIS',
                    validity: 'DAY',
                    tag: 'BP_TRADE'
                };
                const closeOrderResponse = await this.kiteConnect.placeOrder('regular', closeOrderParams);
                const closeOrderId = closeOrderResponse.order_id;
                await this.waitForOrderConfirmation(closeOrderId);
                const exitPrice = await this.getActualFillPrice(closeOrderId);
                const pnl = this.calculatePnL(position, exitPrice);
                this.updateCapitalAfterTrade(pnl);
                const tradeRecord = {
                    tradeId: position.tradeId,
                    entryOrderId: position.entryOrderId,
                    exitOrderId: closeOrderId,
                    instrument: position.instrument,
                    direction: position.direction,
                    quantity: position.quantity,
                    entryPrice: position.entryPrice,
                    exitPrice,
                    entryTime: position.entryTime,
                    exitTime: new Date(),
                    pnl,
                    exitReason,
                    status: 'CLOSED',
                    isPaperTrade: false
                };
                this.persistedData.tradeHistory.push(tradeRecord);
                delete this.persistedData.activePosition;
                this.clearOptionPriceCache();
                this.savePersistedData();
                this.logger.info(`✅ Real position closed successfully`);
                this.logger.info(`   🎫 Exit Order ID: ${closeOrderId}`);
                this.logger.info(`   💰 Exit Price: ₹${exitPrice}`);
                this.logger.info(`   📈 P&L: ₹${pnl > 0 ? '+' : ''}${pnl.toLocaleString()}`);
                this.logger.info(`   💰 New Capital: ₹${this.persistedData.config.capital.toLocaleString()}`);
            }
        }
        catch (error) {
            this.logger.error('❌ Error closing position:', error);
            throw error;
        }
    }
    async verifyBrokerPosition(instrument, expectedQuantity) {
        try {
            if (this.persistedData.config.paperTradingMode) {
                this.logger.info('📝 Paper trading mode - skipping broker position verification');
                return true;
            }
            const positions = await this.kiteConnect.getPositions();
            const netPositions = positions.net || [];
            const matchingPosition = netPositions.find((pos) => pos.tradingsymbol === instrument.tradingsymbol &&
                pos.exchange === instrument.exchange);
            if (!matchingPosition) {
                this.logger.warn(`⚠️ No position found in Zerodha for ${instrument.tradingsymbol}`);
                return false;
            }
            const brokerQuantity = Math.abs(matchingPosition.quantity);
            if (brokerQuantity !== expectedQuantity) {
                this.logger.warn(`⚠️ Position size mismatch: System=${expectedQuantity}, Zerodha=${brokerQuantity}`);
                return false;
            }
            this.logger.info(`✅ Position verified: ${instrument.tradingsymbol} = ${brokerQuantity} units`);
            return true;
        }
        catch (error) {
            this.logger.error(`❌ Error verifying broker position:`, error);
            return false;
        }
    }
    async syncWithBrokerState() {
        try {
            if (this.persistedData.config.paperTradingMode) {
                this.logger.info('📝 Paper trading mode - skipping broker sync');
                return;
            }
            if (!this.persistedData.activePosition) {
                this.logger.info('📋 No active position to sync');
                return;
            }
            const position = this.persistedData.activePosition;
            const isVerified = await this.verifyBrokerPosition(position.instrument, position.quantity);
            if (!isVerified) {
                this.logger.warn('⚠️ Position mismatch detected with broker - manual intervention may be required');
            }
        }
        catch (error) {
            this.logger.error('❌ Error syncing with broker state:', error);
        }
    }
    async getOptionPrice(option) {
        try {
            if (this.persistedData.config.paperTradingMode) {
                const basePrice = option.instrument_type === 'CE' ? 120 : 80;
                const volatility = 0.2;
                const randomFactor = 1 + (Math.random() - 0.5) * volatility;
                return Math.round(basePrice * randomFactor * 100) / 100;
            }
            else {
                const quote = await this.kiteConnect.getQuote([`${option.exchange}:${option.tradingsymbol}`]);
                const optionQuote = quote[`${option.exchange}:${option.tradingsymbol}`];
                return optionQuote.last_price;
            }
        }
        catch (error) {
            this.logger.error(`❌ Error getting option price for ${option.tradingsymbol}:`, error);
            throw error;
        }
    }
    async waitForOrderConfirmation(orderId) {
        const maxRetries = 10;
        const retryInterval = 1000;
        for (let i = 0; i < maxRetries; i++) {
            try {
                const orderDetails = await this.kiteConnect.getOrderHistory(orderId);
                const latestOrder = orderDetails[orderDetails.length - 1];
                if (latestOrder.status === 'COMPLETE') {
                    this.logger.info(`✅ Order ${orderId} confirmed as COMPLETE`);
                    return;
                }
                else if (latestOrder.status === 'REJECTED') {
                    const rejectionReason = latestOrder.status_message || 'Unknown rejection reason';
                    this.logger.error(`❌ Order ${orderId} REJECTED: ${rejectionReason}`);
                    if (rejectionReason.toLowerCase().includes('margin') ||
                        rejectionReason.toLowerCase().includes('limit') ||
                        rejectionReason.toLowerCase().includes('fund')) {
                        this.logger.error(`💰 Margin/Fund related rejection - cannot retry automatically`);
                        throw new Error(`Order rejected due to insufficient funds: ${rejectionReason}`);
                    }
                    else {
                        this.logger.warn(`⚠️ Non-margin rejection: ${rejectionReason} - could be temporary`);
                        throw new Error(`Order rejected: ${rejectionReason}`);
                    }
                }
                else if (latestOrder.status === 'CANCELLED') {
                    throw new Error(`Order ${orderId} was CANCELLED: ${latestOrder.status_message}`);
                }
                this.logger.info(`⏳ Order ${orderId} status: ${latestOrder.status}, retrying in ${retryInterval}ms...`);
                await new Promise(resolve => setTimeout(resolve, retryInterval));
            }
            catch (error) {
                if (i === maxRetries - 1) {
                    throw new Error(`Order confirmation timeout for ${orderId}: ${error}`);
                }
            }
        }
    }
    async getActualFillPrice(orderId) {
        try {
            const orderDetails = await this.kiteConnect.getOrderHistory(orderId);
            const completedOrder = orderDetails.find((order) => order.status === 'COMPLETE');
            return completedOrder?.average_price || completedOrder?.price || 0;
        }
        catch (error) {
            this.logger.error(`❌ Error getting fill price for order ${orderId}:`, error);
            return 0;
        }
    }
    async getActualFillQuantity(orderId) {
        try {
            const orderDetails = await this.kiteConnect.getOrderHistory(orderId);
            const completedOrder = orderDetails.find((order) => order.status === 'COMPLETE');
            return completedOrder?.filled_quantity || 0;
        }
        catch (error) {
            this.logger.error(`❌ Error getting fill quantity for order ${orderId}:`, error);
            return 0;
        }
    }
    calculatePnL(position, exitPrice) {
        const { entryPrice, quantity, direction } = position;
        const pnl = (exitPrice - entryPrice) * quantity;
        this.logger.info(`📊 P&L Calculation:`, {
            direction: direction,
            entryPrice: `₹${entryPrice}`,
            exitPrice: `₹${exitPrice}`,
            quantity: quantity,
            priceChange: `₹${(exitPrice - entryPrice).toFixed(2)}`,
            pnl: `₹${pnl > 0 ? '+' : ''}${pnl.toFixed(2)}`,
            result: pnl > 0 ? 'PROFIT' : pnl < 0 ? 'LOSS' : 'BREAKEVEN'
        });
        return pnl;
    }
    updateCapitalAfterTrade(pnl) {
        this.persistedData.config.capital += pnl;
        this.logger.info(`💰 Capital updated: ${pnl > 0 ? '+' : ''}₹${pnl.toLocaleString()} → ₹${this.persistedData.config.capital.toLocaleString()}`);
    }
    getCurrentCapital() {
        return this.persistedData.config.capital;
    }
    getActivePosition() {
        return this.persistedData.activePosition;
    }
    updateStopLossToCost(entryPrice) {
        if (!this.persistedData.activePosition) {
            this.logger.warn('⚠️ Cannot update SL to cost - no active position');
            return;
        }
        const position = this.persistedData.activePosition;
        if (!position.originalStopLoss) {
            position.originalStopLoss = position.stopLoss;
        }
        const previousSL = position.stopLoss;
        position.stopLoss = entryPrice;
        position.isTrailingActive = true;
        position.trailedAt = new Date();
        this.savePersistedData();
        this.logger.info(`✅ STOP LOSS MOVED TO COST`);
        this.logger.info(`   Previous SL: ₹${previousSL.toFixed(2)} → New SL: ₹${entryPrice.toFixed(2)}`);
        this.logger.info(`   Trade now protected - minimum result: BREAKEVEN`);
    }
    getDetailedPosition() {
        const position = this.persistedData.activePosition;
        if (!position)
            return null;
        const now = new Date();
        const entryTime = new Date(position.entryTime);
        const minutesSinceEntry = Math.floor((now.getTime() - entryTime.getTime()) / 60000);
        const cachedPrice = this.getCachedOptionPrice();
        let currentLTP = null;
        let currentLTPTimestamp = null;
        let unrealizedPnL = null;
        let percentChange = null;
        let secondsSinceLastUpdate = null;
        if (cachedPrice) {
            currentLTP = cachedPrice.price;
            currentLTPTimestamp = cachedPrice.timestamp;
            unrealizedPnL = (currentLTP - position.entryPrice) * position.quantity;
            percentChange = ((currentLTP - position.entryPrice) / position.entryPrice) * 100;
            secondsSinceLastUpdate = Math.floor((now.getTime() - currentLTPTimestamp.getTime()) / 1000);
        }
        return {
            tradeId: position.tradeId,
            direction: position.direction,
            instrument: position.instrument.tradingsymbol,
            strikePrice: position.instrument.strike,
            entryPrice: position.entryPrice,
            quantity: position.quantity,
            entryTime: entryTime,
            entryOrderId: position.entryOrderId,
            stopLoss: position.stopLoss,
            target: position.target,
            currentLTP,
            currentLTPTimestamp,
            unrealizedPnL,
            percentChange,
            minutesSinceEntry,
            secondsSinceLastUpdate,
            isActive: true
        };
    }
    getTradeHistory() {
        return this.persistedData.tradeHistory;
    }
    getTradingConfig() {
        return this.persistedData.config;
    }
    updateTradingConfig(updates) {
        this.persistedData.config = { ...this.persistedData.config, ...updates };
        this.savePersistedData();
        this.logger.info('⚙️ Trading configuration updated');
    }
    getExecutionStatus() {
        return {
            hasActivePosition: !!this.persistedData.activePosition,
            currentCapital: this.persistedData.config.capital,
            totalTrades: this.persistedData.tradeHistory.length,
            paperTradingMode: this.persistedData.config.paperTradingMode
        };
    }
    updateOptionPrice(price) {
        this.cachedOptionPrice = price;
        this.cachedOptionTimestamp = new Date();
    }
    getCachedOptionPrice() {
        if (this.cachedOptionPrice === null || this.cachedOptionTimestamp === null) {
            return null;
        }
        return {
            price: this.cachedOptionPrice,
            timestamp: this.cachedOptionTimestamp
        };
    }
    clearOptionPriceCache() {
        this.cachedOptionPrice = null;
        this.cachedOptionTimestamp = null;
    }
    async getOptionPriceByToken(instrumentToken) {
        try {
            const tokenNumber = parseInt(instrumentToken, 10);
            const quotes = await this.kiteConnect.getQuote([tokenNumber]);
            const quote = quotes[tokenNumber];
            if (!quote) {
                throw new Error(`No quote data found for token: ${instrumentToken}`);
            }
            return quote.last_price || 0;
        }
        catch (error) {
            this.logger.error(`Error fetching option price for token ${instrumentToken}:`, error);
            throw error;
        }
    }
    getInstrumentsStatus() {
        const loaded = this.niftyInstruments.length > 0;
        const result = {
            loaded: loaded,
            count: this.niftyInstruments.length
        };
        if (loaded) {
            result.loadedAt = new Date();
            result.sampleInstruments = this.niftyInstruments.slice(0, 5);
        }
        return result;
    }
    async onBreakoutDetected(direction, underlyingPrice, timestamp) {
        try {
            this.logger.info(`🎯 Breakout detected - Auto-selecting ${direction} option by premium for price: ₹${underlyingPrice}`);
            const selectedOption = await this.selectATMOption(direction, underlyingPrice);
            this.persistedData.activeInstrument = {
                ...selectedOption,
                selectedAt: timestamp,
                direction: direction,
                underlyingPrice: underlyingPrice
            };
            this.savePersistedData();
            this.logger.info(`✅ Premium-based Option auto-selected: ${selectedOption.tradingsymbol}`);
            this.logger.info(`   📊 Strike: ₹${selectedOption.strike} | Token: ${selectedOption.instrument_token}`);
            this.logger.info(`   💰 Selected with target premium: ₹${(underlyingPrice * 0.01).toFixed(2)} (1% of futures)`);
        }
        catch (error) {
            this.logger.error(`❌ Failed to auto-select option by premium after breakout:`, error);
        }
    }
    getSelectedInstrument() {
        return this.persistedData.activeInstrument || null;
    }
}
exports.TradeExecutionService = TradeExecutionService;
//# sourceMappingURL=BreakoutPullbackExecutor.js.map