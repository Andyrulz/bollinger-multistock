declare class TradingBot {
    private kiteConnect;
    private authService;
    private quoteManager;
    private strategyManager;
    private logger;
    private app;
    private basePath;
    constructor();
    private setupRoutes;
    start(): Promise<void>;
    stop(): Promise<void>;
    gracefulShutdown(): Promise<void>;
}
export { TradingBot };
//# sourceMappingURL=index.d.ts.map