import { Logger } from '../utils/Logger';
import { SessionData } from './AuthService';
export interface PersistedSession {
    accessToken: string;
    sessionData: SessionData;
    expiryTime: Date;
    createdAt: Date;
    lastValidated: Date;
}
export declare class SessionPersistence {
    private readonly sessionFilePath;
    private readonly logger;
    private readonly encryptionKey;
    constructor(logger: Logger);
    private ensureSessionDirectory;
    private encryptSessionData;
    private decryptSessionData;
    saveSession(accessToken: string, sessionData: SessionData): Promise<void>;
    loadSession(): Promise<PersistedSession | null>;
    clearSession(): Promise<void>;
    hasValidSession(): Promise<boolean>;
    getSessionInfo(): Promise<{
        exists: boolean;
        expiresAt?: Date;
        createdAt?: Date;
    }>;
}
//# sourceMappingURL=SessionPersistence.d.ts.map