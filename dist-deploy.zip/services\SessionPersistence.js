"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionPersistence = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const crypto = __importStar(require("crypto"));
class SessionPersistence {
    constructor(logger) {
        this.logger = logger;
        this.sessionFilePath = path.join(__dirname, '../../data/auth/session.json');
        const apiKey = process.env.ZERODHA_API_KEY || '';
        const apiSecret = process.env.ZERODHA_API_SECRET || '';
        this.encryptionKey = crypto.createHash('sha256')
            .update(apiKey + apiSecret + 'trading_bot_session_key')
            .digest('hex');
        this.ensureSessionDirectory();
    }
    ensureSessionDirectory() {
        const sessionDir = path.dirname(this.sessionFilePath);
        if (!fs.existsSync(sessionDir)) {
            fs.mkdirSync(sessionDir, { recursive: true, mode: 0o700 });
            this.logger.info('📁 Created secure session directory');
        }
    }
    encryptSessionData(sessionData) {
        const iv = crypto.randomBytes(16);
        const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(this.encryptionKey.slice(0, 32)), iv);
        let encrypted = cipher.update(JSON.stringify(sessionData), 'utf8', 'hex');
        encrypted += cipher.final('hex');
        return {
            data: encrypted,
            iv: iv.toString('hex'),
            timestamp: new Date().toISOString()
        };
    }
    decryptSessionData(encryptedFile) {
        try {
            const iv = Buffer.from(encryptedFile.iv, 'hex');
            const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(this.encryptionKey.slice(0, 32)), iv);
            let decrypted = decipher.update(encryptedFile.data, 'hex', 'utf8');
            decrypted += decipher.final('utf8');
            const sessionData = JSON.parse(decrypted);
            sessionData.expiryTime = new Date(sessionData.expiryTime);
            sessionData.createdAt = new Date(sessionData.createdAt);
            sessionData.lastValidated = new Date(sessionData.lastValidated);
            return sessionData;
        }
        catch (error) {
            this.logger.error('❌ Failed to decrypt session data:', error);
            return null;
        }
    }
    async saveSession(accessToken, sessionData) {
        try {
            const now = new Date();
            const tomorrow = new Date(now);
            tomorrow.setDate(tomorrow.getDate() + 1);
            tomorrow.setHours(6, 0, 0, 0);
            const persistedSession = {
                accessToken,
                sessionData,
                expiryTime: tomorrow,
                createdAt: now,
                lastValidated: now
            };
            const encryptedData = this.encryptSessionData(persistedSession);
            fs.writeFileSync(this.sessionFilePath, JSON.stringify(encryptedData, null, 2), {
                mode: 0o600
            });
            this.logger.info(`💾 Session saved securely - expires at ${tomorrow.toLocaleString()}`);
        }
        catch (error) {
            this.logger.error('❌ Failed to save session:', error);
            throw error;
        }
    }
    async loadSession() {
        try {
            if (!fs.existsSync(this.sessionFilePath)) {
                this.logger.debug('📂 No saved session found');
                return null;
            }
            const fileContent = fs.readFileSync(this.sessionFilePath, 'utf8');
            const encryptedFile = JSON.parse(fileContent);
            const session = this.decryptSessionData(encryptedFile);
            if (!session) {
                this.logger.warn('⚠️ Failed to decrypt saved session');
                await this.clearSession();
                return null;
            }
            const now = new Date();
            if (now > session.expiryTime) {
                this.logger.info('⏰ Saved session has expired - clearing');
                await this.clearSession();
                return null;
            }
            session.lastValidated = now;
            this.logger.info(`🔑 Loaded valid session - expires at ${session.expiryTime.toLocaleString()}`);
            return session;
        }
        catch (error) {
            this.logger.error('❌ Failed to load session:', error);
            await this.clearSession();
            return null;
        }
    }
    async clearSession() {
        try {
            if (fs.existsSync(this.sessionFilePath)) {
                fs.unlinkSync(this.sessionFilePath);
                this.logger.info('🗑️ Session cleared');
            }
        }
        catch (error) {
            this.logger.error('❌ Failed to clear session:', error);
        }
    }
    async hasValidSession() {
        const session = await this.loadSession();
        return session !== null;
    }
    async getSessionInfo() {
        const session = await this.loadSession();
        if (!session) {
            return { exists: false };
        }
        return {
            exists: true,
            expiresAt: session.expiryTime,
            createdAt: session.createdAt
        };
    }
}
exports.SessionPersistence = SessionPersistence;
//# sourceMappingURL=SessionPersistence.js.map