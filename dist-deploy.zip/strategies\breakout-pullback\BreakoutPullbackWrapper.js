"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BreakoutPullbackWrapper = void 0;
const StrategyBase_1 = require("../../core/StrategyBase");
const BreakoutPullbackStrategy_1 = require("./BreakoutPullbackStrategy");
class BreakoutPullbackWrapper extends StrategyBase_1.StrategyBase {
    constructor(kiteConnect, logger, config) {
        super(kiteConnect, logger, config);
        this.coreStrategy = new BreakoutPullbackStrategy_1.BreakoutPullbackStrategy(kiteConnect, logger);
    }
    async initialize() {
        try {
            this.logStrategyEvent('info', 'Initializing Breakout Pullback Strategy');
            this.setHealthStatus('healthy');
            this._isInitialized = true;
            this.logStrategyEvent('info', 'Strategy initialized successfully');
        }
        catch (error) {
            this.logStrategyEvent('error', 'Failed to initialize strategy', error);
            this.setHealthStatus('error');
            throw error;
        }
    }
    async start() {
        try {
            if (!this._isInitialized) {
                await this.initialize();
            }
            this.logStrategyEvent('info', 'Starting strategy');
            await this.coreStrategy.startStrategy();
            this.updateMetrics({
                isActive: true,
                isStreaming: true,
                healthStatus: 'healthy'
            });
            this.logStrategyEvent('info', 'Strategy started successfully');
        }
        catch (error) {
            this.logStrategyEvent('error', 'Failed to start strategy', error);
            this.setHealthStatus('error');
            throw error;
        }
    }
    async stop() {
        try {
            this.logStrategyEvent('info', 'Stopping strategy');
            await this.coreStrategy.stopStrategy();
            this.updateMetrics({
                isActive: false,
                isStreaming: false,
                healthStatus: 'stopped'
            });
            this.logStrategyEvent('info', 'Strategy stopped successfully');
        }
        catch (error) {
            this.logStrategyEvent('error', 'Failed to stop strategy', error);
            this.setHealthStatus('error');
            throw error;
        }
    }
    getStatus() {
        const coreStatus = this.coreStrategy.getStrategyState();
        const tradeHistory = this.coreStrategy.getTradeExecutionService().getTradeHistory();
        const activePosition = this.coreStrategy.getTradeExecutionService().getActivePosition();
        return {
            config: this.getConfig(),
            metrics: {
                ...this.getMetrics(),
                isActive: coreStatus.isActive,
                isStreaming: coreStatus.priceStreamingActive,
                totalTrades: tradeHistory.length,
                profitLoss: this.calculateTotalPnL(tradeHistory),
                winRate: this.calculateWinRate(tradeHistory)
            },
            currentPosition: activePosition,
            recentTrades: tradeHistory.slice(-10)
        };
    }
    async processMarketData(data) {
        try {
            this.updateMetrics({ lastUpdateTime: new Date() });
        }
        catch (error) {
            this.logStrategyEvent('error', 'Error processing market data', error);
            this.metrics.errorCount++;
        }
    }
    calculateTotalPnL(trades) {
        return trades.reduce((total, trade) => {
            return total + (trade.realizedPnl || 0);
        }, 0);
    }
    calculateWinRate(trades) {
        if (trades.length === 0)
            return 0;
        const winningTrades = trades.filter(trade => (trade.realizedPnl || 0) > 0);
        return (winningTrades.length / trades.length) * 100;
    }
    getCoreStrategy() {
        return this.coreStrategy;
    }
}
exports.BreakoutPullbackWrapper = BreakoutPullbackWrapper;
//# sourceMappingURL=BreakoutPullbackWrapper.js.map