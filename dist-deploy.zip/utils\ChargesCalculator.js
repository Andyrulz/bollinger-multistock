"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calculateBuyCharges = calculateBuyCharges;
exports.calculateSellCharges = calculateSellCharges;
exports.calculateRoundTripCharges = calculateRoundTripCharges;
const BROKERAGE_PER_ORDER = 20;
const STT_OPTIONS_SELL_PCT = 0.15 / 100;
const NSE_TXN_CHARGE_PCT = 0.03553 / 100;
const SEBI_CHARGE_PER_CRORE = 10;
const STAMP_DUTY_BUY_PCT = 0.003 / 100;
const IPFT_PER_CRORE = 0.01;
const GST_PCT = 18 / 100;
function round2(n) {
    return Math.round(n * 100) / 100;
}
function calculateBuyCharges(price, quantity) {
    const turnover = price * quantity;
    const brokerage = BROKERAGE_PER_ORDER;
    const stt = 0;
    const txnCharges = round2(turnover * NSE_TXN_CHARGE_PCT);
    const sebiCharges = round2(turnover * SEBI_CHARGE_PER_CRORE / 10000000);
    const stampDuty = round2(turnover * STAMP_DUTY_BUY_PCT);
    const ipft = round2(turnover * IPFT_PER_CRORE / 10000000);
    const gst = round2((brokerage + txnCharges + sebiCharges) * GST_PCT);
    const total = round2(brokerage + stt + txnCharges + sebiCharges + stampDuty + ipft + gst);
    return { brokerage: round2(brokerage), stt, txnCharges, sebiCharges, stampDuty, ipft, gst, total };
}
function calculateSellCharges(price, quantity) {
    const turnover = price * quantity;
    const brokerage = BROKERAGE_PER_ORDER;
    const stt = round2(turnover * STT_OPTIONS_SELL_PCT);
    const txnCharges = round2(turnover * NSE_TXN_CHARGE_PCT);
    const sebiCharges = round2(turnover * SEBI_CHARGE_PER_CRORE / 10000000);
    const stampDuty = 0;
    const ipft = round2(turnover * IPFT_PER_CRORE / 10000000);
    const gst = round2((brokerage + txnCharges + sebiCharges) * GST_PCT);
    const total = round2(brokerage + stt + txnCharges + sebiCharges + stampDuty + ipft + gst);
    return { brokerage: round2(brokerage), stt, txnCharges, sebiCharges, stampDuty, ipft, gst, total };
}
function calculateRoundTripCharges(buyPrice, sellPrice, quantity) {
    const buy = calculateBuyCharges(buyPrice, quantity);
    const sell = calculateSellCharges(sellPrice, quantity);
    return {
        buy,
        sell,
        totalCharges: round2(buy.total + sell.total),
    };
}
//# sourceMappingURL=ChargesCalculator.js.map