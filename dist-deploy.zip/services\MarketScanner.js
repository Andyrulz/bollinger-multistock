"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarketScanner = void 0;
const universe_1 = require("../config/universe");
const MAX_RISK_PERCENT = 1.5;
const MAX_BANDWIDTH_PERCENT = 3.5;
class MarketScanner {
    constructor(kiteConnect, logger, instrumentCache, config) {
        this.kiteConnect = kiteConnect;
        this.logger = logger;
        this.instrumentCache = instrumentCache;
        this.config = config;
        this.universe = universe_1.UNIVERSE;
        this.cachedHistoricalData = new Map();
        this.isDataCached = false;
        this.lastScannerRun = 0;
        this.SCANNER_COOLDOWN_MS = 10000;
        this.oiHistoryService = null;
        this.SEED_LOOKBACK_DAYS = 5;
        this.CANDLE_WINDOW = 375;
        this.FIVE_MIN_MS = 5 * 60 * 1000;
        this.formingCandle = new Map();
        this.candleStorePath = '';
        this.candlePollTimer = null;
        this.candlePollRunning = false;
        this.candleSeeded = false;
        this.lastPollSummary = { at: 0, updated: 0, total: 0 };
    }
    setOIHistoryService(service) {
        this.oiHistoryService = service;
        this.logger.info('📊 MarketScanner: OI History Service connected for Smart Money scoring');
    }
    async scanUniverse() {
        const startTime = Date.now();
        this.logger.info("🔍 MarketScanner: Starting universe scan...");
        try {
            if (await this.isStockTradingBlocked()) {
                this.logger.error("🚫 Stock options blocked (expiry week)");
                return this.emptyResult();
            }
            const sectorStatus = await this.analyzeSectors();
            const filteredStocks = this.filterBySector(sectorStatus);
            const scoredStocks = await this.scoreStocks(filteredStocks, sectorStatus);
            const safeStocks = this.applySafetyFilters(scoredStocks);
            const topStocks = await this.selectTopStocks(safeStocks, sectorStatus);
            const duration = ((Date.now() - startTime) / 1000).toFixed(1);
            this.logger.info(`✅ Scanner completed in ${duration}s: ${topStocks.length}/3 selected`);
            return {
                scanTime: new Date(),
                scannedCount: filteredStocks.length,
                qualifiedCount: safeStocks.length,
                selected: topStocks,
                allScored: scoredStocks,
                greenSectors: sectorStatus.green,
                redSectors: sectorStatus.red,
                flatSectors: sectorStatus.flat,
                failedStocks: [],
            };
        }
        catch (error) {
            this.logger.error("MarketScanner: Fatal error during scan:", error);
            return this.emptyResult();
        }
    }
    async cacheHistoricalData(lookbackDays = 10) {
        this.logger.info(`📥 MarketScanner: Pre-loading historical data (${lookbackDays} days, 5-min)...`);
        const startTime = Date.now();
        const timeSinceLastRun = Date.now() - this.lastScannerRun;
        if (this.lastScannerRun > 0 && timeSinceLastRun < this.SCANNER_COOLDOWN_MS) {
            const waitTime = Math.ceil((this.SCANNER_COOLDOWN_MS - timeSinceLastRun) / 1000);
            throw new Error(`⏳ Scanner cooldown: Please wait ${waitTime} seconds before running again`);
        }
        this.lastScannerRun = Date.now();
        try {
            this.logger.info("✅ Using instrument tokens from universe.ts (no API call needed)");
            this.logger.info(`📋 Universe contains ${this.universe.length} stocks with pre-loaded tokens`);
            this.logger.info(`📊 Starting historical data fetch for ${this.universe.length} stocks`);
            this.logger.info("📊 Zerodha Rate Limit: 3 historical data requests per second");
            this.logger.info(`📊 Strategy: Batch size of 2, with 1-second delay between batches`);
            this.logger.info(`📊 Expected Duration: ~${Math.ceil(this.universe.length / 2)} seconds`);
            const batchSize = 2;
            const delayBetweenBatches = 1000;
            const allResults = [];
            const totalBatches = Math.ceil(this.universe.length / batchSize);
            for (let i = 0; i < this.universe.length; i += batchSize) {
                const batch = this.universe.slice(i, i + batchSize);
                const currentBatch = Math.floor(i / batchSize) + 1;
                this.logger.info(`📥 Batch ${currentBatch}/${totalBatches}: Fetching ${batch.map(s => s.symbol).join(', ')}`);
                const batchStartTime = Date.now();
                const results = await Promise.allSettled(batch.map(async (stock) => {
                    try {
                        const instrumentToken = stock.instrumentToken;
                        if (!instrumentToken) {
                            this.logger.error(`  ✗ ${stock.symbol}: No instrument token (run 'npm run generate-universe' first)`);
                            return { symbol: stock.symbol, success: false };
                        }
                        const toDate = new Date();
                        const fromDate = new Date();
                        fromDate.setDate(fromDate.getDate() - lookbackDays);
                        const candleStartTime = Date.now();
                        const candles = await this.kiteConnect.getHistoricalData(instrumentToken, "5minute", fromDate, toDate);
                        const candleDuration = Date.now() - candleStartTime;
                        this.cachedHistoricalData.set(stock.symbol, candles);
                        this.logger.info(`  ✓ ${stock.symbol}: ${candles.length} candles in ${candleDuration}ms`);
                        return { symbol: stock.symbol, success: true };
                    }
                    catch (error) {
                        this.logger.error(`  ✗ ${stock.symbol}: ${error.message || JSON.stringify(error)}`);
                        return { symbol: stock.symbol, success: false };
                    }
                }));
                const batchDuration = Date.now() - batchStartTime;
                const batchSuccesses = results.filter(r => r.status === 'fulfilled' && r.value?.success).length;
                this.logger.info(`📊 Batch ${currentBatch} complete: ${batchSuccesses}/${batch.length} successful in ${batchDuration}ms`);
                allResults.push(...results);
                if (i + batchSize < this.universe.length) {
                    this.logger.info(`⏳ Waiting 1 second before next batch (rate limit compliance)...`);
                    await new Promise(resolve => setTimeout(resolve, delayBetweenBatches));
                }
            }
            this.logger.info(`📊 Step 2 Complete: All batches processed`);
            const failedStocks = [];
            for (const result of allResults) {
                if (result.status === 'rejected') {
                    failedStocks.push(result.reason?.symbol || 'unknown');
                }
                else if (result.status === 'fulfilled' && result.value && !result.value.success) {
                    failedStocks.push(result.value.symbol);
                }
            }
            for (const stock of this.universe) {
                if (!this.cachedHistoricalData.has(stock.symbol) && !failedStocks.includes(stock.symbol)) {
                    failedStocks.push(stock.symbol);
                }
            }
            if (failedStocks.length > 0) {
                this.logger.warn(`⚠️ ${failedStocks.length} stocks failed initial fetch: ${failedStocks.join(', ')}`);
                this.logger.info(`⏳ Waiting 5s cooldown before retry...`);
                await new Promise(resolve => setTimeout(resolve, 5000));
                const retryBatchSize = 2;
                const retryStocks = this.universe.filter(s => failedStocks.includes(s.symbol));
                const retryTotalBatches = Math.ceil(retryStocks.length / retryBatchSize);
                this.logger.info(`🔄 Retrying ${retryStocks.length} failed stocks in ${retryTotalBatches} batches...`);
                let retrySuccessCount = 0;
                let retryFailCount = 0;
                for (let i = 0; i < retryStocks.length; i += retryBatchSize) {
                    const batch = retryStocks.slice(i, i + retryBatchSize);
                    const currentBatch = Math.floor(i / retryBatchSize) + 1;
                    this.logger.info(`🔄 Retry batch ${currentBatch}/${retryTotalBatches}: ${batch.map(s => s.symbol).join(', ')}`);
                    const retryResults = await Promise.allSettled(batch.map(async (stock) => {
                        try {
                            const instrumentToken = stock.instrumentToken;
                            if (!instrumentToken) {
                                this.logger.error(`  ✗ ${stock.symbol}: No instrument token`);
                                return { symbol: stock.symbol, success: false };
                            }
                            const toDate = new Date();
                            const fromDate = new Date();
                            fromDate.setDate(fromDate.getDate() - lookbackDays);
                            const candleStartTime = Date.now();
                            const candles = await this.kiteConnect.getHistoricalData(instrumentToken, "5minute", fromDate, toDate);
                            const candleDuration = Date.now() - candleStartTime;
                            this.cachedHistoricalData.set(stock.symbol, candles);
                            this.logger.info(`  ✓ RETRY ${stock.symbol}: ${candles.length} candles in ${candleDuration}ms`);
                            return { symbol: stock.symbol, success: true };
                        }
                        catch (error) {
                            this.logger.error(`  🔴 FATAL: ${stock.symbol} failed retry — excluded from scan: ${error.message}`);
                            return { symbol: stock.symbol, success: false };
                        }
                    }));
                    for (const r of retryResults) {
                        if (r.status === 'fulfilled' && r.value?.success) {
                            retrySuccessCount++;
                        }
                        else {
                            retryFailCount++;
                        }
                    }
                    if (i + retryBatchSize < retryStocks.length) {
                        await new Promise(resolve => setTimeout(resolve, delayBetweenBatches));
                    }
                }
                this.logger.info(`🔄 Retry complete: ${retrySuccessCount} recovered, ${retryFailCount} permanently failed`);
            }
            const successful = this.cachedHistoricalData.size;
            const failed = this.universe.filter(s => !this.cachedHistoricalData.has(s.symbol));
            this.logger.info(`📊 Summary: ${successful} successful, ${failed.length} failed out of ${this.universe.length} total`);
            const failureRate = failed.length / this.universe.length;
            if (failureRate > 0.2) {
                this.logger.error(`❌ ABORT: Data cache failure rate: ${(failureRate * 100).toFixed(1)}% exceeds 20% threshold`);
                this.logger.error(`❌ ${failed.length} stocks failed, ${successful} succeeded`);
                this.isDataCached = false;
                return { success: false, count: 0 };
            }
            this.isDataCached = true;
            const duration = ((Date.now() - startTime) / 1000).toFixed(1);
            this.logger.info(`✅✅✅ COMPLETE: Cached ${this.cachedHistoricalData.size}/${this.universe.length} stocks in ${duration}s`);
            return { success: true, count: this.cachedHistoricalData.size };
        }
        catch (error) {
            this.logger.error("❌❌❌ FATAL ERROR in cacheHistoricalData:");
            this.logger.error(`Error Type: ${error.error_type || typeof error}`);
            this.logger.error(`Error Message: ${error.message || JSON.stringify(error)}`);
            if (error.stack) {
                this.logger.error(`Stack: ${error.stack}`);
            }
            throw error;
        }
    }
    isReady() {
        return this.isDataCached;
    }
    clearCache() {
        this.logger.info("🧹 MarketScanner: Clearing cached data");
        this.cachedHistoricalData.clear();
        this.isDataCached = false;
    }
    floorTo5Min(ms) {
        return Math.floor(ms / this.FIVE_MIN_MS) * this.FIVE_MIN_MS;
    }
    sameDay(a, b) {
        const da = new Date(a), db = new Date(b);
        return da.getUTCFullYear() === db.getUTCFullYear()
            && da.getUTCMonth() === db.getUTCMonth()
            && da.getUTCDate() === db.getUTCDate();
    }
    appendCandle(symbol, candle) {
        const series = this.cachedHistoricalData.get(symbol);
        const c = { ...candle, date: new Date(this.floorTo5Min(candle.date.getTime())) };
        if (!series || series.length === 0) {
            this.cachedHistoricalData.set(symbol, [c]);
            return 'PUSH';
        }
        const last = series[series.length - 1];
        const lastT = this.floorTo5Min(last.date.getTime());
        const newT = c.date.getTime();
        if (newT === lastT) {
            if (last.open === c.open && last.high === c.high && last.low === c.low && last.close === c.close)
                return 'DUPLICATE';
            series[series.length - 1] = c;
            return 'UPDATE';
        }
        if (newT < lastT)
            return 'STALE';
        series.push(c);
        if (series.length > this.CANDLE_WINDOW)
            series.splice(0, series.length - this.CANDLE_WINDOW);
        return 'PUSH';
    }
    updateFormingCandle(symbol, lastPrice, dayVolume, nowMs) {
        if (!(lastPrice > 0))
            return;
        const boundary = this.floorTo5Min(nowMs);
        const f = this.formingCandle.get(symbol);
        if (!f || f.boundary !== boundary) {
            if (f && this.sameDay(f.boundary, boundary)) {
                this.appendCandle(symbol, {
                    date: new Date(f.boundary), open: f.open, high: f.high, low: f.low, close: f.close,
                    volume: Math.max(0, f.lastDayVol - f.openDayVol),
                });
            }
            else if (f) {
                this.appendCandle(symbol, {
                    date: new Date(f.boundary), open: f.open, high: f.high, low: f.low, close: f.close,
                    volume: 0,
                });
            }
            this.formingCandle.set(symbol, { boundary, open: lastPrice, high: lastPrice, low: lastPrice, close: lastPrice, openDayVol: dayVolume, lastDayVol: dayVolume });
            return;
        }
        f.high = Math.max(f.high, lastPrice);
        f.low = Math.min(f.low, lastPrice);
        f.close = lastPrice;
        f.lastDayVol = dayVolume;
    }
    flushFormingCandle(symbol, dayVolume) {
        const f = this.formingCandle.get(symbol);
        if (!f)
            return;
        this.appendCandle(symbol, {
            date: new Date(f.boundary), open: f.open, high: f.high, low: f.low, close: f.close,
            volume: Math.max(0, dayVolume - f.openDayVol),
        });
    }
    isCandleStale(symbol, nowMs, maxAgeBars = 2) {
        const series = this.cachedHistoricalData.get(symbol);
        if (!series || series.length === 0)
            return true;
        const lastT = this.floorTo5Min(series[series.length - 1].date.getTime());
        return (this.floorTo5Min(nowMs) - lastT) > maxAgeBars * this.FIVE_MIN_MS;
    }
    getCandles(symbol) {
        return this.cachedHistoricalData.get(symbol);
    }
    saveCandleStore() {
        try {
            const fs = require('fs');
            const path = require('path');
            if (!this.candleStorePath) {
                const dir = path.join(process.cwd(), 'data', 'cache');
                if (!fs.existsSync(dir))
                    fs.mkdirSync(dir, { recursive: true });
                this.candleStorePath = path.join(dir, 'scanner-candles.json');
            }
            const out = { savedAt: new Date().toISOString(), windowDays: this.SEED_LOOKBACK_DAYS, candles: {} };
            for (const [sym, series] of this.cachedHistoricalData.entries()) {
                out.candles[sym] = series.map(c => ({ d: c.date.getTime(), o: c.open, h: c.high, l: c.low, c: c.close, v: c.volume }));
            }
            fs.writeFileSync(this.candleStorePath, JSON.stringify(out));
        }
        catch (e) {
            this.logger.warn(`⚠️ saveCandleStore failed (non-fatal): ${e?.message || e}`);
        }
    }
    loadCandleStore(nowMs = Date.now(), maxAgeBars = 2) {
        try {
            const fs = require('fs');
            const path = require('path');
            const p = path.join(process.cwd(), 'data', 'cache', 'scanner-candles.json');
            if (!fs.existsSync(p))
                return false;
            const raw = JSON.parse(fs.readFileSync(p, 'utf8'));
            if (!raw?.candles)
                return false;
            let newest = 0;
            const map = new Map();
            for (const sym of Object.keys(raw.candles)) {
                const series = raw.candles[sym].map((r) => ({ date: new Date(r.d), open: r.o, high: r.h, low: r.l, close: r.c, volume: r.v }));
                if (series.length)
                    newest = Math.max(newest, series[series.length - 1].date.getTime());
                map.set(sym, series);
            }
            const fresh = newest > 0 && (this.floorTo5Min(nowMs) - this.floorTo5Min(newest)) <= maxAgeBars * this.FIVE_MIN_MS;
            if (!fresh) {
                this.logger.info(`📦 Persisted candle store found but stale (newest ${new Date(newest).toISOString()}) — will reseed`);
                return false;
            }
            this.cachedHistoricalData = map;
            this.isDataCached = true;
            this.logger.info(`📦 Loaded fresh candle store: ${map.size} symbols (newest ${new Date(newest).toISOString()})`);
            return true;
        }
        catch (e) {
            this.logger.warn(`⚠️ loadCandleStore failed (non-fatal): ${e?.message || e}`);
            return false;
        }
    }
    async seedCandlesIfNeeded() {
        if (this.candleSeeded && this.cachedHistoricalData.size > 0)
            return true;
        if (this.loadCandleStore()) {
            this.candleSeeded = true;
            return true;
        }
        this.logger.info(`🌱 Seeding scanner candles once (${this.SEED_LOOKBACK_DAYS}-day historical pull)...`);
        const res = await this.cacheHistoricalData(this.SEED_LOOKBACK_DAYS);
        if (res.success) {
            this.candleSeeded = true;
            this.saveCandleStore();
            this.logger.info(`🌱 Seed complete: ${res.count} symbols. Incremental candle engine active.`);
        }
        return res.success;
    }
    async pollUniverseCandles() {
        if (this.candlePollRunning)
            return;
        if (!this.candleSeeded)
            return;
        this.candlePollRunning = true;
        const now = Date.now();
        let updated = 0;
        try {
            const keys = this.universe.map(s => `NSE:${s.symbol}`);
            const CHUNK = 250;
            for (let i = 0; i < keys.length; i += CHUNK) {
                const chunk = keys.slice(i, i + CHUNK);
                try {
                    const quotes = await this.kiteConnect.getQuote(chunk);
                    for (const stock of this.universe) {
                        const q = quotes[`NSE:${stock.symbol}`];
                        if (q && typeof q.last_price === 'number' && q.last_price > 0) {
                            this.updateFormingCandle(stock.symbol, q.last_price, q.volume || 0, now);
                            updated++;
                        }
                    }
                }
                catch (e) {
                    this.logger.warn(`⚠️ Candle poll chunk failed (non-fatal): ${e?.message || e}`);
                }
                if (i + CHUNK < keys.length)
                    await new Promise(r => setTimeout(r, 300));
            }
            this.lastPollSummary = { at: now, updated, total: this.universe.length };
            this.logger.debug(`🕯️ Candle poll: ${updated}/${this.universe.length} symbols updated`);
        }
        finally {
            this.candlePollRunning = false;
        }
    }
    startCandlePolling(intervalMs, isMarketOpen) {
        if (this.candlePollTimer)
            return;
        this.logger.info(`🕯️ Starting incremental candle poll loop (every ${Math.round(intervalMs / 1000)}s)`);
        this.candlePollTimer = setInterval(() => {
            if (!isMarketOpen())
                return;
            this.pollUniverseCandles().catch(e => this.logger.warn(`candle poll error: ${e?.message || e}`));
        }, intervalMs);
    }
    stopCandlePolling() {
        if (this.candlePollTimer) {
            clearInterval(this.candlePollTimer);
            this.candlePollTimer = null;
        }
    }
    async ensureFreshUniverse(nowMs = Date.now()) {
        const stale = this.universe.filter(s => this.isCandleStale(s.symbol, nowMs));
        if (stale.length === 0)
            return { stale: 0, reseeded: 0, fullReseed: false };
        if (stale.length > this.universe.length * 0.3) {
            this.logger.warn(`⚠️ ${stale.length}/${this.universe.length} symbols stale → full reseed`);
            const res = await this.cacheHistoricalData(this.SEED_LOOKBACK_DAYS);
            if (res.success)
                this.saveCandleStore();
            return { stale: stale.length, reseeded: res.count, fullReseed: true };
        }
        let reseeded = 0;
        for (let i = 0; i < stale.length; i += 2) {
            const batch = stale.slice(i, i + 2);
            await Promise.allSettled(batch.map(async (s) => {
                try {
                    const toDate = new Date();
                    const fromDate = new Date();
                    fromDate.setDate(fromDate.getDate() - this.SEED_LOOKBACK_DAYS);
                    const candles = await this.kiteConnect.getHistoricalData(s.instrumentToken, '5minute', fromDate, toDate);
                    if (candles && candles.length) {
                        this.cachedHistoricalData.set(s.symbol, candles.map((c) => ({ date: new Date(c.date), open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume || 0 })));
                        this.formingCandle.delete(s.symbol);
                        reseeded++;
                    }
                }
                catch { }
            }));
            if (i + 2 < stale.length)
                await new Promise(r => setTimeout(r, 1000));
        }
        this.logger.info(`🔧 Targeted reseed: ${reseeded}/${stale.length} stale symbols repaired`);
        return { stale: stale.length, reseeded, fullReseed: false };
    }
    getCandleEngineStatus() {
        const sample = this.universe.slice(0, 5).map(s => {
            const series = this.cachedHistoricalData.get(s.symbol);
            return { symbol: s.symbol, candles: series?.length || 0, newest: series && series.length ? series[series.length - 1].date.toISOString() : null };
        });
        return { seeded: this.candleSeeded, symbols: this.cachedHistoricalData.size, lastPoll: this.lastPollSummary, sampleCounts: sample };
    }
    async analyzeSectors() {
        this.logger.info("📊 Analyzing sector performance...");
        const sectors = Array.from(new Set(this.universe.map((s) => s.sectorToken)));
        this.logger.info(`📊 Fetching quotes for ${sectors.length} sector indices: ${sectors.slice(0, 3).join(', ')}...`);
        const quotes = await this.kiteConnect.getQuote(sectors);
        const quoteKeys = Object.keys(quotes);
        this.logger.info(`📊 Raw quote response keys (${quoteKeys.length}): ${quoteKeys.slice(0, 5).join(', ')}`);
        if (quoteKeys.length > 0 && quoteKeys[0]) {
            const firstQuote = quotes[quoteKeys[0]];
            this.logger.info(`📊 Sample quote structure: instrument_token=${firstQuote?.instrument_token}, net_change=${firstQuote?.net_change}, ohlc=${JSON.stringify(firstQuote?.ohlc)}`);
        }
        const green = [];
        const red = [];
        const flat = [];
        const data = new Map();
        for (const stock of this.universe) {
            let quote = quotes[stock.sectorToken];
            if (!quote) {
                quote = Object.values(quotes).find((q) => q.instrument_token === stock.sectorToken);
            }
            if (!quote)
                continue;
            const previousClose = quote.ohlc?.close || 0;
            const netChange = quote.net_change || 0;
            const changePercent = previousClose > 0 ? (netChange / previousClose) * 100 : 0;
            data.set(stock.sectorToken, {
                name: stock.sector,
                changePercent,
            });
            if (changePercent > this.config.sectorChangeThreshold.green) {
                if (!green.includes(stock.sector))
                    green.push(stock.sector);
            }
            else if (changePercent < this.config.sectorChangeThreshold.red) {
                if (!red.includes(stock.sector))
                    red.push(stock.sector);
            }
            else {
                if (!flat.includes(stock.sector))
                    flat.push(stock.sector);
            }
        }
        this.logger.info(`🔍 Sector Analysis (threshold: green>${this.config.sectorChangeThreshold.green}%, red<${this.config.sectorChangeThreshold.red}%):`);
        const uniqueSectors = Array.from(new Set(this.universe.map(s => s.sector)));
        for (const sector of uniqueSectors.slice(0, 5)) {
            const sectorData = Array.from(data.values()).find(d => d.name === sector);
            if (sectorData) {
                const status = green.includes(sector) ? 'GREEN' : red.includes(sector) ? 'RED' : 'FLAT';
                this.logger.info(`  ${sector}: ${sectorData.changePercent.toFixed(2)}% (${status})`);
            }
        }
        this.logger.info(`Sectors - Green: ${green.length}, Red: ${red.length}, Flat: ${flat.length}`);
        return { green, red, flat, data };
    }
    filterBySector(sectorStatus) {
        const allSectorsFlat = sectorStatus.green.length === 0 && sectorStatus.red.length === 0;
        if (allSectorsFlat) {
            this.logger.warn("⚠️ All sectors flat (0% change) - market may be closed or pre-market");
            return [];
        }
        return [...this.universe];
    }
    async scoreStocks(stocks, sectorStatus) {
        this.logger.info(`📈 Scoring ${stocks.length} stocks...`);
        const quoteCache = new Map();
        const QUOTE_BATCH_SIZE = 40;
        const allQuoteKeys = stocks.map(s => `NSE:${s.symbol}`);
        for (let i = 0; i < allQuoteKeys.length; i += QUOTE_BATCH_SIZE) {
            const batch = allQuoteKeys.slice(i, i + QUOTE_BATCH_SIZE);
            try {
                const quotes = await this.kiteConnect.getQuote(batch);
                for (const key of batch) {
                    const q = quotes[key];
                    if (q) {
                        quoteCache.set(key, {
                            upper_circuit_limit: q.upper_circuit_limit || 0,
                            lower_circuit_limit: q.lower_circuit_limit || 0,
                            ohlcClose: q.ohlc?.close || 0,
                        });
                    }
                }
                this.logger.info(`📡 Fetched quotes batch ${Math.floor(i / QUOTE_BATCH_SIZE) + 1}/${Math.ceil(allQuoteKeys.length / QUOTE_BATCH_SIZE)} (${batch.length} symbols)`);
                if (i + QUOTE_BATCH_SIZE < allQuoteKeys.length) {
                    await new Promise(resolve => setTimeout(resolve, 500));
                }
            }
            catch (batchError) {
                this.logger.warn(`⚠️ Quote batch ${Math.floor(i / QUOTE_BATCH_SIZE) + 1} failed, stocks in this batch will have no circuit/change data: ${batchError}`);
            }
        }
        this.logger.info(`📡 Quote cache populated: ${quoteCache.size}/${stocks.length} stocks`);
        const results = [];
        for (const stock of stocks) {
            try {
                const candles = this.cachedHistoricalData.get(stock.symbol);
                if (!candles || candles.length < 50) {
                    this.logger.warn(`${stock.symbol}: Insufficient data (${candles?.length || 0} candles)`);
                    continue;
                }
                const candles15m = this.derive15MinCandles(candles);
                const closes = candles.map((c) => c.close);
                const highs = candles.map((c) => c.high);
                const lows = candles.map((c) => c.low);
                const volumes = candles.map((c) => c.volume);
                const ema8 = this.calculateEMA(closes, 8);
                const ema21 = this.calculateEMA(closes, 21);
                const ema50 = this.calculateEMA(closes, 50);
                const rsi5m = this.calculateRSI(closes, 14);
                const rsi15m = this.calculateRSI(candles15m.map((c) => c.close), 14);
                const adx = this.calculateADX(highs, lows, closes, 14);
                const vwap = this.calculateVWAP(candles);
                const rvol = this.calculateRVOL(volumes);
                const spotPrice = closes[closes.length - 1];
                if (!spotPrice || !candles[0]) {
                    this.logger.warn(`${stock.symbol}: Invalid price data`);
                    continue;
                }
                const supertrend = this.calculateSupertrend(candles, 10, 2);
                const bollingerBands = this.calculateBollingerBands(closes, 20, 2);
                const riskPercent = (Math.abs(spotPrice - supertrend.value) / spotPrice) * 100;
                if (riskPercent > MAX_RISK_PERCENT) {
                    this.logger.warn(`⚠️ ${stock.symbol}: Rejected - Risk too high (${riskPercent.toFixed(2)}% > ${MAX_RISK_PERCENT}%)`);
                    results.push({
                        symbol: stock.symbol,
                        score: 0,
                        baseScore: 0,
                        bias: "LONG",
                        sector: stock.sector,
                        sectorToken: stock.sectorToken,
                        breakdown: { trend: 0, momentum: 0, volume: 0, sector: 0, smartMoney: 0 },
                        tacticalBonus: { freshBreakout: 0, rvolSurge: 0, proximity: 0, rsiAccel: 0, squeeze: 0, gammaWall: 0, total: 0 },
                        spotPrice,
                        upperCircuitLimit: 0,
                        lowerCircuitLimit: 0,
                        todayChangePercent: 0,
                        atmOption: null,
                        historicalData: candles,
                        valid: false,
                        rejectionReason: `Risk too high (${riskPercent.toFixed(2)}% > ${MAX_RISK_PERCENT}%)`,
                    });
                    continue;
                }
                const bandwidthPercent = ((bollingerBands.upper - bollingerBands.lower) / bollingerBands.middle) * 100;
                if (bandwidthPercent > MAX_BANDWIDTH_PERCENT) {
                    this.logger.warn(`⚠️ ${stock.symbol}: Rejected - Over-extended (Bandwidth ${bandwidthPercent.toFixed(2)}% > ${MAX_BANDWIDTH_PERCENT}%)`);
                    results.push({
                        symbol: stock.symbol,
                        score: 0,
                        baseScore: 0,
                        bias: "LONG",
                        sector: stock.sector,
                        sectorToken: stock.sectorToken,
                        breakdown: { trend: 0, momentum: 0, volume: 0, sector: 0, smartMoney: 0 },
                        tacticalBonus: { freshBreakout: 0, rvolSurge: 0, proximity: 0, rsiAccel: 0, squeeze: 0, gammaWall: 0, total: 0 },
                        spotPrice,
                        upperCircuitLimit: 0,
                        lowerCircuitLimit: 0,
                        todayChangePercent: 0,
                        atmOption: null,
                        historicalData: candles,
                        valid: false,
                        rejectionReason: `Over-extended (Bandwidth ${bandwidthPercent.toFixed(2)}% > ${MAX_BANDWIDTH_PERCENT}%)`,
                    });
                    continue;
                }
                this.logger.debug(`✅ ${stock.symbol}: Passed geometry checks (Risk: ${riskPercent.toFixed(2)}%, Bandwidth: ${bandwidthPercent.toFixed(2)}%)`);
                const sectorData = sectorStatus.data.get(stock.sectorToken);
                const sectorChange = sectorData?.changePercent || 0;
                let sectorState = 'FLAT';
                let bias = null;
                let biasSource = 'SECTOR';
                if (sectorStatus.green.includes(stock.sector)) {
                    sectorState = 'GREEN';
                    bias = "LONG";
                }
                else if (sectorStatus.red.includes(stock.sector)) {
                    sectorState = 'RED';
                    bias = "SHORT";
                }
                if (!bias) {
                    const currCandleEarly = candles[candles.length - 1];
                    const prevCandleEarly = candles[candles.length - 2];
                    const currCloseEarly = currCandleEarly?.close || spotPrice;
                    const prevCloseEarly = prevCandleEarly?.close || currCloseEarly;
                    if (prevCloseEarly <= bollingerBands.upper && currCloseEarly > bollingerBands.upper) {
                        bias = 'LONG';
                        biasSource = 'BREAKOUT';
                    }
                    else if (prevCloseEarly >= bollingerBands.lower && currCloseEarly < bollingerBands.lower) {
                        bias = 'SHORT';
                        biasSource = 'BREAKOUT';
                    }
                    else {
                        const upperDistEarly = Math.abs(bollingerBands.upper - currCloseEarly) / currCloseEarly;
                        const lowerDistEarly = Math.abs(currCloseEarly - bollingerBands.lower) / currCloseEarly;
                        if (upperDistEarly < 0.002 && currCloseEarly > prevCloseEarly) {
                            bias = 'LONG';
                            biasSource = 'BREAKOUT';
                        }
                        else if (lowerDistEarly < 0.002 && currCloseEarly < prevCloseEarly) {
                            bias = 'SHORT';
                            biasSource = 'BREAKOUT';
                        }
                    }
                }
                if (!bias) {
                    this.logger.debug(`⏭️ ${stock.symbol}: No sector bias and no BB breakout - skip`);
                    continue;
                }
                const candles60m = this.derive60MinCandles(candles);
                if (candles60m.length >= 20) {
                    const supertrend1h = this.calculateSupertrend(candles60m, 10, 2);
                    const isAligned = (bias === "LONG" && supertrend1h.trend === "UP") ||
                        (bias === "SHORT" && supertrend1h.trend === "DOWN");
                    if (!isAligned) {
                        const rejectionMsg = `1h ST misaligned (Bias: ${bias}, 1h ST: ${supertrend1h.trend}, value: ${supertrend1h.value.toFixed(2)})`;
                        this.logger.warn(`⚠️ ${stock.symbol}: Rejected - ${rejectionMsg}`);
                        results.push({
                            symbol: stock.symbol,
                            score: 0,
                            baseScore: 0,
                            bias: bias,
                            sector: stock.sector,
                            sectorToken: stock.sectorToken,
                            breakdown: { trend: 0, momentum: 0, volume: 0, sector: 0, smartMoney: 0 },
                            tacticalBonus: { freshBreakout: 0, rvolSurge: 0, proximity: 0, rsiAccel: 0, squeeze: 0, gammaWall: 0, total: 0 },
                            spotPrice,
                            upperCircuitLimit: 0,
                            lowerCircuitLimit: 0,
                            todayChangePercent: 0,
                            atmOption: null,
                            historicalData: candles,
                            valid: false,
                            rejectionReason: rejectionMsg,
                        });
                        continue;
                    }
                    this.logger.debug(`✅ ${stock.symbol}: 1h ST aligned (Bias: ${bias}, 1h ST: ${supertrend1h.trend})`);
                }
                else {
                    this.logger.warn(`⚠️ ${stock.symbol}: Insufficient 60m candles (${candles60m.length}) for 1h ST - allowing through`);
                }
                let upperCircuitLimit = 0;
                let lowerCircuitLimit = 0;
                let todayChangePercent = 0;
                const quoteKey = `NSE:${stock.symbol}`;
                const cachedQuote = quoteCache.get(quoteKey);
                if (cachedQuote) {
                    upperCircuitLimit = cachedQuote.upper_circuit_limit;
                    lowerCircuitLimit = cachedQuote.lower_circuit_limit;
                    todayChangePercent = cachedQuote.ohlcClose
                        ? ((spotPrice - cachedQuote.ohlcClose) / cachedQuote.ohlcClose) * 100
                        : 0;
                }
                const breakdown = { trend: 0, momentum: 0, volume: 0, sector: 0, smartMoney: 0 };
                if (bias === "LONG") {
                    if (spotPrice > vwap)
                        breakdown.trend += 1.5;
                    if (spotPrice > ema8 && ema8 > ema21)
                        breakdown.trend += 1.0;
                    if (spotPrice > ema50)
                        breakdown.trend += 0.5;
                }
                else {
                    if (spotPrice < vwap)
                        breakdown.trend += 1.5;
                    if (spotPrice < ema8 && ema8 < ema21)
                        breakdown.trend += 1.0;
                    if (spotPrice < ema50)
                        breakdown.trend += 0.5;
                }
                if (bias === "LONG") {
                    if (rsi5m >= 60 && rsi5m <= 75) {
                        breakdown.momentum += 1.5;
                    }
                    else if (rsi5m > 75 && rsi5m < 85) {
                        breakdown.momentum += 0.5;
                    }
                    if (rsi5m > rsi15m)
                        breakdown.momentum += 1.0;
                }
                else {
                    if (rsi5m <= 40 && rsi5m >= 25) {
                        breakdown.momentum += 1.5;
                    }
                    else if (rsi5m < 25 && rsi5m > 15) {
                        breakdown.momentum += 0.5;
                    }
                    if (rsi5m < rsi15m)
                        breakdown.momentum += 1.0;
                }
                if (adx > 25)
                    breakdown.momentum += 1.0;
                if (bias === 'LONG') {
                    if (rvol > 2.0 && rvol <= 5.0) {
                        breakdown.volume += 0.5;
                    }
                    else if (rvol > 5.0) {
                        breakdown.volume += 0.0;
                    }
                    else if (rvol >= 1.5 && rvol <= 2.0) {
                        breakdown.volume += 0.25;
                    }
                }
                else {
                    if (rvol > 2.0 && rvol <= 5.0) {
                        breakdown.volume += 1.0;
                    }
                    else if (rvol > 5.0) {
                        breakdown.volume += 0.5;
                    }
                    else if (rvol >= 1.5 && rvol <= 2.0) {
                        breakdown.volume += 0.5;
                    }
                }
                if (sectorState !== 'FLAT') {
                    breakdown.sector += 1.0;
                }
                const stockChange = todayChangePercent;
                if (bias === "LONG" && stockChange > sectorChange) {
                    breakdown.sector += 1.0;
                }
                else if (bias === "SHORT" && stockChange < sectorChange) {
                    breakdown.sector += 1.0;
                }
                let smartMoneyBonus = 0;
                let smartMoneySignal = 'NONE';
                if (this.oiHistoryService) {
                    if (this.oiHistoryService.isExpiryWeek()) {
                        smartMoneySignal = 'EXPIRY_WEEK';
                        this.logger.debug(`${stock.symbol}: Smart Money skipped (expiry week)`);
                    }
                    else if (this.oiHistoryService.hasValidData()) {
                        try {
                            const prevClose = candles[candles.length - 2]?.close || spotPrice;
                            const oiAnalysis = await this.oiHistoryService.analyzeStock(stock.symbol, spotPrice, prevClose);
                            if (oiAnalysis) {
                                smartMoneyBonus = this.oiHistoryService.calculateSmartMoneyBonus(oiAnalysis, bias);
                                smartMoneySignal = oiAnalysis.smartMoneySignal;
                                if (smartMoneyBonus === 2.0) {
                                    this.logger.info(`💎 ${stock.symbol}: Coiled Spring MATCH (+2.0) - ${smartMoneySignal} aligns with ${bias}`);
                                }
                                else if (smartMoneyBonus === -999) {
                                    this.logger.warn(`⚠️ ${stock.symbol}: Smart Money CONFLICT - ${smartMoneySignal} vs ${bias} bias - DISQUALIFIED`);
                                    smartMoneySignal = 'CONFLICT';
                                }
                            }
                        }
                        catch (oiError) {
                            this.logger.debug(`${stock.symbol}: OI analysis failed - ${oiError}`);
                        }
                    }
                }
                if (smartMoneyBonus === -999) {
                    breakdown.smartMoney = 0;
                    continue;
                }
                breakdown.smartMoney = smartMoneyBonus;
                const baseScore = breakdown.trend +
                    breakdown.momentum +
                    breakdown.volume +
                    breakdown.sector +
                    breakdown.smartMoney;
                const currCandle = candles[candles.length - 1];
                const prevCandle = candles[candles.length - 2];
                const currClose = currCandle?.close || spotPrice;
                const prevClose = prevCandle?.close || currClose;
                if (biasSource === 'SECTOR') {
                    if (prevClose <= bollingerBands.upper && currClose > bollingerBands.upper) {
                        bias = 'LONG';
                        biasSource = 'BREAKOUT';
                    }
                    else if (prevClose >= bollingerBands.lower && currClose < bollingerBands.lower) {
                        bias = 'SHORT';
                        biasSource = 'BREAKOUT';
                    }
                    else {
                        const upperDist = Math.abs(bollingerBands.upper - currClose) / currClose;
                        const lowerDist = Math.abs(currClose - bollingerBands.lower) / currClose;
                        if (upperDist < 0.002 && currClose > prevClose) {
                            bias = 'LONG';
                            biasSource = 'BREAKOUT';
                        }
                        else if (lowerDist < 0.002 && currClose < prevClose) {
                            bias = 'SHORT';
                            biasSource = 'BREAKOUT';
                        }
                    }
                }
                const isCounterTrend = (sectorState === 'RED' && bias === 'LONG') ||
                    (sectorState === 'GREEN' && bias === 'SHORT');
                const BASE_SCORE_FLOOR = 5.0;
                let tacticalBonus = {
                    freshBreakout: 0, rvolSurge: 0, proximity: 0, rsiAccel: 0, squeeze: 0, gammaWall: 0, total: 0
                };
                if (baseScore >= BASE_SCORE_FLOOR) {
                    tacticalBonus = this.calculateTacticalBonus(candles, spotPrice, bias, bollingerBands, bandwidthPercent);
                    if (tacticalBonus.total > 0) {
                        this.logger.debug(`📈 ${stock.symbol}: Tactical Bonus +${tacticalBonus.total.toFixed(1)} (FB:${tacticalBonus.freshBreakout} RV:${tacticalBonus.rvolSurge} PX:${tacticalBonus.proximity} RA:${tacticalBonus.rsiAccel} SQ:${tacticalBonus.squeeze.toFixed(1)} GW:${tacticalBonus.gammaWall})`);
                    }
                }
                const rawScore = baseScore + tacticalBonus.total;
                const score = Math.min(rawScore, 13.0);
                if (tacticalBonus.freshBreakout > 0 && breakdown.volume > 0
                    && tacticalBonus.proximity === 0 && tacticalBonus.rsiAccel === 0) {
                    this.logger.info(`🛑 ${stock.symbol}: Double Trap filter — FB+V without PX/RA, skipping`);
                    continue;
                }
                const isBreakoutOnly = biasSource === 'BREAKOUT' && sectorState === 'FLAT';
                const isCounterTrendEntry = biasSource === 'BREAKOUT' && isCounterTrend;
                if (isCounterTrendEntry) {
                    if (baseScore < 8.0) {
                        this.logger.info(`🚫 ${stock.symbol}: Counter-trend ${bias} blocked (base ${baseScore.toFixed(1)} < 8.0, sector ${sectorState})`);
                        continue;
                    }
                    this.logger.info(`⚡ ${stock.symbol}: Counter-trend ${bias} ALLOWED (base ${baseScore.toFixed(1)} ≥ 8.0, strong conviction)`);
                }
                else if (isBreakoutOnly) {
                    if (baseScore < 6.5) {
                        this.logger.info(`🚫 ${stock.symbol}: Flat-sector breakout blocked (base ${baseScore.toFixed(1)} < 6.5)`);
                        continue;
                    }
                    this.logger.info(`⚡ ${stock.symbol}: Flat-sector ${bias} via breakout (base ${baseScore.toFixed(1)} ≥ 6.5)`);
                }
                results.push({
                    symbol: stock.symbol,
                    score,
                    baseScore,
                    bias,
                    sector: stock.sector,
                    sectorToken: stock.sectorToken,
                    breakdown,
                    tacticalBonus,
                    smartMoneySignal,
                    spotPrice,
                    upperCircuitLimit,
                    lowerCircuitLimit,
                    todayChangePercent: stockChange,
                    atmOption: null,
                    historicalData: candles,
                    valid: true,
                });
            }
            catch (error) {
                this.logger.error(`Failed to score ${stock.symbol}:`, error);
            }
        }
        return results;
    }
    applySafetyFilters(stocks) {
        return stocks.filter((stock) => {
            const candles = stock.historicalData;
            if (candles.length < 2)
                return false;
            const lastCandle = candles[candles.length - 1];
            const prevCandle = candles[candles.length - 2];
            if (stock.score < this.config.minScore) {
                this.logger.debug(`${stock.symbol}: Score too low (${stock.score.toFixed(2)})`);
                return false;
            }
            const closes = candles.map((c) => c.close);
            const rsi = this.calculateRSI(closes, 14);
            if (rsi > 85) {
                this.logger.warn(`${stock.symbol}: RSI overbought exhaustion (${rsi.toFixed(1)} > 85) - DISCARD`);
                return false;
            }
            if (rsi < 15) {
                this.logger.warn(`${stock.symbol}: RSI oversold exhaustion (${rsi.toFixed(1)} < 15) - DISCARD`);
                return false;
            }
            if (!lastCandle || !prevCandle) {
                return true;
            }
            const gapPercent = ((lastCandle.open - prevCandle.close) / prevCandle.close) * 100;
            if (Math.abs(gapPercent) > 2.0) {
                this.logger.warn(`${stock.symbol}: Gap ${gapPercent.toFixed(2)}% - DISCARD`);
                return false;
            }
            const CIRCUIT_PROXIMITY_THRESHOLD = 1.5;
            if (stock.upperCircuitLimit > 0 && stock.lowerCircuitLimit > 0) {
                const currentPrice = stock.spotPrice;
                if (stock.bias === "LONG") {
                    const proximityToUpperCircuit = ((stock.upperCircuitLimit - currentPrice) / currentPrice) * 100;
                    if (proximityToUpperCircuit < CIRCUIT_PROXIMITY_THRESHOLD) {
                        this.logger.warn(`${stock.symbol}: Near Upper Circuit (${proximityToUpperCircuit.toFixed(2)}% < ${CIRCUIT_PROXIMITY_THRESHOLD}%) - DISCARD`);
                        return false;
                    }
                }
                else {
                    const proximityToLowerCircuit = ((currentPrice - stock.lowerCircuitLimit) / currentPrice) * 100;
                    if (proximityToLowerCircuit < CIRCUIT_PROXIMITY_THRESHOLD) {
                        this.logger.warn(`${stock.symbol}: Near Lower Circuit (${proximityToLowerCircuit.toFixed(2)}% < ${CIRCUIT_PROXIMITY_THRESHOLD}%) - DISCARD`);
                        return false;
                    }
                }
            }
            if (stock.todayChangePercent < -5.0 && stock.bias === 'SHORT') {
                this.logger.warn(`${stock.symbol}: Extreme DOWN move (${stock.todayChangePercent.toFixed(1)}% < -5%) - DISCARD (extended)`);
                return false;
            }
            if (stock.todayChangePercent > 5.0 && stock.bias === 'LONG') {
                this.logger.warn(`${stock.symbol}: Extreme UP move (${stock.todayChangePercent.toFixed(1)}% > +5%) - DISCARD (extended)`);
                return false;
            }
            return true;
        });
    }
    async selectTopStocks(stocks, sectorStatus) {
        const sorted = stocks.sort((a, b) => b.score - a.score);
        this.logger.info(`📊 Top 10 Scored Stocks (Base + Tactical):`);
        sorted.slice(0, 10).forEach((stock, i) => {
            const smDisplay = ` SM:${stock.breakdown.smartMoney.toFixed(1)}`;
            const tacDisplay = stock.tacticalBonus.total > 0
                ? ` | Tac: FB:${stock.tacticalBonus.freshBreakout} RV:${stock.tacticalBonus.rvolSurge} PX:${stock.tacticalBonus.proximity} RA:${stock.tacticalBonus.rsiAccel} SQ:${stock.tacticalBonus.squeeze.toFixed(1)} GW:${stock.tacticalBonus.gammaWall}`
                : '';
            this.logger.info(`  ${i + 1}. ${stock.symbol}: Score=${stock.score.toFixed(2)} (Base:${stock.baseScore.toFixed(1)} + Tac:${stock.tacticalBonus.total.toFixed(1)}) [${stock.bias}${stock.breakdown.sector === 0 ? '*' : ''}] | T:${stock.breakdown.trend.toFixed(1)} M:${stock.breakdown.momentum.toFixed(1)} V:${stock.breakdown.volume.toFixed(1)} S:${stock.breakdown.sector.toFixed(1)}${smDisplay}${tacDisplay}`);
        });
        const qualifiedStocks = sorted.filter(s => s.score >= this.config.minScore);
        this.logger.info(`📊 ${qualifiedStocks.length} stocks meet minimum score of ${this.config.minScore}`);
        const MAX_STOCKS_PER_SECTOR = 2;
        const sectorCounts = new Map();
        const validStocks = [];
        let checkedCount = 0;
        let skippedForDiversity = 0;
        for (const stock of qualifiedStocks) {
            if (validStocks.length >= this.config.topCount) {
                break;
            }
            const currentSectorCount = sectorCounts.get(stock.sector) || 0;
            if (currentSectorCount >= MAX_STOCKS_PER_SECTOR) {
                this.logger.info(`⚠️ ${stock.symbol}: Sector ${stock.sector} already has ${currentSectorCount} stocks - SKIP (diversity rule)`);
                skippedForDiversity++;
                continue;
            }
            checkedCount++;
            if (checkedCount > 1) {
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
            try {
                let atmOption;
                try {
                    atmOption = await this.findATMOption(stock.symbol, stock.spotPrice, stock.bias);
                }
                catch (findError) {
                    const code = findError?.code || findError?.error_type || '';
                    const isTransient = ['ECONNABORTED', 'ETIMEDOUT', 'ECONNRESET', 'ENOTFOUND', 'NetworkException'].includes(code);
                    if (isTransient) {
                        this.logger.warn(`⚠️ ${stock.symbol}: Transient error (${code}) finding option — retrying in 3s...`);
                        await new Promise(resolve => setTimeout(resolve, 3000));
                        atmOption = await this.findATMOption(stock.symbol, stock.spotPrice, stock.bias);
                    }
                    else {
                        throw findError;
                    }
                }
                if (atmOption.premium < this.config.minPremium) {
                    this.logger.warn(`${stock.symbol}: Premium too low (₹${atmOption.premium.toFixed(1)}, min: ₹${this.config.minPremium}) - SKIP, trying next...`);
                    stock.valid = false;
                    continue;
                }
                const DYNAMIC_OI_MULTIPLIER = 500;
                const dynamicMinOI = DYNAMIC_OI_MULTIPLIER * atmOption.lotSize;
                const MIN_VOL = 500;
                if (atmOption.oi < dynamicMinOI && atmOption.volume < MIN_VOL) {
                    this.logger.warn(`❌ ${stock.symbol}: Illiquid Option (${atmOption.tradingsymbol}) - OI:${atmOption.oi} < Dynamic Min ${dynamicMinOI} (lot:${atmOption.lotSize} × ${DYNAMIC_OI_MULTIPLIER}), Vol:${atmOption.volume} - DISCARD`);
                    stock.valid = false;
                    continue;
                }
                stock.atmOption = atmOption;
                stock.valid = true;
                stock.tacticalBonus.gammaWall = atmOption.gammaWallBonus;
                stock.tacticalBonus.runwayTier = atmOption.runwayTier;
                stock.tacticalBonus.runwayRatio = atmOption.runwayRatio;
                if (atmOption.gammaWallBonus > 0) {
                    stock.tacticalBonus.total += atmOption.gammaWallBonus;
                    stock.score += atmOption.gammaWallBonus;
                }
                validStocks.push(stock);
                sectorCounts.set(stock.sector, (sectorCounts.get(stock.sector) || 0) + 1);
                const gwIndicator = atmOption.gammaWallBonus > 0
                    ? ` 🎯GW:${atmOption.gammaWallBonus}[${atmOption.runwayTier}]`
                    : '';
                this.logger.info(`✅ ${stock.symbol}: Valid option found - ${atmOption.tradingsymbol} @ ₹${atmOption.premium.toFixed(1)} | OI:${atmOption.oi.toLocaleString()}, Vol:${atmOption.volume}${gwIndicator} | Sector: ${stock.sector} (${sectorCounts.get(stock.sector)}/${MAX_STOCKS_PER_SECTOR}) (${validStocks.length}/${this.config.topCount} slots filled)`);
            }
            catch (error) {
                this.logger.error(`Failed to find option for ${stock.symbol}:`, error);
                stock.valid = false;
            }
        }
        this.logger.info(`📊 Checked ${checkedCount} stocks, skipped ${skippedForDiversity} for diversity, found ${validStocks.length} with valid options`);
        return validStocks;
    }
    async findATMOption(symbol, spotPrice, type) {
        const instruments = await this.instrumentCache.getNFOInstruments();
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const symbolOptions = instruments.filter((i) => i.name === symbol &&
            i.segment === "NFO-OPT" &&
            new Date(i.expiry) >= today);
        if (symbolOptions.length === 0) {
            throw new Error(`No options found for ${symbol}`);
        }
        const sortedExpiries = symbolOptions
            .map((o) => new Date(o.expiry).getTime())
            .sort((a, b) => a - b);
        const nearestExpiryTime = sortedExpiries[0];
        if (nearestExpiryTime === undefined) {
            throw new Error(`No expiry dates found for ${symbol}`);
        }
        const expiry = new Date(nearestExpiryTime);
        this.logger.info(`📅 Using expiry for ${symbol}: ${expiry.toDateString()} (from instrument data)`);
        const optionType = type === "LONG" ? "CE" : "PE";
        const options = symbolOptions.filter((i) => new Date(i.expiry).getTime() === nearestExpiryTime && i.instrument_type === optionType);
        const allStrikes = [...new Set(options.map((o) => o.strike))].sort((a, b) => a - b);
        const atmStrike = this.findClosestStrike(spotPrice, allStrikes);
        const atmIndex = allStrikes.indexOf(atmStrike);
        const candidateStrikes = [];
        if (atmIndex > 0)
            candidateStrikes.push(allStrikes[atmIndex - 1]);
        candidateStrikes.push(allStrikes[atmIndex]);
        if (atmIndex < allStrikes.length - 1)
            candidateStrikes.push(allStrikes[atmIndex + 1]);
        const candidateOptions = options.filter((o) => candidateStrikes.includes(o.strike));
        const quoteKeys = candidateOptions.map((o) => `NFO:${o.tradingsymbol}`);
        const quotes = await this.kiteConnect.getQuote(quoteKeys);
        const candidates = candidateOptions.map((option) => {
            const quoteKey = `NFO:${option.tradingsymbol}`;
            const quoteData = quotes[quoteKey] || {};
            return {
                strike: option.strike,
                option,
                oi: quoteData.oi || 0,
                volume: quoteData.volume || 0,
                premium: quoteData.last_price || 0,
                distancePercent: Math.abs(option.strike - spotPrice) / spotPrice * 100,
                tradingsymbol: option.tradingsymbol,
            };
        });
        const validCandidates = candidates.filter(c => c.distancePercent <= 1.0);
        const finalCandidates = validCandidates.length > 0 ? validCandidates : candidates;
        const sortedByOI = [...finalCandidates].sort((a, b) => b.oi - a.oi);
        if (sortedByOI.length === 0) {
            throw new Error(`No valid options found for ${symbol} ${optionType}`);
        }
        const selected = sortedByOI[0];
        const secondHighestOI = sortedByOI[1]?.oi || 0;
        const passesConcentrationGate = secondHighestOI > 0 && selected.oi >= secondHighestOI * 2;
        let gammaWallBonus = 0;
        let runwayTier = 'NO_WALL';
        let runwayRatio = 0;
        const MIN_WALL_OI = 10000;
        if (!passesConcentrationGate) {
            this.logger.debug(`📊 ${symbol}: No Concentration Gate (${selected.oi.toLocaleString()} vs ${secondHighestOI.toLocaleString()}) - GW:0`);
        }
        else if (selected.oi < MIN_WALL_OI) {
            this.logger.debug(`📊 ${symbol}: Wall OI too thin (${selected.oi.toLocaleString()} < ${MIN_WALL_OI.toLocaleString()}) - GW:0 [THIN_WALL]`);
        }
        else {
            const selectedIndex = allStrikes.indexOf(selected.strike);
            const runwayStrikes = [];
            if (type === 'LONG') {
                for (let i = selectedIndex + 1; i <= Math.min(selectedIndex + 3, allStrikes.length - 1); i++) {
                    if (allStrikes[i] !== undefined)
                        runwayStrikes.push(allStrikes[i]);
                }
            }
            else {
                for (let i = selectedIndex - 1; i >= Math.max(selectedIndex - 3, 0); i--) {
                    if (allStrikes[i] !== undefined)
                        runwayStrikes.push(allStrikes[i]);
                }
            }
            const runwayOptions = options.filter((o) => runwayStrikes.includes(o.strike));
            let avgRunwayOI = 0;
            if (runwayOptions.length > 0) {
                try {
                    const runwayQuoteKeys = runwayOptions.map((o) => `NFO:${o.tradingsymbol}`);
                    const runwayQuotes = await this.kiteConnect.getQuote(runwayQuoteKeys);
                    const runwayOIs = runwayOptions.map((o) => {
                        const data = runwayQuotes[`NFO:${o.tradingsymbol}`] || {};
                        return data.oi || 0;
                    });
                    avgRunwayOI = runwayOIs.length > 0
                        ? runwayOIs.reduce((a, b) => a + b, 0) / runwayOIs.length
                        : 0;
                    runwayRatio = selected.oi > 0 ? (avgRunwayOI / selected.oi) * 100 : 100;
                    if (runwayRatio < 25) {
                        gammaWallBonus = 1.5;
                        runwayTier = 'VACUUM';
                    }
                    else if (runwayRatio < 40) {
                        gammaWallBonus = 1.0;
                        runwayTier = 'CLEAN';
                    }
                    else if (runwayRatio < 60) {
                        gammaWallBonus = 0.5;
                        runwayTier = 'PASSABLE';
                    }
                    else {
                        gammaWallBonus = 0;
                        runwayTier = 'CONGESTED';
                    }
                    if (gammaWallBonus > 0) {
                        this.logger.info(`🎯 GW:${gammaWallBonus} [${runwayTier}] (Ratio: ${runwayRatio.toFixed(0)}%) | ${symbol} Wall=${selected.strike}${optionType} (OI:${selected.oi.toLocaleString()}) RunwayAvg=${avgRunwayOI.toLocaleString()}`);
                    }
                    else {
                        this.logger.debug(`⚠️ GW Rejected: Messy Runway (Ratio: ${runwayRatio.toFixed(0)}%) for ${symbol} ${selected.strike}${optionType}`);
                    }
                }
                catch (err) {
                    this.logger.warn(`⚠️ Runway fetch failed for ${symbol}: ${err}`);
                    gammaWallBonus = 0;
                    runwayTier = 'CONGESTED';
                    runwayRatio = 100;
                }
            }
            else {
                this.logger.debug(`📊 ${symbol}: No runway strikes available - GW:0`);
                runwayTier = 'CONGESTED';
                runwayRatio = 100;
            }
        }
        const candidateLog = candidates.map(c => `${c.strike}:${c.oi.toLocaleString()}`).join(', ');
        this.logger.debug(`📊 3-Strike Selection: ${symbol} | ATM=${atmStrike} | Candidates=[${candidateLog}] | Selected=${selected.strike} (OI: ${selected.oi.toLocaleString()})`);
        return {
            tradingsymbol: selected.tradingsymbol,
            strike: selected.strike,
            premium: selected.premium,
            expiry,
            oi: selected.oi,
            volume: selected.volume,
            lotSize: selected.option.lot_size || 1,
            gammaWallBonus,
            runwayTier,
            runwayRatio,
        };
    }
    getCurrentMonthLastTuesday() {
        const today = new Date();
        const year = today.getFullYear();
        const month = today.getMonth();
        const lastDay = new Date(year, month + 1, 0);
        let lastTuesday = new Date(lastDay);
        while (lastTuesday.getDay() !== 2) {
            lastTuesday.setDate(lastTuesday.getDate() - 1);
        }
        if (today > lastTuesday) {
            const nextMonth = new Date(year, month + 2, 0);
            while (nextMonth.getDay() !== 2) {
                nextMonth.setDate(nextMonth.getDate() - 1);
            }
            return nextMonth;
        }
        return lastTuesday;
    }
    async getActualNearestExpiry(sampleSymbol = 'RELIANCE') {
        try {
            const instruments = await this.instrumentCache.getNFOInstruments();
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const stockOptions = instruments.filter((i) => i.name === sampleSymbol &&
                i.segment === 'NFO-OPT' &&
                new Date(i.expiry) >= today);
            if (stockOptions.length === 0) {
                this.logger.warn(`No options found for ${sampleSymbol}`);
                return null;
            }
            const expiryDates = stockOptions
                .map((o) => new Date(o.expiry).getTime())
                .filter((v, i, a) => a.indexOf(v) === i)
                .sort((a, b) => a - b);
            if (expiryDates.length === 0)
                return null;
            const firstExpiry = expiryDates[0];
            if (firstExpiry === undefined)
                return null;
            const nearestExpiry = new Date(firstExpiry);
            this.logger.info(`📅 Nearest expiry for ${sampleSymbol}: ${nearestExpiry.toDateString()}`);
            return nearestExpiry;
        }
        catch (error) {
            this.logger.error('Failed to fetch actual expiry from instruments:', error);
            return null;
        }
    }
    async isStockTradingBlocked() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const expiry = await this.getActualNearestExpiry('RELIANCE');
        if (!expiry) {
            this.logger.error("🚫 Cannot determine expiry date from instruments - blocking for safety");
            return true;
        }
        expiry.setHours(0, 0, 0, 0);
        const daysToExpiry = Math.floor((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        this.logger.info(`📅 Expiry check: Today=${today.toDateString()}, Expiry=${expiry.toDateString()}, DaysToExpiry=${daysToExpiry}`);
        if (daysToExpiry === 0) {
            this.logger.error("🚫 Expiry Day - Stock options blocked (physical settlement)");
            return true;
        }
        if (daysToExpiry === 1) {
            this.logger.error("🚫 Day before expiry - Blocked (high margins for physical settlement)");
            return true;
        }
        if (daysToExpiry === 2) {
            this.logger.warn("⚠️ 2 days to expiry - Enhanced liquidity checks active");
        }
        return false;
    }
    findClosestStrike(spotPrice, strikes) {
        return strikes.reduce((prev, curr) => Math.abs(curr - spotPrice) < Math.abs(prev - spotPrice) ? curr : prev);
    }
    derive15MinCandles(candles5m) {
        const candles15m = [];
        for (let i = 0; i < candles5m.length; i += 3) {
            const chunk = candles5m.slice(i, i + 3);
            if (chunk.length === 3 && chunk[0] && chunk[2]) {
                candles15m.push({
                    date: chunk[0].date,
                    open: chunk[0].open,
                    high: Math.max(...chunk.map((c) => c.high)),
                    low: Math.min(...chunk.map((c) => c.low)),
                    close: chunk[2].close,
                    volume: chunk.reduce((sum, c) => sum + c.volume, 0),
                });
            }
        }
        return candles15m;
    }
    derive60MinCandles(candles5m) {
        const candles60m = [];
        let chunk = [];
        let currentDay = -1;
        for (let i = 0; i < candles5m.length; i++) {
            const candle = candles5m[i];
            if (!candle)
                continue;
            const candleDay = new Date(candle.date).getDate();
            if (chunk.length > 0 && (chunk.length === 12 || candleDay !== currentDay)) {
                candles60m.push({
                    date: chunk[0].date,
                    open: chunk[0].open,
                    high: Math.max(...chunk.map((c) => c.high)),
                    low: Math.min(...chunk.map((c) => c.low)),
                    close: chunk[chunk.length - 1].close,
                    volume: chunk.reduce((sum, c) => sum + c.volume, 0),
                });
                chunk = [];
            }
            chunk.push(candle);
            currentDay = candleDay;
        }
        if (chunk.length > 0) {
            candles60m.push({
                date: chunk[0].date,
                open: chunk[0].open,
                high: Math.max(...chunk.map((c) => c.high)),
                low: Math.min(...chunk.map((c) => c.low)),
                close: chunk[chunk.length - 1].close,
                volume: chunk.reduce((sum, c) => sum + c.volume, 0),
            });
        }
        return candles60m;
    }
    calculateEMA(data, period) {
        if (data.length < period)
            return data[data.length - 1] || 0;
        const multiplier = 2 / (period + 1);
        let ema = data.slice(0, period).reduce((a, b) => a + b, 0) / period;
        for (let i = period; i < data.length; i++) {
            const value = data[i];
            if (value !== undefined) {
                ema = (value - ema) * multiplier + ema;
            }
        }
        return ema;
    }
    calculateRSI(closes, period) {
        if (closes.length < period + 1)
            return 50;
        let gains = 0;
        let losses = 0;
        for (let i = 1; i <= period; i++) {
            const curr = closes[i];
            const prev = closes[i - 1];
            if (curr !== undefined && prev !== undefined) {
                const change = curr - prev;
                if (change > 0)
                    gains += change;
                else
                    losses += Math.abs(change);
            }
        }
        let avgGain = gains / period;
        let avgLoss = losses / period;
        for (let i = period + 1; i < closes.length; i++) {
            const curr = closes[i];
            const prev = closes[i - 1];
            if (curr !== undefined && prev !== undefined) {
                const change = curr - prev;
                if (change > 0) {
                    avgGain = (avgGain * (period - 1) + change) / period;
                    avgLoss = (avgLoss * (period - 1)) / period;
                }
                else {
                    avgGain = (avgGain * (period - 1)) / period;
                    avgLoss = (avgLoss * (period - 1) + Math.abs(change)) / period;
                }
            }
        }
        if (avgLoss === 0)
            return 100;
        const rs = avgGain / avgLoss;
        return 100 - 100 / (1 + rs);
    }
    calculateTacticalBonus(candles, currentPrice, bias, bb, bandwidthPercent) {
        const tactical = {
            freshBreakout: 0,
            rvolSurge: 0,
            proximity: 0,
            rsiAccel: 0,
            squeeze: 0,
            gammaWall: 0,
            total: 0
        };
        if (candles.length < 5) {
            return tactical;
        }
        const currCandle = candles[candles.length - 1];
        const prevCandle = candles[candles.length - 2];
        if (!currCandle || !prevCandle)
            return tactical;
        const currClose = currCandle.close;
        const prevClose = prevCandle.close;
        let isFreshBreakout = false;
        if (bias === 'LONG') {
            if (prevClose <= bb.upper && currClose > bb.upper) {
                tactical.freshBreakout = 0.75;
                isFreshBreakout = true;
                this.logger.debug(`  🔥 Fresh LONG Breakout: ${prevClose.toFixed(2)} → ${currClose.toFixed(2)} (BB Upper: ${bb.upper.toFixed(2)})`);
            }
        }
        else {
            if (prevClose >= bb.lower && currClose < bb.lower) {
                tactical.freshBreakout = 1.5;
                isFreshBreakout = true;
                this.logger.debug(`  🔥 Fresh SHORT Breakout: ${prevClose.toFixed(2)} → ${currClose.toFixed(2)} (BB Lower: ${bb.lower.toFixed(2)})`);
            }
        }
        const currVolume = currCandle.volume;
        const prevCandlesForVol = candles.slice(-21, -1);
        const prevVolumes = prevCandlesForVol.map(c => c.volume);
        const avgVolume = prevVolumes.length > 0
            ? prevVolumes.reduce((a, b) => a + b, 0) / prevVolumes.length
            : currVolume;
        const tacticalRvol = avgVolume > 0 ? currVolume / avgVolume : 1.0;
        if (bias === 'LONG') {
            if (tacticalRvol > 3.0) {
                tactical.rvolSurge = 1.0;
            }
            else if (tacticalRvol > 2.0) {
                tactical.rvolSurge = 0.75;
            }
            else if (tacticalRvol > 1.5) {
                tactical.rvolSurge = 0.5;
            }
        }
        else {
            if (tacticalRvol > 3.0) {
                tactical.rvolSurge = 2.0;
            }
            else if (tacticalRvol > 2.0) {
                tactical.rvolSurge = 1.5;
            }
            else if (tacticalRvol > 1.5) {
                tactical.rvolSurge = 1.0;
            }
        }
        if (!isFreshBreakout) {
            if (bias === 'LONG') {
                const distance = (bb.upper - currentPrice) / currentPrice;
                if (distance > 0 && distance < 0.002 && currClose > prevClose) {
                    tactical.proximity = 2.5;
                    this.logger.debug(`  📍 Proximity LONG: ${(distance * 100).toFixed(3)}% from upper band, approaching`);
                }
            }
            else {
                const distance = (currentPrice - bb.lower) / currentPrice;
                if (distance > 0 && distance < 0.002 && currClose < prevClose) {
                    tactical.proximity = 2.0;
                    this.logger.debug(`  📍 Proximity SHORT: ${(distance * 100).toFixed(3)}% from lower band, approaching`);
                }
            }
        }
        if (candles.length >= 4) {
            const closes = candles.map(c => c.close);
            const rsiCurrent = this.calculateRSI(closes, 14);
            const rsi3Ago = this.calculateRSI(closes.slice(0, -3), 14);
            if (bias === 'LONG' && (rsiCurrent - rsi3Ago) > 5) {
                tactical.rsiAccel = 2.0;
                this.logger.debug(`  🚀 RSI Accel LONG: ${rsi3Ago.toFixed(1)} → ${rsiCurrent.toFixed(1)} (+${(rsiCurrent - rsi3Ago).toFixed(1)})`);
            }
            else if (bias === 'SHORT' && (rsi3Ago - rsiCurrent) > 5) {
                tactical.rsiAccel = 1.5;
                this.logger.debug(`  🚀 RSI Accel SHORT: ${rsi3Ago.toFixed(1)} → ${rsiCurrent.toFixed(1)} (${(rsiCurrent - rsi3Ago).toFixed(1)})`);
            }
        }
        tactical.squeeze = Math.min(1.0, Math.max(0, (3.5 - bandwidthPercent) / 2.5));
        if (tactical.squeeze > 0.1) {
            this.logger.debug(`  💠 Squeeze: Bandwidth ${bandwidthPercent.toFixed(2)}% → +${tactical.squeeze.toFixed(2)} bonus`);
        }
        tactical.total = tactical.freshBreakout + tactical.rvolSurge +
            tactical.proximity + tactical.rsiAccel + tactical.squeeze;
        return tactical;
    }
    calculateADX(highs, lows, closes, period) {
        if (highs.length < period + 1)
            return 0;
        const trueRanges = [];
        const plusDMs = [];
        const minusDMs = [];
        for (let i = 1; i < highs.length; i++) {
            const high = highs[i];
            const low = lows[i];
            const prevHigh = highs[i - 1];
            const prevLow = lows[i - 1];
            const prevClose = closes[i - 1];
            if (high === undefined || low === undefined || prevHigh === undefined ||
                prevLow === undefined || prevClose === undefined) {
                continue;
            }
            const tr = Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose));
            trueRanges.push(tr);
            const plusDM = high - prevHigh > prevLow - low ? Math.max(high - prevHigh, 0) : 0;
            const minusDM = prevLow - low > high - prevHigh ? Math.max(prevLow - low, 0) : 0;
            plusDMs.push(plusDM);
            minusDMs.push(minusDM);
        }
        if (trueRanges.length < period)
            return 0;
        let smoothTR = trueRanges.slice(0, period).reduce((a, b) => a + b, 0);
        let smoothPlusDM = plusDMs.slice(0, period).reduce((a, b) => a + b, 0);
        let smoothMinusDM = minusDMs.slice(0, period).reduce((a, b) => a + b, 0);
        for (let i = period; i < trueRanges.length; i++) {
            const tr = trueRanges[i];
            const plusDM = plusDMs[i];
            const minusDM = minusDMs[i];
            if (tr !== undefined && plusDM !== undefined && minusDM !== undefined) {
                smoothTR = smoothTR - smoothTR / period + tr;
                smoothPlusDM = smoothPlusDM - smoothPlusDM / period + plusDM;
                smoothMinusDM = smoothMinusDM - smoothMinusDM / period + minusDM;
            }
        }
        const plusDI = (100 * smoothPlusDM) / smoothTR;
        const minusDI = (100 * smoothMinusDM) / smoothTR;
        const dx = (100 * Math.abs(plusDI - minusDI)) / (plusDI + minusDI || 1);
        return dx;
    }
    calculateVWAP(candles) {
        let cumVolume = 0;
        let cumPriceVolume = 0;
        for (const candle of candles) {
            const typicalPrice = (candle.high + candle.low + candle.close) / 3;
            cumPriceVolume += typicalPrice * candle.volume;
            cumVolume += candle.volume;
        }
        return cumVolume > 0 ? cumPriceVolume / cumVolume : 0;
    }
    calculateRVOL(volumes) {
        if (volumes.length < 20)
            return 1.0;
        const recentVolume = volumes.slice(-10).reduce((a, b) => a + b, 0) / 10;
        const avgVolume = volumes.slice(-20, -10).reduce((a, b) => a + b, 0) / 10;
        return avgVolume > 0 ? recentVolume / avgVolume : 1.0;
    }
    calculateSupertrend(candles, period = 10, multiplier = 2) {
        if (candles.length < period + 1) {
            const lastClose = candles[candles.length - 1]?.close || 0;
            return { value: lastClose, trend: 'UP' };
        }
        const trueRanges = [];
        for (let i = 1; i < candles.length; i++) {
            const candle = candles[i];
            const prevCandle = candles[i - 1];
            if (!candle || !prevCandle)
                continue;
            const tr = Math.max(candle.high - candle.low, Math.abs(candle.high - prevCandle.close), Math.abs(candle.low - prevCandle.close));
            trueRanges.push(tr);
        }
        if (trueRanges.length < period) {
            const lastClose = candles[candles.length - 1]?.close || 0;
            return { value: lastClose, trend: 'UP' };
        }
        let atr = trueRanges.slice(0, period).reduce((sum, tr) => sum + tr, 0) / period;
        for (let i = period; i < trueRanges.length; i++) {
            const currentTR = trueRanges[i];
            if (currentTR !== undefined) {
                atr = (atr * (period - 1) + currentTR) / period;
            }
        }
        const supertrendValues = [];
        for (let i = period; i < candles.length; i++) {
            const candle = candles[i];
            const prevCandle = candles[i - 1];
            if (!candle || !prevCandle)
                continue;
            const hl2 = (candle.high + candle.low) / 2;
            const basicUB = hl2 + (multiplier * atr);
            const basicLB = hl2 - (multiplier * atr);
            let finalUB, finalLB, trend, supertrend;
            if (supertrendValues.length === 0) {
                finalUB = basicUB;
                finalLB = basicLB;
                trend = candle.close <= finalUB ? -1 : 1;
                supertrend = trend === 1 ? finalLB : finalUB;
            }
            else {
                const prev = supertrendValues[supertrendValues.length - 1];
                if (!prev) {
                    finalUB = basicUB;
                    finalLB = basicLB;
                    trend = candle.close <= finalUB ? -1 : 1;
                    supertrend = trend === 1 ? finalLB : finalUB;
                }
                else {
                    finalUB = (basicUB < prev.finalUB || prevCandle.close > prev.finalUB) ? basicUB : prev.finalUB;
                    finalLB = (basicLB > prev.finalLB || prevCandle.close < prev.finalLB) ? basicLB : prev.finalLB;
                    if (prev.trend === 1) {
                        trend = candle.close < prev.supertrend ? -1 : 1;
                    }
                    else {
                        trend = candle.close > prev.supertrend ? 1 : -1;
                    }
                    supertrend = trend === 1 ? finalLB : finalUB;
                }
            }
            supertrendValues.push({ close: candle.close, finalUB, finalLB, trend, supertrend });
        }
        const lastValue = supertrendValues[supertrendValues.length - 1];
        if (!lastValue) {
            const lastClose = candles[candles.length - 1]?.close || 0;
            return { value: lastClose, trend: 'UP' };
        }
        return {
            value: lastValue.supertrend,
            trend: lastValue.trend === 1 ? 'UP' : 'DOWN'
        };
    }
    calculateBollingerBands(closes, period = 20, stdDevMultiplier = 2) {
        if (closes.length < period) {
            const lastClose = closes[closes.length - 1] || 0;
            return {
                upper: lastClose * 1.02,
                middle: lastClose,
                lower: lastClose * 0.98
            };
        }
        const recentCloses = closes.slice(-period);
        const sma = recentCloses.reduce((sum, close) => sum + close, 0) / period;
        const variance = recentCloses.reduce((sum, close) => sum + Math.pow(close - sma, 2), 0) / period;
        const stdDev = Math.sqrt(variance);
        return {
            upper: sma + (stdDev * stdDevMultiplier),
            middle: sma,
            lower: sma - (stdDev * stdDevMultiplier)
        };
    }
    emptyResult() {
        return {
            scanTime: new Date(),
            scannedCount: 0,
            qualifiedCount: 0,
            selected: [],
            allScored: [],
            greenSectors: [],
            redSectors: [],
            flatSectors: [],
            failedStocks: [],
        };
    }
}
exports.MarketScanner = MarketScanner;
//# sourceMappingURL=MarketScanner.js.map