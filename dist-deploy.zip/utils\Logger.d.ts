export declare class Logger {
    private logger;
    constructor();
    info(message: string, meta?: any): void;
    warn(message: string, meta?: any): void;
    error(message: string, error?: any): void;
    debug(message: string, meta?: any): void;
    log(level: string, message: string, meta?: any): void;
}
//# sourceMappingURL=Logger.d.ts.map