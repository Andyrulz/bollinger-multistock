"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logger = void 0;
const winston_1 = __importDefault(require("winston"));
const path_1 = __importDefault(require("path"));
class Logger {
    constructor() {
        const logDir = path_1.default.join(process.cwd(), 'logs');
        this.logger = winston_1.default.createLogger({
            level: process.env.LOG_LEVEL || 'info',
            format: winston_1.default.format.combine(winston_1.default.format.timestamp({
                format: 'YYYY-MM-DD HH:mm:ss'
            }), winston_1.default.format.errors({ stack: true }), winston_1.default.format.printf((info) => {
                const { level, message, timestamp, stack } = info;
                return `${timestamp} [${level.toUpperCase()}]: ${stack || message}`;
            })),
            transports: [
                new winston_1.default.transports.Console({
                    format: winston_1.default.format.combine(winston_1.default.format.colorize(), winston_1.default.format.simple())
                }),
                new winston_1.default.transports.File({
                    filename: path_1.default.join(logDir, 'trading.log'),
                    maxsize: 5242880,
                    maxFiles: 5,
                }),
                new winston_1.default.transports.File({
                    filename: path_1.default.join(logDir, 'error.log'),
                    level: 'error',
                    maxsize: 5242880,
                    maxFiles: 5,
                })
            ]
        });
    }
    info(message, meta) {
        this.logger.info(message, meta);
    }
    warn(message, meta) {
        this.logger.warn(message, meta);
    }
    error(message, error) {
        if (error) {
            this.logger.error(message, { error: error.message, stack: error.stack });
        }
        else {
            this.logger.error(message);
        }
    }
    debug(message, meta) {
        this.logger.debug(message, meta);
    }
    log(level, message, meta) {
        this.logger.log(level, message, meta);
    }
}
exports.Logger = Logger;
//# sourceMappingURL=Logger.js.map