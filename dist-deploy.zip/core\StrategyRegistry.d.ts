import { StrategyBase, StrategyConfig } from './StrategyBase';
import { Logger } from '../utils/Logger';
import { QuoteManager } from '../services/QuoteManager';
import { InstrumentCache } from '../utils/InstrumentCache';
export interface StrategyConstructor {
    new (kiteConnect: any, logger: Logger, quoteManager: QuoteManager, instrumentCache: InstrumentCache, config: StrategyConfig): StrategyBase;
}
export declare class StrategyRegistry {
    private static strategies;
    private static instances;
    private static logger;
    static initialize(logger: Logger): void;
    static registerStrategy(id: string, strategyClass: StrategyConstructor): void;
    static createInstance(id: string, kiteConnect: any, logger: Logger, quoteManager: QuoteManager, instrumentCache: InstrumentCache, config: StrategyConfig): Promise<StrategyBase>;
    static getInstance(id: string): StrategyBase | undefined;
    static getAllInstances(): Map<string, StrategyBase>;
    static removeInstance(id: string): Promise<boolean>;
    static getRegisteredStrategies(): string[];
    static getActiveInstances(): string[];
    static isRegistered(id: string): boolean;
    static hasInstance(id: string): boolean;
    static initializePendingStrategies(): Promise<void>;
}
//# sourceMappingURL=StrategyRegistry.d.ts.map